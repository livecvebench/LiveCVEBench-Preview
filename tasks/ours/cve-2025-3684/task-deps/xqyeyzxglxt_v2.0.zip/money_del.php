<?php

require_once(dirname(__FILE__).'/include/common.php');
if (strpos($_SESSION['eptime_flag'], 'moneydfig') === false) {LYG::ShowMsg('您没有权限！');} 

if(empty($_REQUEST['id'])){ lyg::showmsg('参数错误'); }

$arr = explode(",", $_REQUEST['id']);

$ids = array();
foreach($arr as $a){
	$b = intval($a);
    $c = c_moneyID($b);
$d = c_moneytype($b);
$e = c_moneyprice($b);
$f = c_moneyzhanghu($b);

$rowscount1 = $con->Excute("delete from #__money_pay where payid='{$c}'");

if($d==0){$eok = $con->Update("update #__zhanghu set amount=amount-{$e} where id={$f}");}
if($d==1){$eok = $con->Update("update #__zhanghu set amount=amount+{$e} where id={$f}");}

	if(!in_array($b,$ids)){
		$ids[] = $b;	
	}
}

if(count($ids)<1){
	lyg::showmsg('参数错误');
}

$ids = implode(" or id=",$ids);


$rowscount = $con->Excute("delete from #__money where id={$ids}");
LYG::writeLog("[".$_SESSION['eptime_username']."]删除 {$rowscount} 条收支记录");
LYG::ShowMsg("成功删除 {$rowscount} 条收支记录","money_list.php");