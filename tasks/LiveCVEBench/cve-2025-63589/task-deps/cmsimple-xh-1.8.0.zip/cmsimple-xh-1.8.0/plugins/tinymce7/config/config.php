<?php

$plugin_cf['tinymce7']['init']="dropdown";
$plugin_cf['tinymce7']['utf8_marker']="äöü";
$plugin_cf['tinymce7']['CDN_src']="https://cdn.tiny.cloud/1/no-api-key/tinymce/7/tinymce.min.js";
$plugin_cf['tinymce7']['CDN']="";
