<?php

die('access denied');
