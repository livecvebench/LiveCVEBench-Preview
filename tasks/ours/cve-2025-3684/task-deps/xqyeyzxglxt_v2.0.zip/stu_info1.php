<?php
require_once(dirname(__FILE__).'/include/common.php');
$webconfig = lyg::readArr("web");
$check_enable = intval($webconfig['system_check'])===1?true:false;

if(empty($_REQUEST['stuid']) || intval($_REQUEST['stuid'])<1){lyg::showmsg('参数错误');}
$dataid = intval($_REQUEST['stuid']);
$info=  $con->select("select * from #__jiaz where stuid=$dataid order by id");
	
if(!empty($_POST)){
	//参数校验
	extract($_POST);

	if(empty($jzmobile) || trim($jzmobile)==''){
		LYG::ShowMsg('电话不能为空');
	}
	if(empty($jzname) || trim($jzname)==''){
		LYG::ShowMsg('姓名不能为空');
	}

		$data = array(
		    'stuid' =>$stuid,
			'gx'    =>$jzgx,
            'name'	=>$jzname,
			'cardno'=>$jzcardno,
			'mobile'=>$jzmobile,
			'address'=>$jzaddress,
		    'beizhu'=>$jzbeizhu
	);
	$aok = $con->add("jiaz",$data);

	if($aok){
		LYG::ShowMsg('添加成功','stu_info1.php?stuid='.$stuid.'');
	}else{
		LYG::ShowMsg('添加失败，请重试');
	}
	
	die();
}

?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>家长信息</title>
<link href="style/css/css.css" rel="stylesheet" type="text/css" />
<link href="style/css/font-awesome.min.css" rel="stylesheet" type="text/css" />
<style type="text/css">
label{margin-right:10px;}
</style>
<script type="text/javascript" src="js/My97DatePicker/WdatePicker.js"></script>
<script type="text/javascript" src="js/jquery.min.js"></script>
<script type="text/javascript" src="js/common.js"></script>
		<link rel="stylesheet" href="kindeditor/themes/default/default.css" />
		<script src="kindeditor/kindeditor-all.js" charset="UTF-8"></script>
		<script src="kindeditor/lang/zh-CN.js" charset="UTF-8"></script>
		<script>
			KindEditor.ready(function(K) {
				var editor = K.editor({
					allowFileManager : true
				});
				K('#image3').click(function() {
					editor.loadPlugin('image', function() {
						editor.plugin.imageDialog({
							showRemote : false,
							imageUrl : K('#url3').val(),
							clickFn : function(url, title, width, height, border, align) {
								K('#url3').val(url);
								editor.hideDialog();
							}
						});
					});
				});
			});
		</script>
</head>


<body class="content">

<?php
foreach ($info as $k => $v) {
?>
<div align="right">			<a class="edit" href="stu_info1_edit.php?id=<?php echo $v['id'];?>"><i class="fa fa-pencil-square-o"></i><span>编辑</span></a>
				<a onclick="return confirm('确定删除吗？');" class="del" href="class_del.php?id=<?php echo $v['id'];?>&class=jiaz"><i class="fa fa-close"></i><span>删除</span></a>
</div>
<table cellpadding="3" cellspacing="0" class="table-add">
		<tr>
			<td align="right" height='36' width="100px">关系：</td>
			<td>
			<?php echo $v['gx'];?>
			</td>
		</tr>
		<tr>
			<td align="right" height='36'>姓名：</td>
			<td>
			<?php echo $v['name'];?>
			</td>
		</tr>
		<tr>
			<td align="right" height='36'>电话：</td>
			<td>
			<?php echo $v['mobile'];?>
			</td>
		</tr>
		<tr>
			<td align="right" height='36'>身份证号码：</td>
			<td>
			<?php echo $v['cardno'];?>
			</td>
		</tr>

		<tr>
			<td align="right" height='36'>地址：</td>
			<td>
			<?php echo $v['address'];?>
			</td>
		</tr>

	<tr>
		<td align="right" height='36'>备注：</td>
		<td align="left"><?php echo $v['beizhu'];?></td>
	</tr>
</table><br>
 <?php                 
}
?>
<br>
<form action='' method='post'>
<input type='hidden' name='stuid' value='<?php echo $dataid;?>'>
<table cellpadding="3" cellspacing="0" class="table-add">
		<tr>
			<td align="right" height='36' width="100px">关系：</td>
			<td>
<select name="jzgx" class="select"><?php 
			foreach($c_gx as $k=>$v){
						echo "<option value='{$k}'>{$v}</option>";
			}?>
</select>
			</td>
		</tr>
		<tr>
			<td align="right" height='36'>姓名：</td>
			<td>
			<input type="text" name="jzname" class='inp'>
			</td>
		</tr>
		<tr>
			<td align="right" height='36'>电话：</td>
			<td>
			<input type="text" name="jzmobile" class='inp'>
			</td>
		</tr>
		<tr>
			<td align="right" height='36'>身份证号码：</td>
			<td>
			<input type="text" name="jzcardno" class='inp'>
			</td>
		</tr>

		<tr>
			<td align="right" height='36'>地址：</td>
			<td>
			<input type="text" name="jzaddress" class='inp'>
			</td>
		</tr>


	<tr>
		<td align="right" height='36'>备注：</td>
		<td align="left"><input type="text" name="jzbeizhu" class='inp'></td>
	</tr>

			<tr>
				<td align="right" height='50'>　</td>
				<td align="left"><input class='sub' type='submit' value='添加'/></td>
			</tr>
</table>

</form>
</body>
</html>