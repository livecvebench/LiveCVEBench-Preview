<?php

die('access denied');

