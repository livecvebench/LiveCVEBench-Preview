<?php

require_once(dirname(__FILE__).'/include/common.php');
if (strpos($_SESSION['eptime_flag'], 'gongffig') === false) {LYG::ShowMsg('您没有权限！');}

$check_enable = intval($webconfig['system_check'])===1?true:false;
$login = $_SESSION['eptime_username'];
$time1=date('Y-m-d H:m:s',time());
$pagesize = 20;

//总记录数
$datacount=$con->RowsCount("select count(*) from #__gongzi where isok=0 ");
//总页数
$totalpages=LYG::getTotalPage($datacount,$pagesize);
$page=1;
if(isset($_GET['p']) && intval($_GET['p'])>0){
	$page=intval($_GET['p']);
	$page=$page>$totalpages?$totalpages:$page;
	if($page+1<=1){$page=1;}
}
$start_id=($page-1)*$pagesize;
//查询数据
$sql='select * from #__gongzi where isok=0 order by id desc limit '.$start_id.','.$pagesize;
$data	=$con->select($sql,'');
//得到分页HTML
$fenye=LYG::getPageHtml($page,$datacount,$pagesize);
if(trim($_GET['shenhe'])=="ok"){

//记账开始
	if(trim(c_bigclassid('3'))==''){
		LYG::ShowMsg('没有工资专用项目，不能操作');
	}
$type=c_bigclassid1('3');
$id_bigclass=c_bigclassid('3');
$id_smallclass=0;
$price=$_GET['gongzi'];
	if(trim(c_zhanghuisok('2'))==''){
		LYG::ShowMsg('没有工资发放账号，不能操作');
	}
$zhanghu=c_zhanghuisok('2');
$selldate=date("Y-m-d",time());
$wanglai=0;
$yuangong=$_GET['ygid'];
$moneyID=c_newOrderNo("G");
$id_login = $_SESSION['eptime_id'];
$login = $_SESSION['eptime_username'];
if($check_enable){
	$isok = 1;
		}
		else{$isok = 0;}
$addtime = date("Y-m-d H:i:s",time());
$beizhu1='工资发放自动生成';
	$data = array(
		'type'		=>$type,
  'id_bigclass'		=>$id_bigclass,
 'id_smallclass'	=>$id_smallclass,
        'price'		=>$price,
        'selldate'	=>$selldate,
		'zhanghu'	=>$zhanghu,
		'wanglai'	=>$wanglai,
		'yuangong'	=>$yuangong,
		'xiangmu'	=>$xiangmu,
		'moneyID'	=>$moneyID,
		'id_login'	=>$id_login,
        'login'		=>$login,
		'isok'		=>$isok,
		'beizhu'    =>$beizhu1,
		'addtime'	=>$addtime
	);
	
	$aok = $con->add("money",$data);
if ($type==0){$bok = $con->Update("update #__zhanghu set amount=amount+{$price} where id={$zhanghu}");}
elseif($type==1){$bok = $con->Update("update #__zhanghu set amount=amount-{$price} where id={$zhanghu}");}
//记账结束
$eok = $con->Update("update #__gongzi set isok=1,fa='{$login}',fatime='{$time1}' where id={$_GET['id']}");
echo "<script>window.history.go(-1);</script>";}
//if(trim($_GET['shenhe'])=="kk"){$eok = $con->Update("update #__gongzi set isok=0 where id={$_GET['id']}");echo "<script>window.history.go(-1);</script>";}

?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title></title>
<link href="style/css/css.css" rel="stylesheet" type="text/css" />
<link href="style/css/font-awesome.min.css" rel="stylesheet" type="text/css" />
<script type="text/javascript" src="js/jquery.min.js"></script>
<script type="text/javascript" src="js/common.js"></script>
<SCRIPT language=javascript> 
function openScript(url, width, height) {
        var Win = window.open(url,"openScript",'width=' + width + ',height=' + 
 
height + ',resizable=0,scrollbars=no,menubar=no,status=no' );
}
</SCRIPT>
</head>

<body class="content">




<table cellpadding="3" cellspacing="0">
	<thead>
    	<tr>
				<th>ID</th>
				<th>教工编号</th>
				<th>教工姓名</th>
				<th>任职岗位</th>
				<th>月份</th>
				<th>基本工资</th>
				<th>核算人</th>
				<th>核算时间</th>
				<th>应发工资</th>
				<th>实发工资</th>
				<th>备注</th>
				<th>发放状态</th>
        </tr>
    </thead>
    <tbody>
	<?php foreach($data as $k=>$v){?>
    	<tr class='list'>
<td align="center"><a href='javascript:openScript("gongzi_info.php?id=<?php echo $v['id'];?>",600,690)'><?php  echo $v['id'];?></a></td>
<td align="center"><?php  echo c_yuanggong1($v['ygid']);?></td>
<td align="center"><?php  echo c_yuanggong2($v['ygid']);?></td>
<td align="center"><?php  echo c_yuanggong3($v['ygid']);?></td>
<td align="center"><?php  echo $v['yuefen'];?></td>
<td align="center"><?php  echo $v['jiben'];?></td>
<td align="center"><?php echo $v['hesuan'];?></td>
<td align="center"><?php echo $v['addtime'];?></td>
<td align="center"><?php echo $v['gongzi'];?></td>
<td align="center"><?php echo $v['gongzia'];?></td>
<td align="center"><a title=<?php echo $v['beizhu'];?>>备注</a></td>
<td align="center"><?php if($v['isok']==1){echo "<font color=green>已发放</font>";}else{echo "<a href=?shenhe=ok&gongzi={$v['gongzia']}&ygid={$v['ygid']}&id={$v['id']}><font color=red>待发放</a></a>";}?></td>
        </tr>
	<?php }?>
    </tbody>
    <tfoot>
    	<tr>
        	<td colspan="12" style="padding-left:30px;">
			<?php echo $fenye ;?>
			</td>
        </tr>
    </tfoot>
</table>


</body>
</html>