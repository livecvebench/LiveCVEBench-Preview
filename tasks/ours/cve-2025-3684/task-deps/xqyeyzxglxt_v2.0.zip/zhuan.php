<?php

require_once(dirname(__FILE__).'/include/common.php');
if (strpos($_SESSION['eptime_flag'], 'zhangzfig') === false) {LYG::ShowMsg('您没有权限！');} 
$webconfig = lyg::readArr("web");
$check_enable = intval($webconfig['system_check'])===1?true:false;


if(empty($_REQUEST['id']) || intval($_REQUEST['id'])<1){lyg::showmsg('参数错误');}
$dataid = intval($_REQUEST['id']);
$info=  $con->find("select * from #__zhanghu where id=$dataid");
if(empty($info)){lyg::showmsg('参数错误');}

if(!empty($_POST)){
	
	extract($_POST);
$type=2;
$moneyID=c_newOrderNo("Z");
$price=trim($price);
$price11=trim($price11);
$selldate=trim($selldate);
    $zhanghu = intval($zhanghu);
	$zhanghu1= intval($zhanghu1);
	$beizhu= trim($beizhu);
$id_login = $_SESSION['eptime_id'];
$login = $_SESSION['eptime_username'];
$addtime = date("Y-m-d H:i:s",time());

	if(empty($price) || trim($price)==''){
		LYG::ShowMsg('金额不能为空');
	}
	if($price11-$price<0){
		LYG::ShowMsg('转出账户余额不足，不能进行操作!');
	}

if($check_enable){$isok = 1;}else{$isok = 0;}

	$data = array(
		'type'		=>$type,
        'price'		=>$price,
        'selldate'	=>$selldate,
		'zhanghu'	=>$zhanghu,
        'zhanghu1'	=>$zhanghu1,
		'beizhu'	=>$beizhu,
		'moneyID'	=>$moneyID,
		'id_login'	=>$id_login,
        'login'		=>$login,
		'isok'		=>$isok,
		'addtime'	=>$addtime
	);

$result = $con->add("money_pay",$data);
	if($result!==false){

$eok = $con->Update("update #__zhanghu set amount=amount-{$price} where id={$zhanghu}");
$eok = $con->Update("update #__zhanghu set amount=amount+{$price} where id={$zhanghu1}");

LYG::writeLog("[".$_SESSION['eptime_username']."]转账成功！");
		LYG::ShowMsg('转账成功','money_zhang_list.php');
	}else{
		LYG::ShowMsg('没有更改');
	}
	
	die();
	
}

$classes = $con->select("select * from #__zhanghu where id!=$dataid");
	
?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title></title>
<link href="style/css/css.css" rel="stylesheet" type="text/css" />
<style type="text/css">
label{margin-right:10px;}
</style>
<script type="text/javascript" src="js/My97DatePicker/WdatePicker.js"></script>
<script type="text/javascript" src="js/jquery.min.js"></script>
<script type="text/javascript" src="js/common.js"></script>
		<link rel="stylesheet" href="kindeditor/themes/default/default.css" />
		<script src="kindeditor/kindeditor-all.js" charset="UTF-8"></script>
		<script src="kindeditor/lang/zh-CN.js" charset="UTF-8"></script>
		<script>
			KindEditor.ready(function(K) {
				var editor = K.editor({
					allowFileManager : true
				});
				K('#image3').click(function() {
					editor.loadPlugin('image', function() {
						editor.plugin.imageDialog({
							showRemote : false,
							imageUrl : K('#url3').val(),
							clickFn : function(url, title, width, height, border, align) {
								K('#url3').val(url);
								editor.hideDialog();
							}
						});
					});
				});
			});
		</script>
</head>


<body class="content">

<h5 class='back' onclick='history.go(-1);'><span>返回</span></h5>

<form action='' method='post'>
<input type='hidden' name='id' value="<?php echo $dataid;?>" />
<table cellpadding="3" cellspacing="0" class="table-add">
		<tr>
			<td align="right" height='36'></td>
			<td>

			</td>
		</tr>

		<tr>
			<td align="right" height='36'>类型：</td>
			<td>
	转账
			
			</td>
		</tr>


		<tr>
			<td align="right" height='36'>转出账户：</td>
			<td align="left" width='*'>
<?php echo $info['name'];?><input type='hidden' name='zhanghu' value="<?php echo $dataid;?>" /><input type='hidden' name='price11' value="<?php echo $info['amount'];?>" />
			</td>
		</tr>

		<tr>
			<td align="right" height='36'>转入账户：</td>
			<td align="left" width='*'>
				<select name="zhanghu1" class="select">
				<?php
				foreach($classes as $k=>$v){
        			echo "<option value='{$v['id']}'>{$v['name']}</option>";
				}
				?>
				</select>
			</td>
		</tr>

		<tr>
			<td align="right" height='36'>金额：</td>
			<td>
			<input class='inp' type='number' name='price' placeholder="0.00" step="0.01"/>
			<span>数字，请保留小数点后两位</span>
			</td>
		</tr>
		<tr>
			<td align="right" height='36'>时间：</td>
			<td>
			
			<input type='text' class='inp' name='selldate' value='<?php echo date("Y-m-d",time()) ?>' placeholder="0000-00-00" onclick="WdatePicker();" />
			<span>点击选择</span>
			</td>
		</tr>




	<tr>
		<td align="right" height='36'>备注：</td>
		<td align="left"><input type='text' class='inp' name='beizhu' placeholder='' /></td>
	</tr>


	<tr>
    	<td align="right" height='50'>　</td>
        <td align="left">
        	<input class='sub' type='submit' value='转账'/>　<input class='reset' type='reset' value='重置'></td>
    </tr>


    
</table>
</form>

</body>
</html>