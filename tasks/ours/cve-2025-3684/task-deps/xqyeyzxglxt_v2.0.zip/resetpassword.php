<?php

session_start();
error_reporting(0);
require_once(dirname(__FILE__).'/init.php');
require_once(dirname(__FILE__).'/include/mysql.php');
require_once(dirname(__FILE__).'/include/function.php');
header('Content-type:text/html;charset=utf-8');

define('USER','admin');
define('PASSWORD','admin');

$userInfo = array(
	'UserName'	=> USER,
	'Password'	=> c_adminpwd(PASSWORD),
);
$success = $con->savemin('admin',$userInfo,'id=1');
if($success !== false){
	echo '账号密码重置成功，账号：'.USER.'，密码：'.PASSWORD.'<br/>重置密码后请务必删除本文件或重命名本文件！！！';
}else{
	echo '账号密码重置失败，请重试。';
}