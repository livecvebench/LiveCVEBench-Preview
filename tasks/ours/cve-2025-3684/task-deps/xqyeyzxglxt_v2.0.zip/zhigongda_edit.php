<?php
require_once(dirname(__FILE__).'/include/common.php');
if (strpos($_SESSION['eptime_flag'], 'zhimfig') === false) {LYG::ShowMsg('您没有权限！');} 

if(empty($_REQUEST['id']) || intval($_REQUEST['id'])<1){lyg::showmsg('参数错误');}
$id = intval($_REQUEST['id']);
$info=  $con->find("select * from #__yuangong where id=$id");
if(empty($info)){lyg::showmsg('参数错误');}

if(!empty($_POST)){
	//参数校验
	extract($_POST);
if(empty($bianhao) || trim($bianhao)==''){
		LYG::ShowMsg('编号不能为空');
	}	
	if(empty($name) || trim($name)==''){
		LYG::ShowMsg('名称不能为空');
	}
$bianhao= trim($bianhao);
$name= trim($name);
$sex= trim($sex);
$nation= trim($nation);
$shengri= trim($shengri);
$gangwei= trim($gangwei);
$banji = intval($banji);
$ruzhi= trim($ruzhi);
$zjtype= trim($zjtype);
$zjno= trim($zjno);
$tel= trim($tel);
$address= trim($address);
$beizhu= trim($beizhu);

	$ex = $con->rowscount("select count(*) from #__yuangong where bianhao=? and id<>$id",array($bianhao));
	if($ex>0){
		lyg::showmsg("已存在");
	}
$eok = $con->update("update #__yuangong set bianhao=?, name=?,sex=?,nation=?,shengri=?,gangwei=?,banji=?,ruzhi=?,zjtype=?,zjno=?,tel=?,address=?,beizhu=? where id=$id limit 1",array($bianhao,$name,$sex,$nation,$shengri,$gangwei,$banji,$ruzhi,$zjtype,$zjno,$tel,$address,$beizhu));

	if($eok!==false){
		LYG::ShowMsg('操作成功','zhigongda_list.php');
	}else{
		LYG::ShowMsg('操作失败，请重试');
	}
	die();
}
$classes = $con->select("select * from #__gangwei");	
?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>编辑<?php echo $c_class["{$class}"];?></title>
<link href="style/css/css.css" rel="stylesheet" type="text/css" />
<script type="text/javascript" src="js/My97DatePicker/WdatePicker.js"></script>
<script type="text/javascript" src="js/jquery.min.js"></script>
<script type="text/javascript" src="js/common.js"></script>
</head>

<body class="content">

<h5 class='back' onclick='history.go(-1);'><span>返回</span></h5>

<form action='' method='post'>
	<input type='hidden' name='id' value='<?php echo $info['id'];?>'>
	<table cellpadding="3" cellspacing="0" class="table-add">
		<tbody>
			<tr>
				<td align="right" width='100' height='36'>教工编号：</td>
				<td align="left" width='*'>
					<input type='text' class='inp' name='bianhao' placeholder=''  value='<?php echo $info['bianhao'];?>'/>
				</td>
			</tr>
			<tr>
				<td align="right" width='100' height='36'>教工姓名：</td>
				<td align="left" width='*'>
					<input type='text' class='inp' name='name' placeholder='' value='<?php echo $info['name'];?>'/>
				</td>
			</tr>
			<tr>
				<td align="right" width='100' height='36'>教工性别：</td>
				<td align="left" width='*'>
			<select name="sex" class="select" id="sex">
			<?php 
			foreach($c_sex as $k=>$v){
        		if($info['sex']===$v){echo "<option value='{$k}' selected='selected'>{$v}</option>";}else{echo "<option value='{$k}'>{$v}</option>";}		
			}?>
			</select>	民族：<select name="nation" class="select" id="nation">
			<?php 
			foreach($c_nation as $k=>$v){
if($info['nation']===$v){echo "<option value='{$k}' selected='selected'>{$v}</option>";}else{echo "<option value='{$k}'>{$v}</option>";}	
			}?>
			</select>
				</td>
			</tr>
			<tr>
				<td align="right" width='100' height='36'>教工生日：</td>
				<td align="left" width='*'>
					<input type='text' class='inp' name='shengri' placeholder="0000-00-00"  value='<?php echo substr($info['shengri'],0,10);?>' onclick="WdatePicker();"/>
				</td>
			</tr>
			<tr>
				<td align="right" width='100' height='36'>任职岗位：</td>
				<td align="left" width='*'>
			<select name="gangwei" class="select" onchange="search(this);">
			<?php
			foreach ($classes as $k => $v) {
if($info['gangwei']===$v['name']){echo "<option value='{$v['name']}' selected='selected'>{$v['name']}</option>";}else{echo "<option value='{$v['name']}'>{$v['name']}</option>";}
			}
			?></select> 所在班级：
			<select name="banji" class="select">
				<?php
				foreach(c_classinfo("xiangmu") as $k=>$v){

        		if(intval($info['banji'])===intval($v['id'])){
					echo "<option value='{$v['id']}' selected='selected'>{$v['name']}</option>";
        		}else{
        			echo "<option value='{$v['id']}'>{$v['name']}</option>";}
				}
				?>
				</select>
				</td>
			</tr>

			<tr>
				<td align="right" width='100' height='36'>入职日期：</td>
				<td align="left" width='*'>
					<input type='text' class='inp' name='ruzhi' placeholder="0000-00-00" value='<?php echo substr($info['ruzhi'],0,10);?>' onclick="WdatePicker();" />
				</td>
			</tr>

			<tr>
				<td align="right" width='100' height='36'>证件类型：</td>
				<td align="left" width='*'>
			<select name="zjtype" class="select" id="zjtype">
			<?php 
			foreach($c_zjtype as $k=>$v){
        		if($info['zjtype']===$v){
					echo "<option value='{$v}' selected='selected'>{$v}</option>";
        		}else{
        			echo "<option value='{$v}'>{$v}</option>";}
				}
			?>
			</select>
				</td>
			</tr>
			<tr>
				<td align="right" width='100' height='36'>证件号码：</td>
				<td align="left" width='*'>
					<input type='text' class='inp' name='zjno' placeholder='' value='<?php echo $info['zjno'];?>'/>
				</td>
			</tr>
			<tr>
				<td align="right" width='100' height='36'>联系电话：</td>
				<td align="left" width='*'>
					<input type='text' class='inp' name='tel' placeholder='' value='<?php echo $info['tel'];?>'/>
				</td>
			</tr>
			<tr>
				<td align="right" width='100' height='36'>联系地址：</td>
				<td align="left" width='*'>
					<input type='text' class='inp' name='address' placeholder='' value='<?php echo $info['address'];?>'/>
				</td>
			</tr>

			<tr>
				<td align="right" width='100' height='36'>备注：</td>
				<td align="left" width='*'>
					<input type='text' class='inp' name='beizhu' placeholder='' value='<?php echo $info['beizhu'];?>'/>
				</td>
			</tr>
			<tr>
				<td align="right" height='50'>　</td>
				<td align="left"><input class='sub' type='submit' value='修改'/></td>
			</tr>
		</tbody>
	</table>

</form>

</body>
</html>