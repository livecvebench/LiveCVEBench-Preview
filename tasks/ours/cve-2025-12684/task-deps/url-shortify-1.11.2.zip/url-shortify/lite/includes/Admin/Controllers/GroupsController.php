<?php

namespace KaizenCoders\URL_Shortify\Admin\Controllers;

class GroupsController extends BaseController {

}
