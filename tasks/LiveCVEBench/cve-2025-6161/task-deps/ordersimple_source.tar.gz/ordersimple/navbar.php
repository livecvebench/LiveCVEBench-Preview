<nav class="navbar navbar-default">
  <div class="container">
    <!-- Brand and toggle get grouped for better mobile display -->
	<div>
   <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
        <span class="sr-only">Toggle navigation</span>
        <span class="icon-bar"></span>
       
      </button>
      <a href="index.php"><center><b>FoodBot</b><center></a>
    </div>

    <!-- Collect the nav links, forms, and other content for toggling -->
    <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
      <ul class="nav navbar-nav">
        <li><a href="index.php">Menu</a></li>
        <li><a href="order.php">Order</a></li>
		<li><a href="view.php">View Your Order</a></li>
      </ul>
	  <ul>
	  	<li class="right"><a href="login.php">Admin</a></li>
	  </ul>	
    </div><!-- /.navbar-collapse -->
  </div><!-- /.container-fluid -->
</nav>







<style>
.right {
 float: right;
 list-style-type: none;
}
center{
font-size:18px;
 padding:15px 15px;

}
</style>