<?php
require_once(dirname(__FILE__).'/include/common.php');
if (strpos($_SESSION['eptime_flag'], 'qingafig') === false) {LYG::ShowMsg('您没有权限！');}

$webconfig = lyg::readArr("web");

$check_enable = intval($webconfig['system_check'])===1?true:false;
	
if(!empty($_POST)){
	//参数校验
	extract($_POST);

	if(empty($stuid) || trim($stuid)==''){
		LYG::ShowMsg('请假人不能为空');
	}

preg_match_all('/(?<=\[)([^\]]*?)(?=\])/' , $stuid , $ary);
$stuid1 = $ary[0][0] ;

		$data = array(
		    'stuid'    =>$stuid1,
			'begindate'=>$begindate,
            'enddate'  =>$enddate,
			'yuangong' =>$yuangong,
		    'beizhu'   =>$beizhu
	);
	$aok = $con->add("qingj",$data);

	if($aok){

$eok = $con->Update("update #__wanglai set isok=2 where id={$stuid1}");

		LYG::ShowMsg('添加成功','qing_list.php');
	}else{
		LYG::ShowMsg('添加失败，请重试');
	}
	
	die();
}

?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>请假登记</title>
<link href="style/css/css.css" rel="stylesheet" type="text/css" />
<link href="style/css/font-awesome.min.css" rel="stylesheet" type="text/css" />
<style type="text/css">
label{margin-right:10px;}
</style>
<script type="text/javascript" src="js/My97DatePicker/WdatePicker.js"></script>
<script type="text/javascript" src="js/jquery.min.js"></script>
<script type="text/javascript" src="js/common.js"></script>
		<link rel="stylesheet" href="kindeditor/themes/default/default.css" />
		<script src="kindeditor/kindeditor-all.js" charset="UTF-8"></script>
		<script src="kindeditor/lang/zh-CN.js" charset="UTF-8"></script>
		<script>
			KindEditor.ready(function(K) {
				var editor = K.editor({
					allowFileManager : true
				});
				K('#image3').click(function() {
					editor.loadPlugin('image', function() {
						editor.plugin.imageDialog({
							showRemote : false,
							imageUrl : K('#url3').val(),
							clickFn : function(url, title, width, height, border, align) {
								K('#url3').val(url);
								editor.hideDialog();
							}
						});
					});
				});
			});
		</script>
        <script  language="javascript">
            function ShowOpenWin(objTag)
            {
                document.getElementById("frmOpenWin").style.display = "block";
                
                var position = getPos(objTag);                    

                document.getElementById("frmOpenWin").style.top =  (position.y+22) + "px";
                document.getElementById("frmOpenWin").style.left = position.x+"px";
            }

            function HiddenAllFlag()
            {
                if(event.srcElement.id != "tbxCategory")
                {
                    document.getElementById("frmOpenWin").style.display = "none";
                }
            }
            
            function getPos(elm)
            {
                for(var zx=zy=0;elm!=null;zx+=elm.offsetLeft,zy+=elm.offsetTop,elm=elm.offsetParent); 
                return {x:zx,y:zy}                
            }
        </script>
</head>


<body class="content">
<form action='' method='post'>
<table cellpadding="3" cellspacing="0" class="table-add">
		<tr>
			<td align="right" height='36' width="100px">请假人：</td>
			<td>
<input type="text" name="stuid" id="tbxCategory" onClick="ShowOpenWin(this);" style="width:360" class='inp'  readonly/> <font color="red">必须选择</font>
<iframe onlosecapture="HiddenAllFlag()" onblur="HiddenAllFlag()" src="wang.php" id="frmOpenWin" frameborder="0" style="BORDER-RIGHT: 1px solid; BORDER-TOP: 1px solid; DISPLAY: none; BORDER-LEFT: 1px solid; WIDTH: 360px; BORDER-BOTTOM: 1px solid; POSITION: absolute; HEIGHT: 200px"></iframe>

			</td>
		</tr>
		<tr>
			<td align="right" height='36'>开始时间：</td>
			<td>
			<input type='text' class='inp' name='begindate' value='<?php echo date("Y-m-d H:00:00",time()) ?>' placeholder="0000-00-00 00:00:00" onclick="WdatePicker({dateFmt:'yyyy-MM-dd HH:mm:ss'});" />
			<span>点击选择</span>
			</td>
		</tr>
		<tr>
			<td align="right" height='36'>结束时间：</td>
			<td>
			<input type='text' class='inp' name='enddate' value='<?php echo date("Y-m-d H:00:00",time()) ?>' placeholder="0000-00-00  00:00:00" onclick="WdatePicker({dateFmt:'yyyy-MM-dd HH:mm:ss'});" />
			<span>点击选择</span>
			</td>
		</tr>
		<tr>
			<td align="right" height='36'>经办人：</td>
			<td>
			<select name="yuangong" class="select">
				<?php
				foreach(c_classinfo("yuangong") as $k=>$v){
if(intval($_SESSION['eptime_l_yuangong'])===intval($v['id'])){echo "<option value='{$v['id']}' selected='selected'>{$v['name']}</option>";}
else{echo "<option value='{$v['id']}'>{$v['name']}</option>";}
				}
				?>
				</select>
			</td>
		</tr>
	<tr>
		<td align="right" height='36'>备注：</td>
		<td align="left"><input type="text" name="beizhu" class='inp'></td>
	</tr>

			<tr>
				<td align="right" height='50'>　</td>
				<td align="left"><input class='sub' type='submit' value='添加'/></td>
			</tr>
</table>

</form>
</body>
</html>