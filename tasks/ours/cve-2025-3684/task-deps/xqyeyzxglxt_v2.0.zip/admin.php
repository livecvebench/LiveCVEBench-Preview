<?php

require_once(dirname(__FILE__).'/include/common.php');

$webconfig = lyg::readArr("web");


?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="renderer" content="webkit" />
<title><?php echo $webconfig['system_title'];?></title>
</head>


<frameset rows="60,*" frameborder="0">
	<frame src="admin_head.php" style="border-bottom:0px solid #ccc;"/>
	<frameset cols="200,*">
    	<frame src="admin_left.php" style="border-right:1px solid #ccc"/>
        <frame name="right" src="admin_default.php"/>
    </frameset>
</frameset><noframes></noframes>


</html>
