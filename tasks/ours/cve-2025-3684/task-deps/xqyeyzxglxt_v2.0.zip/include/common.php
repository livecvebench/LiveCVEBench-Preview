<?php

//error_reporting(0);

session_start();

require_once(dirname(__FILE__).'/init.php');
require_once(dirname(__FILE__).'/mysql.php');
require_once(dirname(__FILE__).'/function.php');


LYG::checklogin();
