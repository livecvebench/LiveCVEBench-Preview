<?php

$plugin_tx['fa']['alt_logo']="Fort Awesome";
$plugin_tx['fa']['syscheck_fail']="failure";
$plugin_tx['fa']['syscheck_message']="Checking that %1\$s … %2\$s";
$plugin_tx['fa']['syscheck_phpversion']="PHP version ≥ %s";
$plugin_tx['fa']['syscheck_success']="okay";
$plugin_tx['fa']['syscheck_title']="System check";
$plugin_tx['fa']['syscheck_warning']="warning";
$plugin_tx['fa']['syscheck_writable']="“%s” is writable";
$plugin_tx['fa']['syscheck_xhversion']="CMSimple_XH version ≥ %s";
$plugin_tx['fa']['cf_require_auto']="Whether Font Awesome is always available.";
$plugin_tx['fa']['cf_fontawesome_version']="The Font Awesome version to use. The editor plugins are not yet compatible with Font Awesome 5.";
$plugin_tx['fa']['cf_fontawesome_shim']="Improved backward compatibility when using Font Awesome 5.";
