<?php


namespace KaizenCoders\URL_Shortify\Admin\Controllers;

class BaseController {

	public function __construct() {
	}

	public function request() {
	}
}
