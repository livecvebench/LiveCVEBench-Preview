<?php

require_once(dirname(__FILE__).'/include/common.php');
$webconfig = lyg::readArr("web");
if (strpos($_SESSION['eptime_flag'], 'moneyfig') === false) {LYG::ShowMsg('您没有权限！');} 
$check_enable = intval($webconfig['system_check'])===1?true:false;
if(!empty($_POST)){
	//参数校验
	extract($_POST);

$type=intval($type);
$id_bigclass=intval($id_bigclass);
$id_smallclass=intval($id_smallclass);
$price=trim($price);
$selldate=trim($selldate);
	$zhanghu = intval($zhanghu);
	$wanglai = intval($wanglai);
	$yuangong = intval($yuangong);
	$xiangmu = intval($xiangmu);
	$beizhu= trim($beizhu);
	$img = trim($img);

$moneyID = c_newOrderNo("D");
$id_login = $_SESSION['eptime_id'];
$login = $_SESSION['eptime_username'];
if($check_enable){
	$isok = 1;
		}
		else{$isok = 0;}
$addtime = date("Y-m-d H:i:s",time());


	if(trim($type)==''){
		LYG::ShowMsg('类型不能为空');
	}
	if(empty($id_bigclass) || trim($id_bigclass)==''){
		LYG::ShowMsg('一级分类不能为空');
	}
	if(empty($id_smallclass) || trim($id_smallclass)==''){
		LYG::ShowMsg('二级分类不能为空');
	}
	if(empty($price) || trim($price)==''){
		LYG::ShowMsg('金额不能为空');
	}
	$ex = $con->rowscount("select count(*) from #__money where moneyID=?",array($moneyID));
	if($ex>0){
		lyg::showmsg("单据号出错，请重新提交！");
	}
	
	$data = array(
		'type'		=>$type,
  'id_bigclass'		=>$id_bigclass,
 'id_smallclass'	=>$id_smallclass,
        'price'		=>$price,
        'selldate'	=>$selldate,
		'zhanghu'	=>$zhanghu,
		'wanglai'	=>$wanglai,
		'yuangong'	=>$yuangong,
		'xiangmu'	=>$xiangmu,
		'beizhu'	=>$beizhu,
		'img'		=>$img,
		'moneyID'	=>$moneyID,
		'id_login'	=>$id_login,
        'login'		=>$login,
		'isok'		=>$isok,
		'addtime'	=>$addtime
	);
	
	$aok = $con->add("money",$data);

	if($aok){

if ($type==0){$eok = $con->Update("update #__zhanghu set amount=amount+{$price} where id={$zhanghu}");}
elseif($type==1){$eok = $con->Update("update #__zhanghu set amount=amount-{$price} where id={$zhanghu}");}

if (c_bigclassisok($id_bigclass)==1){
	$beizhu1= $c_isok1["{$type}"];
 if ($type==0){$type1=1;}elseif($type==1){$type1=0;} 
    $payid = c_newOrderNo("D");
$timestamp = strtotime($selldate);
$timestamp = $timestamp + $webconfig['order_interval'];
$lastdate = date("Y-m-d h:i:s", $timestamp);
	$data1 = array(
		'type'		=>$type1,
  'id_bigclass'		=>$id_bigclass,
 'id_smallclass'	=>$id_smallclass,
        'price'		=>$price,
		'price1'	=>$price,
        'selldate'	=>$selldate,
		'wanglai'	=>$wanglai,
		'yuangong'	=>$yuangong,
		'xiangmu'	=>$xiangmu,
		'beizhu'	=>$beizhu1,
		'img'		=>$img,
		'moneyID'	=>$moneyID,
		'lastdate'	=>$lastdate,
		'payid'	    =>$moneyID,
		'id_login'	=>$id_login,
        'login'		=>$login,
		'isok'		=>$isok,
		'addtime'	=>$addtime
	);
$dok = $con->add("money_pay",$data1);
LYG::writeLog("[".$_SESSION['eptime_username']."]添加单号[".$moneyID."]同时产生应收付");
}
LYG::writeLog("[".$_SESSION['eptime_username']."]添加单号[".$moneyID."]");
		LYG::ShowMsg('添加成功','money_list.php');
	}else{
		LYG::ShowMsg('添加失败，请重试');
	}
	
	die();
}




?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>收支记账</title>
<link href="style/css/css.css" rel="stylesheet" type="text/css" />
<script type="text/javascript" src="js/My97DatePicker/WdatePicker.js"></script>
<script type="text/javascript" src="js/jquery.min.js"></script>
<script type="text/javascript" src="js/common.js"></script>
<script type="text/javascript">
$(function(){
    $("#type").change(function(){
        var id = parseInt($(this).val());

            $.ajax({
                type:'get',
                url:'json.php?act=getbigclass&type='+id,
                dataType:'json',
                success:function(data){
                    var html="<option value=''>请选择</option>";
                    for(var i=0;i<data.length;i++){
                        html+="<option value='"+data[i].id+"'>"+data[i].bigclass+"</option>";
                    }
                    $("#id_bigclass").html(html);
                },
                complete:function(XMLHttpRequest,textStatus){},
                error:function(){}
            });

    });

    $("#id_bigclass").change(function(){
        var id = parseInt($(this).val());

            $.ajax({
                type:'get',
                url:'json.php?act=getsmallclass&id_bigclass='+id,
                dataType:'json',
                success:function(data){
                    var html="";
                    for(var i=0;i<data.length;i++){
                        html+="<option value='"+data[i].id+"'>"+data[i].smallclass+"</option>";
                    }
                    $("#id_smallclass").html(html);
                },
                complete:function(XMLHttpRequest,textStatus){},
                error:function(){}
            });

    });
	
});
function setmethod(tag){
	$("#actionmethod").val(tag);
	if(tag=="output"){
		$("#searchform").attr("target","_blank");
	}else{
		$("#searchform").removeAttr("target");
	}
}
</script>


		<link rel="stylesheet" href="kindeditor/themes/default/default.css" />
		<script src="kindeditor/kindeditor-all.js" charset="UTF-8"></script>
		<script src="kindeditor/lang/zh-CN.js" charset="UTF-8"></script>
		<script>
			KindEditor.ready(function(K) {
				var editor = K.editor({
					allowFileManager : true
				});
				K('#image3').click(function() {
					editor.loadPlugin('image', function() {
						editor.plugin.imageDialog({
							showRemote : false,
							imageUrl : K('#url3').val(),
							clickFn : function(url, title, width, height, border, align) {
								K('#url3').val(url);
								editor.hideDialog();
							}
						});
					});
				});
			});
		</script>
</head>

<body class="content">

<SCRIPT language=javascript>
function check()
{
	
if (document.form3.type.value=="")
{
alert("类型必须选择！");
return false;
}
if (document.form3.id_bigclass.value=="")
{
alert("一级分类必须填写，如没有，请先添加！");
return false;
}
if (document.form3.id_smallclass.value=="")
{
alert("二级分类必须填写，如没有，请先添加！");
return false;
}
if (document.form3.price.value=="")
{
alert("金额必须填写！");
return false;
}

if (document.form3.zhanghu.value=="")
{
alert("账户必须填写，请选择！如没有，请先添加！");
return false;
}
if (document.form3.wanglai.value=="")
{
alert("<?php echo $webconfig['system_wanglai'];?>必须填写，请选择！如没有，请先添加！");
return false;
}
if (document.form3.yuangong.value=="")
{
alert("<?php echo $webconfig['system_yuangong'];?>必须填写，请选择！如没有，请先添加！");
return false;
}
if (document.form3.xiangmu.value=="")
{
alert("<?php echo $webconfig['system_xiangmu'];?>必须填写，请选择！如没有，请先添加！");
return false;
}

}
</script>

<h5 class='back' onclick='history.go(-1);'><span>返回</span></h5>

<form action='' method='post' name="form3">
	<table cellpadding="3" cellspacing="0" class="table-add">

		<tr>
			<td align="right" width='100' height='36'>类型：</td>
			<td align="left" width='*'>
			<select name="type" class="select" id="type">
			<option value=''>请选择</option>
			<?php 
			foreach($c_type as $k=>$v){
						echo "<option value='{$k}'>{$v}</option>";
			}?>
			</select>	
			</td>
		</tr>

		<tr>
			<td align="right" height='36'>一级分类：</td>
			<td>
			
				<select name="id_bigclass" class="select" id="id_bigclass">
				</select>
			</td>
		</tr>

		<tr>
			<td align="right" height='36'>二级分类：</td>
			<td>
				<select name="id_smallclass" class="select" id="id_smallclass">
				</select>
			</td>
		</tr>

		<tr>
			<td align="right" height='36'>金额：</td>
			<td>
			<input class='inp' type='number' name='price' placeholder="0.00" step="0.01" />
			<span>数字，请保留小数点后两位</span>
			</td>
		</tr>
		<tr>
			<td align="right" height='36'>时间：</td>
			<td>
			<input type='text' class='inp' name='selldate' value='<?php echo date("Y-m-d",time()) ?>' placeholder="0000-00-00" onclick="WdatePicker();" />
			<span>点击选择</span>
			</td>
		</tr>
		<tr>
			<td align="right" height='36'>资金账户：</td>
			<td align="left" width='*'>
				<select name="zhanghu" class="select">
				<?php
				foreach(c_classinfo("zhanghu") as $k=>$v){
if(intval($_SESSION['eptime_l_zhanghu'])===intval($v['id'])){echo "<option value='{$v['id']}' selected='selected'>{$v['name']}</option>";}
else{echo "<option value='{$v['id']}'>{$v['name']}</option>";}
				}
				?>
				</select>
			</td>
		</tr>



		<tr>
			<td align="right" height='36'><?php echo $webconfig['system_wanglai'];?>：</td>
			<td align="left" width='*'>
			<select name="wanglai" class="select"><option value='0'>可不选择</option>
				<?php
				foreach(c_classinfo("wanglai") as $k=>$v){
if(intval($_SESSION['eptime_l_wanglai'])===intval($v['id'])){echo "<option value='{$v['id']}' selected='selected'>{$v['name']}</option>";}
else{echo "<option value='{$v['id']}'>{$v['name']}</option>";}
				}
				?>
				</select>
			</td>
		</tr>
		<tr>
			<td align="right" height='36'><?php echo $webconfig['system_yuangong'];?>：</td>
			<td align="left" width='*'>
			<select name="yuangong" class="select"><option value='0'>可不选择</option>
				<?php
				foreach(c_classinfo("yuangong") as $k=>$v){
if(intval($_SESSION['eptime_l_yuangong'])===intval($v['id'])){echo "<option value='{$v['id']}' selected='selected'>{$v['name']}</option>";}
else{echo "<option value='{$v['id']}'>{$v['name']}</option>";}
				}
				?>
				</select>
			</td>
		</tr>
		<tr>
			<td align="right" height='36'><?php echo $webconfig['system_xiangmu'];?>：</td>
			<td align="left" width='*'>
			<select name="xiangmu" class="select"><option value='0'>可不选择</option>
				<?php
				foreach(c_classinfo("xiangmu") as $k=>$v){
if(intval($_SESSION['eptime_l_xiangmu'])===intval($v['id'])){echo "<option value='{$v['id']}' selected='selected'>{$v['name']}</option>";}
else{echo "<option value='{$v['id']}'>{$v['name']}</option>";}
				}
				?>
				</select>
			</td>
		</tr>

	<tr>
		<td align="right" height='36'>备注：</td>
		<td align="left"><textarea name="beizhu" cols="60" rows="3"  onKeyup="if(this.value.length>255){this.value=this.value.slice(0,255)}"></textarea></td>
	</tr>
	<tr>
		<td align="right" height='36'>附件：</td>
		<td align="left"><input type='text' class='inp' name='img' placeholder='' id="url3"/><input type="button" id="image3" value="选择图片" /></td>
	</tr>






		<tr>
			<td align="right" height='50'>　</td>
			<td align="left"><input class='sub' type='submit' value='添加' onClick="return check()"/></td>
		</tr>

	</table>
</form>

</body>
</html>