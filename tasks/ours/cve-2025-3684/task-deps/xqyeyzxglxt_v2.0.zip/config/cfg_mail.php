<?php
return array (
  'type' => 'server',
  'server_mail' => '',
  'server_key' => '',
  'server_url' => '',
  'server_ver' => '2.0',
);