<?php
require_once(dirname(__FILE__).'/include/common.php');
if (strpos($_SESSION['eptime_flag'], 'kucunlfig') === false) {LYG::ShowMsg('您没有权限！');} 

if(empty($_REQUEST['type']) || intval($_REQUEST['type'])<0){lyg::showmsg('参数错误');}
$data_id = intval($_REQUEST['type']);

$_k = "and #__kucunlog.type=".$data_id;
$_v = array();

$_c = array();//分页条件
$_s = array();//搜索条件


if(!empty($_GET['type']) && intval($_GET['type'])>0){
    $_k=$_k." and #__kucunlog.type=".intval($_GET['type']);
    $_c[]="type=".intval($_GET['type']);
    $_s['type'] = intval($_GET['type']);
}

if(!empty($_GET['cangku']) && intval($_GET['cangku'])>0){
    $_k=$_k." and #__kucunlog.cangku=".intval($_GET['cangku']);
    $_c[]="cangku=".intval($_GET['cangku']);
    $_s['cangku'] = intval($_GET['cangku']);
}

if(!empty($_GET['fenlei']) && intval($_GET['fenlei'])>0){
    $_k=$_k." and #__shangpin.fenlei=".intval($_GET['fenlei']);
    $_c[]="fenlei=".intval($_GET['fenlei']);
    $_s['fenlei'] = intval($_GET['fenlei']);
}

if(!empty($_GET['yuangong']) && intval($_GET['yuangong'])>0){
    $_k=$_k." and #__kucunlog.yuangong=".intval($_GET['yuangong']);
    $_c[]="yuangong=".intval($_GET['yuangong']);
    $_s['yuangong'] = intval($_GET['yuangong']);
}

if(!empty($_GET['keywords']) && trim($_GET['keywords'])!=''){
    $_k=$_k." and (#__shangpin.name like '%".trim($_GET['keywords'])."%' or #__shangpin.bianhao like '%".trim($_GET['keywords'])."%' or #__shangpin.xinghao like '%".trim($_GET['keywords'])."%' or #__kucunlog.beizhu like '%".trim($_GET['keywords'])."%')";
    $_c[]="keywords=".trim($_GET['keywords']);
    $_s['keywords'] = trim($_GET['keywords']);
}

if($_k!=''){
    $_k = " where 1=1 ".$_k;
}

$field = array(
	"#__kucunlog.*",
	"#__shangpin.name,bianhao,fenlei,xinghao,danwei"
);
$field = implode(",",$field);
$left = "left join #__shangpin on #__shangpin.id=#__kucunlog.shangpinid ";


$action="search";
if(!empty($_GET['action']) && $_GET['action']=='output'){
	require_once(dirname(__FILE__).'/include/PHPExcel/PHPExcel.php');
	$sql = "select {$field} from #__kucunlog {$left} {$_k} order by #__kucunlog.id desc,#__kucunlog.isok desc";
	$data = $con->select($sql);
	require_once("output.php");
	die();
}

$sqla = "select {$field} from #__kucunlog {$left} {$_k} order by #__kucunlog.id desc,#__kucunlog.isok desc";
$dataa = $con->select($sqla);
$nowprice1=0;
$nowprice2=0;
foreach($dataa as $k=>$v){
$nowprice1=$nowprice1+$v['shuliang'];
$nowprice2=$nowprice2+$v['price']*$v['shuliang'];
                        }


if($webconfig['eptime_pagesize']){$pagesize=$webconfig['eptime_pagesize'];}else{$pagesize = 20;}

$datacount=$con->RowsCount("select count(#__kucunlog.id) from #__kucunlog {$left} {$_k}");

$totalpages=LYG::getTotalPage($datacount,$pagesize);
$page=1;
if(!empty($_GET['p']) && intval($_GET['p'])>0){
	$page=intval($_GET['p']);
	$page=$page>$totalpages?$totalpages:$page;
	if($page+1<=1){$page=1;}
}
$start_id=($page-1)*$pagesize;

$sql = "select {$field} from #__kucunlog {$left} {$_k} order by #__kucunlog.id desc,#__kucunlog.isok desc limit {$start_id},{$pagesize}";
$data =$con->select($sql);
$fenye = LYG::getPageHtml($page,$datacount,$pagesize,$_c);

?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title></title>
<link href="style/css/css.css" rel="stylesheet" type="text/css" />
<link href="style/css/font-awesome.min.css" rel="stylesheet" type="text/css" />
<script type="text/javascript" src="js/jquery.min.js"></script>
<script type="text/javascript" src="js/common.js"></script>
<script type="text/javascript">
function search(obj){
	document.searchform.submit();
}
$(function(){
	$("input.sort").blur(function(){
		
		var sort = parseInt($(this).val());
		if(isNaN(sort)){
			sort = 100;
		}
		if(sort == parseInt(this.defaultValue)){
			return;
		}
		
		var id = $(this).parent().parent().attr("data-id");
		
		$.post("json.php",{"act":"shangpinsort","id":id,"sort":sort},function(e){
			location.reload();
		},"json");
	});
});
</script>
</head>

<body class="content">

<div class="searchform">
    <form method="get" name="searchform">
	<input type='hidden' name='type' value='<?php echo $data_id;?>'>
	<table>
		<tr>
		    <td width="*" align="right"></td>
			<td width="200" align="right">
			<select name="cangku" class="select bai" onchange="search(this);">
				<option value='0'>所有仓库</option>
           <?php
			foreach (c_classinfo("cangku") as $k => $v) {
				if(array_key_exists('cangku', $_s) && intval($_s['cangku'])===intval($v['id'])){
					echo "<option value='{$v['id']}' selected='selected'>{$v['name']}</option>";
				}else{
					echo "<option value='{$v['id']}'>{$v['name']}</option>";    
				}                    
			}
			?>
            </select>
			</td>
			<td width="200" align="right">
			<select name="fenlei" class="select bai" onchange="search(this);">
				<option value='0'>所有商品分类</option>
           <?php
			foreach (c_classinfo("fenlei") as $k => $v) {
				if(array_key_exists('fenlei', $_s) && intval($_s['fenlei'])===intval($v['id'])){
					echo "<option value='{$v['id']}' selected='selected'>{$v['name']}</option>";
				}else{
					echo "<option value='{$v['id']}'>{$v['name']}</option>";    
				}                    
			}
			?></select>
			</td>
			<td width="200" align="right">
				<select name="yuangong" class="select bai" onchange="search(this);">
					<option value='0'>所有经办人</option><?php
					foreach(c_classinfo("yuangong") as $k=>$v){
						if(array_key_exists('yuangong', $_s) && intval($_s['yuangong'])===intval($v['id'])){
							echo "<option value='{$v['id']}' selected='selected'>{$v['name']}</option>";
						}else{
							echo "<option value='{$v['id']}'>{$v['name']}</option>";    
						}
					}
					?>
				</select>
			</td>
			<td width="60" align="right">关键词:</td>
			<td width="180">
				<input type="text" name="keywords" class="text" placeholder='编号、名称、规格型号或备注' value="<?php 
					if(array_key_exists("keywords",$_s)){
						echo $_s['keywords'];
					}
				?>">
			</td>
			
			<td width="80" align="right">
<input type="submit" onclick="setmethod('search');" value="查询" class="sub">
			</td>
		</tr>
	</table>
    </form>
	<table>
		<tr>
		<td width="*" align="right"></td>
			<td width="80%" align="right">
			总数量：<b><?php echo $nowprice1;?></b> ，总价值：<b><?php echo $nowprice2;?></b> 元&nbsp;
			</td>
			</tr>
	</table>
</div>

<table cellpadding="3" cellspacing="0">
	<thead>
    	<tr>
            <th>ID</th>
			<th>单号</th>
            <th>仓库</th>
			<th>商品分类</th>
            <th>商品编号</th>
			<th>商品名称</th>
            <th>规格型号</th>
            <th>单位</th>
			<th>数量</th>
			<th>单价</th>
			<th>价值</th>
			<th>备注</th>
			<th>时间</th>
			<th>经办人</th>
        </tr>
    </thead>
    <tbody>
	<?php foreach($data as $k=>$v){?>
    	<tr class='list' data-id="<?php echo $v['id'];?>">
        	<td align="center"><?php echo $v['id'];?></td>
			<td align="center"><?php echo $v['danhao'];?></td>
			<td align="center"><?php if($data_id==1){echo "-->";}?> <?php echo c_classname('cangku',$v['cangku']);?> <?php if($data_id==3){echo "-->";}?> <?php echo c_classname('cangku',$v['cangku1']);?><?php  if($data_id==2){echo "-->";}?></td>
			<td align="center"><?php echo c_classname('fenlei',$v['fenlei']);?></td>
        	<td align="center"><?php echo $v['bianhao'];?></td>
			<td align="center"><?php echo $v['name'];?></td>
			<td align="center"><?php echo $v['xinghao'];?></td>
			<td align="center"><?php echo $v['danwei'];?></td>
			<td align="center"><?php echo $v['shuliang'];?></td>
        	<td align="center"><?php echo round($v['price'],2);?></td>
        	<td align="center"><?php echo round($v['shuliang']*$v['price'],2);?></td>
        	<td align="center"><?php echo $v['beizhu'];?></td>
			<td align="center"><?php echo $v['addtime'];?></td>
			<td align="center"><?php echo c_classname("yuangong",$v['yuangong']);?></td>
        </tr>
	<?php }?>
    </tbody>
    <tfoot>
    	<tr>
        	<td colspan="14" style="padding-left:30px;">
			<?php echo $fenye ;?>
			</td>
        </tr>
    </tfoot>
</table>


</body>
</html>