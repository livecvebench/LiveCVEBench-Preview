<?php

$plugin_mcf['hi_updatecheck']['autocheck']="bool";
$plugin_mcf['hi_updatecheck']['autocheck_timeout']="string";
$plugin_mcf['hi_updatecheck']['autocheck_notify']="enum:All updates,Only critical updates";
$plugin_mcf['hi_updatecheck']['ignore']="string";
$plugin_mcf['hi_updatecheck']['curl_connect_timeout']="hidden";
$plugin_mcf['hi_updatecheck']['curl_maxredir']="hidden";
