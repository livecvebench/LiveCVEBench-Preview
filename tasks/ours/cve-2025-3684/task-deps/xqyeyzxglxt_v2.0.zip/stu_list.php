<?php

require_once(dirname(__FILE__).'/include/common.php');
if (strpos($_SESSION['eptime_flag'], 'stulfig') === false) {LYG::ShowMsg('您没有权限！');}

$_k = "";
$_v = array();

$_c = array();//分页条件
$_s = array();//搜索条件

if(!empty($_GET['banji']) && intval($_GET['banji'])>0){
    $_k=$_k." and #__wanglai.banji=".intval($_GET['banji']);
    $_c[]="banji=".intval($_GET['banji']);
    $_s['banji'] = intval($_GET['banji']);
}
if(!empty($_GET['isok']) && intval($_GET['isok'])>0){
    $_k=$_k." and #__wanglai.isok=".intval($_GET['isok']);
    $_c[]="isok=".intval($_GET['isok']);
    $_s['isok'] = intval($_GET['isok']);
}

if(!empty($_GET['sex'])){
    $_k=$_k." and #__wanglai.sex='".trim($_GET['sex'])."'";
    $_c[]="sex='".trim($_GET['sex'])."'";
    $_s['sex'] = trim($_GET['sex']);
}
if(!empty($_GET['nation'])){
    $_k=$_k." and #__wanglai.nation='".trim($_GET['nation'])."'";
    $_c[]="nation='".trim($_GET['nation'])."'";
    $_s['nation'] = trim($_GET['nation']);
}

if(!empty($_GET['keywords']) && trim($_GET['keywords'])!=''){
    $_k=$_k." and (#__wanglai.name like '%".trim($_GET['keywords'])."%' or #__wanglai.bianhao like '%".trim($_GET['keywords'])."%' or #__jiaz.name like '%".trim($_GET['keywords'])."%' or #__jiaz.mobile like '%".trim($_GET['keywords'])."%' or #__wanglai.beizhu like '%".trim($_GET['keywords'])."%')";
    $_c[]="keywords=".trim($_GET['keywords']);
    $_s['keywords'] = trim($_GET['keywords']);
}

if(!empty($_GET['time0']) && !empty($_GET['time1']) && 
    preg_match("/^\d{4}\-\d{2}\-\d{2}$/",$_GET['time0']) && preg_match("/^\d{4}\-\d{2}\-\d{2}$/",$_GET['time1'])
){
    $time0 = $_GET['time0'];
    $time1 = $_GET['time1'];
    $t0 = strtotime($time0." 00:00:00");
    $t1 = strtotime($time1." 23:59:59");
    if($t0!==false && $t1!==false && $t1>$t0){

        $_k=$_k." and UNIX_TIMESTAMP(#__wanglai.shengri)>=".$t0;
        $_c[]="time0=$time0";
        $_s['time0'] = $time0;

        $_k=$_k." and UNIX_TIMESTAMP(#__wanglai.shengri)<=".$t1;
        $_c[]="time1=$time1";
        $_s['time1'] = $time1;
    }
}

if(!empty($_GET['time00']) && !empty($_GET['time11']) && 
    preg_match("/^\d{4}\-\d{2}\-\d{2}$/",$_GET['time00']) && preg_match("/^\d{4}\-\d{2}\-\d{2}$/",$_GET['time11'])
){
    $time00 = $_GET['time00'];
    $time11 = $_GET['time11'];
    $t00 = strtotime($time00." 00:00:00");
    $t11 = strtotime($time11." 23:59:59");
    if($t00!==false && $t11!==false && $t11>$t00){

        $_k=$_k." and UNIX_TIMESTAMP(#__wanglai.ruzhi)>=".$t00;
        $_c[]="time00=$time00";
        $_s['time00'] = $time00;

        $_k=$_k." and UNIX_TIMESTAMP(#__wanglai.ruzhi)<=".$t11;
        $_c[]="time11=$time11";
        $_s['time11'] = $time11;
    }
}

if($_k!=''){
    $_k = " where 1=1 ".$_k;
}

$field = array(
	"#__wanglai.*"
);
$field = implode(",",$field);
$left = "left join #__jiaz on #__jiaz.stuid=#__wanglai.id ";


$action="search";
if(!empty($_GET['action']) && $_GET['action']=='output'){
	require_once(dirname(__FILE__).'/include/PHPExcel/PHPExcel.php');
	$sql = "select  {$field} from #__wanglai {$left} {$_k} group  by #__wanglai.id desc,#__wanglai.isok desc";
	$data = $con->select($sql);
	require_once("outputs.php");
	die();
}

if($webconfig['eptime_pagesize']){$pagesize=$webconfig['eptime_pagesize'];}else{$pagesize = 20;}

$datacount=$con->RowsCount("select count(#__wanglai.id) from #__wanglai {$_k} ");

$totalpages=LYG::getTotalPage($datacount,$pagesize);
$page=1;
if(!empty($_GET['p']) && intval($_GET['p'])>0){
	$page=intval($_GET['p']);
	$page=$page>$totalpages?$totalpages:$page;
	if($page+1<=1){$page=1;}
}
$start_id=($page-1)*$pagesize;

$sql = "select  {$field} from #__wanglai {$left} {$_k} group  by #__wanglai.id desc,#__wanglai.isok desc limit {$start_id},{$pagesize}";
$data =$con->select($sql);
$fenye = LYG::getPageHtml($page,$datacount,$pagesize,$_c);










if(trim($_GET['shenhe'])=="ok"){$eok = $con->Update("update #__wanglai set isok=isok+1 where id={$_GET['id']}");echo "<script>window.history.go(-1);</script>";}
if(trim($_GET['shenhe'])=="kk"){$eok = $con->Update("update #__wanglai set isok=1 where id={$_GET['id']}");echo "<script>window.history.go(-1); </script>";}



	
function getAge($birthday) {
$age = 0;
$year = $month = $day = 0;

if (is_array($birthday)) {
extract($birthday);
} else {
if (strpos($birthday, '-') !== false) {
list($year, $month, $day) = explode('-', $birthday);
$day = substr($day, 0, 2); //get the first two chars in case of '2000-11-03 12:12:00'
}
}

$age = date('Y') - $year;
if (date('m') < $month || (date('m') == $month && date('d') < $day)) $age--;
return $age;
}


function getXuefei($stuid){
	global $con;
        $_now =strtotime(date("Y-m-d 00:00:00"));
        $sql = "select count(*) from #__fei where stuid={$stuid} and price>=0 and UNIX_TIMESTAMP(begindate) <= {$_now} and UNIX_TIMESTAMP(enddate) >= {$_now} and name like '%学费%' ";
		$sl = $con->RowsCount($sql);
		if($sl>0){ return "<font color=green>已缴费</font>";}
		if($sl<=0){ return "<font color=red>未缴费</font>";}

}

function getXuefei1($stuid){
	global $con;
        $_now =strtotime(date("Y-m-d 00:00:00"));
        $sql = "select count(*) from #__fei where stuid={$stuid} and price>=0 and UNIX_TIMESTAMP(begindate) <= {$_now} and UNIX_TIMESTAMP(enddate) >= {$_now} and name like '%学费%' ";
		$sl = $con->RowsCount($sql);
		if($sl>0){ return "已缴费";}
		if($sl<=0){ return "未缴费";}

}


function getjiaz($stuid){
	global $con;
        $sql = "select * from #__jiaz where stuid={$stuid}";
		$ss = $con->select($sql);
		$sss="";$ssss=1;
foreach ($ss as $k => $v) {
		$sss=$sss.$ssss.".".$v['gx'].":".$v['name']." 电话:".$v['mobile']." 身份证:".$v['cardno']." 地址:".$v['address']." 备注:".$v['beizhu'];
		$ssss=$ssss+1;
		}
		return $sss;
}

$info=  $con->select("select * from #__jiaz where stuid=$dataid order by id");
?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>幼儿档案管理</title>
<link href="style/css/css.css" rel="stylesheet" type="text/css" />
<link href="style/css/font-awesome.min.css" rel="stylesheet" type="text/css" />
<script type="text/javascript" src="js/My97DatePicker/WdatePicker.js"></script>
<script type="text/javascript" src="js/jquery.min.js"></script>
<script type="text/javascript" src="js/common.js"></script>
<SCRIPT language=javascript> 
function openScript(url, width, height) {
        var Win = window.open(url,"openScript",'width=' + width + ',height=' + 
 
height + ',resizable=0,scrollbars=no,menubar=no,status=no' );
}
</SCRIPT>
<script type="text/javascript">
function search(obj){
	document.searchform.submit();
}
$(function(){
	$("input.sort").blur(function(){
		
		var sort = parseInt($(this).val());
		if(isNaN(sort)){
			sort = 100;
		}
		if(sort == parseInt(this.defaultValue)){
			return;
		}
		
		var id = $(this).parent().parent().attr("data-id");
		
		$.post("json.php",{"act":"shangpinsort","id":id,"sort":sort},function(e){
			location.reload();
		},"json");
	});
});
</script>
<script type="text/javascript">
function setmethod(tag){
	$("#actionmethod").val(tag);
	if(tag=="output"){
		$("#searchform").attr("target","_blank");
	}else{
		$("#searchform").removeAttr("target");
	}
}
</script>
</head>

<body class="content">
<div class="searchform">
    <form method="get" name="searchform"  target="_self">
	<input type="hidden" id="actionmethod" name="action" value="search">
	<table>
		<tr>
		    <td width="*" align="right">生日</td>
			<td width="100" align="right">
				<input type="text" name="time0" class="text"  onclick="WdatePicker();" value="<?php 
					if(array_key_exists("time0",$_s)){
						echo $_s['time0'];
					}
				?>">
			</td>
			<td width="20" align="center">至</td>
			<td width="100">
				<input type="text" name="time1" class="text"  onclick="WdatePicker();" value="<?php 
					if(array_key_exists("time1",$_s)){
						echo $_s['time1'];
					}
				?>">
			</td>
				<td width='80'>
			<select name="sex" class="select" id="sex" onchange="search(this);">
			<option value='0'>所有性别</option>
			<?php 
			foreach($c_sex as $k=>$v){

						if(array_key_exists('sex', $_s) && trim($_s['sex'])===trim($v)){
							echo "<option value='{$k}' selected='selected'>{$v}</option>";
						}else{
							echo "<option value='{$k}'>{$v}</option>";    
						}
			}?>
			</select></td>
			   <td width='100'>
			<select name="nation" class="select" id="nation" onchange="search(this);">
			<option value='0'>所有民族</option>
			<?php 
			foreach($c_nation as $k=>$v){
						if(array_key_exists('nation', $_s) && trim($_s['nation'])===trim($v)){
							echo "<option value='{$k}' selected='selected'>{$v}</option>";
						}else{
							echo "<option value='{$k}'>{$v}</option>";    
						}
			}?>
			</select>
				</td>
			<td width="200" align="right">
				<select name="banji" class="select bai" onchange="search(this);">
					<option value='0'>所有班级</option><?php
					foreach(c_classinfo("xiangmu") as $k=>$v){
						if(array_key_exists('banji', $_s) && intval($_s['banji'])===intval($v['id'])){
							echo "<option value='{$v['id']}' selected='selected'>{$v['name']}</option>";
						}else{
							echo "<option value='{$v['id']}'>{$v['name']}</option>";    
						}
					}
					?>
				</select>
			</td>
			<td width="200" align="right">
				<select name="isok" class="select bai" onchange="search(this);">
					<option value='0'>所有状态</option><?php
					foreach($c_stuok as $k=>$v){
						if(array_key_exists('isok', $_s) && intval($_s['isok'])===intval($k)){
							echo "<option value='{$k}' selected='selected'>{$v}</option>";
						}else{
							echo "<option value='{$k}'>{$v}</option>";    
						}
					}
					?>
				</select>
			</td>
</tr>
</table>
<table>
<tr>
            <td width="*" align="right"></td>
		    <td width="80" align="right">入园时间</td>
			<td width="100" align="right">
				<input type="text" name="time00" class="text"  onclick="WdatePicker();" value="<?php 
					if(array_key_exists("time00",$_s)){
						echo $_s['time00'];
					}
				?>">
			</td>
			<td width="20" align="center">至</td>
			<td width="100">
				<input type="text" name="time11" class="text"  onclick="WdatePicker();" value="<?php 
					if(array_key_exists("time11",$_s)){
						echo $_s['time11'];
					}
				?>">
			</td>
			<td width="60" align="right">关键词:</td>
			<td width="250">
				<input type="text" name="keywords" class="text" placeholder='档案编号、姓名、家长姓名、电话或备注' value="<?php 
					if(array_key_exists("keywords",$_s)){
						echo $_s['keywords'];
					}
				?>">
			</td>
			
			<td width="80" align="right">
<input type="submit" onclick="setmethod('search');" value="查询" class="sub">
			</td>
			<td width="80" align="right">
<input type="submit" onclick="setmethod('output');" value="导出" class="reset" title="根据当前查询条件导出">
			</td>
		</tr>
	</table>
    </form>
</div>

<table cellpadding="3" cellspacing="0">
	<thead>
    	<tr>
            <th >ID</th>
			<th >档案编号</th>
			<th >照片</th>
            <th >姓名</th>
			<th >性别</th>
			<th >民族</th>
			<th >年龄</th>
<th >生日</th>
<th >所在班级</th>
<th >入园日期</th>
<th >学费收缴情况</th>
<th >状态</th>
<th >家长信息</th>
			<th >备注</th>
            <th >-</th>
        </tr>
    </thead>
    <tbody>
	<?php foreach($data as $k=>$v){?>
    	<tr class='list'>
<td align="center"><?php  echo $v['id'];?></td>
<td align="center"><a href='javascript:openScript("stu_info.php?id=<?php echo $v['id'];?>",600,690)'><?php  echo $v['bianhao'];?></a></td>
<td align="center"><a href='javascript:openScript("<?php if($v['pic']){echo $v['pic'];}else{echo "style/images/stu.jpg";}?>",400,600)'><img src="<?php if($v['pic']){echo $v['pic'];}else{echo "style/images/stu.jpg";}?>" height="40" align="middle"></a></td>
<td align="center"><?php echo $v['name'];?></td>
<td align="center"><?php  echo $v['sex'];?></td>
<td align="center"><?php  echo $v['nation'];?></td>
<td align="center"><?php echo getAge($v['shengri']);?></td>
<td align="center"><?php echo substr($v['shengri'],0,10);?></td>
<td align="center"><?php echo c_classname("xiangmu",$v['banji']);?></td>
<td align="center"><?php echo substr($v['ruzhi'],0,10);?></td>
<td align="center"><?php echo getXuefei($v['id']);?></td>
<td align="center">
<?php if($v['isok']==5){echo "<a href=?shenhe=kk&class=wanglai&id={$v['id']}>";}
else{echo "<a href=?shenhe=ok&class=wanglai&id={$v['id']}>";}?>
<font color=<?php if($v['isok']==1){echo "green";}elseif($v['isok']==2){echo "red";}else{echo "grey";}?>><?php echo $c_stuok[$v['isok']];?></font></a>
</td>
<td align="center"><a href='javascript:openScript("stu_info1.php?stuid=<?php echo $v['id'];?>",600,690)'>家长信息</a></td>
<td align="center"><?php echo $v['beizhu'];?></td>
            <td align="center">
				<a class="edit" href="stu_edit.php?id=<?php echo $v['id'];?>"><i class="fa fa-pencil-square-o"></i><span>编辑</span></a>
				<a onclick="return confirm('确定删除吗？');" class="del" href="class_del.php?id=<?php echo $v['id'];?>&class=wanglai"><i class="fa fa-close"></i><span>删除</span></a>
			</td>
        </tr>
	<?php }?>
    </tbody>
    <tfoot>
    	<tr>
        	<td colspan="16" style="padding-left:30px;">
			<?php echo $fenye ;?>
			</td>
        </tr>
    </tfoot>
</table>


</body>
</html>