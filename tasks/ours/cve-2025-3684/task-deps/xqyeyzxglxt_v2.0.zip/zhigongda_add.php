<?php
require_once(dirname(__FILE__).'/include/common.php');
if (strpos($_SESSION['eptime_flag'], 'zhiafig') === false) {LYG::ShowMsg('您没有权限！');} 

if(!empty($_POST)){
	//参数校验
	extract($_POST);

	if(empty($bianhao) || trim($bianhao)==''){
		LYG::ShowMsg('编号不能为空');
	}
	if(empty($name) || trim($name)==''){
		LYG::ShowMsg('姓名不能为空');
	}
	$bianhao= trim($bianhao);
	$name= trim($name);
$sex= trim($sex);
$nation= trim($nation);
$shengri= trim($shengri);
$gangwei= trim($gangwei);
	$banji = intval($banji);
$ruzhi= trim($ruzhi);
$zjtype= trim($zjtype);
$zjno= trim($zjno);
$tel= trim($tel);
	$address= trim($address);
    $beizhu= trim($beizhu);
    
	$ex = $con->rowscount("select count(*) from #__yuangong where bianhao=?",array($bianhao));
	if($ex>0){
		lyg::showmsg("已存在");
	}
	
		$data = array(
		    'bianhao'=>$bianhao,
            'name'	=>$name,
			'sex'	=>$sex,
			'nation'=>$nation,
			'shengri'=>$shengri,
			'gangwei'=>$gangwei,
			'banji'	=>$banji,
			'ruzhi'	=>$ruzhi,
			'zjtype'=>$zjtype,
			'zjno'	=>$zjno,
			'tel'	=>$tel,
			'address'=>$address,
		    'beizhu'=>$beizhu
	);


	
	$aok = $con->add("yuangong",$data);

	if($aok){
		LYG::ShowMsg('添加成功','zhigongda_list.php');
	}else{
		LYG::ShowMsg('添加失败，请重试');
	}
	
	die();
}
$classes = $con->select("select * from #__gangwei");	
?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>添加</title>
<link href="style/css/css.css" rel="stylesheet" type="text/css" />
<script type="text/javascript" src="js/My97DatePicker/WdatePicker.js"></script>
<script type="text/javascript" src="js/jquery.min.js"></script>
<script type="text/javascript" src="js/common.js"></script>
</head>

<body class="content">


<form action='' method='post'>
	<table cellpadding="3" cellspacing="0" class="table-add">
		<tbody>
			<tr>
				<td align="right" width='100' height='36'>教工编号：</td>
				<td align="left" width='*'>
					<input type='text' class='inp' name='bianhao' placeholder=''/>
				</td>
			</tr>
			<tr>
				<td align="right" width='100' height='36'>教工姓名：</td>
				<td align="left" width='*'>
					<input type='text' class='inp' name='name' placeholder=''/>
				</td>
			</tr>
			<tr>
				<td align="right" width='100' height='36'>教工性别：</td>
				<td align="left" width='*'>
			<select name="sex" class="select" id="sex">
			<?php 
			foreach($c_sex as $k=>$v){
						echo "<option value='{$k}'>{$v}</option>";
			}?>
			</select>	民族：<select name="nation" class="select" id="nation">
			<?php 
			foreach($c_nation as $k=>$v){
						echo "<option value='{$k}'>{$v}</option>";
			}?>
			</select>
				</td>
			</tr>
			<tr>
				<td align="right" width='100' height='36'>教工生日：</td>
				<td align="left" width='*'>
					<input type='text' class='inp' name='shengri' placeholder="0000-00-00" onclick="WdatePicker();" />
				</td>
			</tr>
			<tr>
				<td align="right" width='100' height='36'>任职岗位：</td>
				<td align="left" width='*'>
			<select name="gangwei" class="select" onchange="search(this);">
			<?php
			foreach ($classes as $k => $v) {
					echo "<option value='{$v['name']}'>{$v['name']}</option>";    
			}
			?></select> <a href="base.php?base=gangwei">+</a> 所在班级：
			<select name="banji" class="select">
				<?php
				foreach(c_classinfo("xiangmu") as $k=>$v){
if(intval($_SESSION['eptime_l_xiangmu'])===intval($v['id'])){echo "<option value='{$v['id']}' selected='selected'>{$v['name']}</option>";}
else{echo "<option value='{$v['id']}'>{$v['name']}</option>";}
				}
				?>
				</select> 
				</td>
			</tr>

			<tr>
				<td align="right" width='100' height='36'>入职日期：</td>
				<td align="left" width='*'>
					<input type='text' class='inp' name='ruzhi' placeholder="0000-00-00" onclick="WdatePicker();" />
				</td>
			</tr>

			<tr>
				<td align="right" width='100' height='36'>证件类型：</td>
				<td align="left" width='*'>
			<select name="zjtype" class="select" id="zjtype">
			<?php 
			foreach($c_zjtype as $k=>$v){
						echo "<option value='{$v}'>{$v}</option>";
			}?>
			</select>
				</td>
			</tr>
			<tr>
				<td align="right" width='100' height='36'>证件号码：</td>
				<td align="left" width='*'>
					<input type='text' class='inp' name='zjno' placeholder=''/>
				</td>
			</tr>
			<tr>
				<td align="right" width='100' height='36'>联系电话：</td>
				<td align="left" width='*'>
					<input type='text' class='inp' name='tel' placeholder=''/>
				</td>
			</tr>
			<tr>
				<td align="right" width='100' height='36'>联系地址：</td>
				<td align="left" width='*'>
					<input type='text' class='inp' name='address' placeholder=''/>
				</td>
			</tr>

			<tr>
				<td align="right" width='100' height='36'>备注：</td>
				<td align="left" width='*'>
					<input type='text' class='inp' name='beizhu' placeholder=''/>
				</td>
			</tr>
			<tr>
				<td align="right" height='50'>　</td>
				<td align="left"><input class='sub' type='submit' value='添加'/></td>
			</tr>
		</tbody>
	</table>
</form>

</body>
</html>