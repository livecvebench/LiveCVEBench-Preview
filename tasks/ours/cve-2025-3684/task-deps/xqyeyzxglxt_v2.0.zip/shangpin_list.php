<?php

require_once(dirname(__FILE__).'/include/common.php');
if ($_SESSION['eptime_adminPower']<>0) {LYG::ShowMsg('您没有权限！');} 
$_k = array();
$_v = array();

$_c = array();//分页条件
$_s = array();//搜索条件

if(!empty($_GET['fenlei']) && intval($_GET['fenlei'])>0){
    $_k[]="#__shangpin.fenlei=?";
    $_v[]=intval($_GET['fenlei']);
    $_c[]="fenlei=".intval($_GET['fenlei']);
    $_s['fenlei'] = intval($_GET['fenlei']);
}

$_k = implode(' and ',$_k);
if($_k!=''){
    $_k = " where ".$_k;
}



$pagesize = 20;

//总记录数
$datacount=$con->RowsCount("select count(*) from #__shangpin {$_k}",$_v);
//总页数
$totalpages=LYG::getTotalPage($datacount,$pagesize);
$page=1;
if(isset($_GET['p']) && intval($_GET['p'])>0){
	$page=intval($_GET['p']);
	$page=$page>$totalpages?$totalpages:$page;
	if($page+1<=1){$page=1;}
}
$start_id=($page-1)*$pagesize;
//查询数据
$sql = "select #__shangpin.* from #__shangpin left join #__fenlei on #__fenlei.id = #__shangpin.fenlei {$_k} order by  #__shangpin.id desc limit $start_id,$pagesize";
$data = $con->select($sql,$_v);

//得到分页HTML
$fenye=LYG::getPageHtml($page,$datacount,$pagesize);

$classes = $con->select("select * from #__fenlei");

if(trim($_GET['shenhe'])=="ok"){$eok = $con->Update("update #__shangpin set isok=1 where id={$_GET['id']}");echo "<script>window.history.go(-1); </script>";}
if(trim($_GET['shenhe'])=="kk"){$eok = $con->Update("update #__shangpin set isok=0 where id={$_GET['id']}");echo "<script>window.history.go(-1); </script>";}

?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>商品管理</title>
<link href="style/css/css.css" rel="stylesheet" type="text/css" />
<link href="style/css/font-awesome.min.css" rel="stylesheet" type="text/css" />
<script type="text/javascript" src="js/jquery.min.js"></script>
<script type="text/javascript" src="js/common.js"></script>
<script type="text/javascript">
function search(obj){
	document.searchform.submit();
}
$(function(){
	$("input.sort").blur(function(){
		
		var sort = parseInt($(this).val());
		if(isNaN(sort)){
			sort = 100;
		}
		if(sort == parseInt(this.defaultValue)){
			return;
		}
		
		var id = $(this).parent().parent().attr("data-id");
		
		$.post("json.php",{"act":"shangpinsort","id":id,"sort":sort},function(e){
			location.reload();
		},"json");
	});
});
</script>
</head>

<body class="content">


<div class="searchform">
    <form method="get" name="searchform">
	<table>
		<tr>
			<td width="80" align="left">商品分类</td>
			<td width="200">
			<select name="fenlei" class="select bai" onchange="search(this);">
				<option value='0'>不限</option>
			<?php
			foreach ($classes as $k => $v) {
				if(array_key_exists('fenlei', $_s) && intval($_s['fenlei'])===intval($v['id'])){
					echo "<option value='{$v['id']}' selected='selected'>{$v['name']}</option>";
				}else{
					echo "<option value='{$v['id']}'>{$v['name']}</option>";    
				}                    
			}
			?></select>
			</td>
			<td width="100" align="center"><li><a href="base.php?base=fenlei">+</a></li></td>
			<td width="*"></td>
		</tr>
	</table>
    </form>
</div>

<div class="list-menu">
	<ul>
		<li><a href="shangpin_add.php">添加</a></li>
	</ul>
</div>


<table cellpadding="3" cellspacing="0">
	<thead>
    	<tr>
            <th>ID</th>
            <th>商品编号</th>
			<th>商品名称</th>
            <th>商品分类</th>
            <th>规格型号</th>
            <th>单位</th>
			<th>单价</th>
			<th>备注</th>
            <th>状态</th>
            <th>-</th>
        </tr>
    </thead>
    <tbody>
	<?php foreach($data as $k=>$v){?>
    	<tr class='list' data-id="<?php echo $v['id'];?>">
        	<td align="center"><?php echo $v['id'];?></td>
        	<td align="center"><?php echo $v['bianhao'];?></td>
			<td align="center"><?php echo $v['name'];?></td>
			<td align="center"><?php echo c_classname('fenlei',$v['fenlei']);?></td>
			<td align="center"><?php echo $v['xinghao'];?></td>
			<td align="center"><?php echo $v['danwei'];?></td>
        	<td align="center"><?php echo round($v['price'],2);?></td>
        	<td align="center"><?php echo $v['beizhu'];?></td>
			<td align="center">
<?php if($v['isok']==1){echo "<a href=?shenhe=kk&id={$v['id']}><font color=green>已启用</font></a>";}else{echo "<a href=?shenhe=ok&id={$v['id']}><font color=grey>已禁用</a></a>";}?>
			</td>
            <td align="center">
				<a class="edit" href="shangpin_edit.php?id=<?php echo $v['id'];?>"><i class="fa fa-pencil-square-o"></i><span>编辑</span></a>
				<a onclick="return confirm('确定删除吗？');" class="del" href="class_del.php?id=<?php echo $v['id'];?>&class=shangpin"><i class="fa fa-close"></i><span>删除</span></a>
			</td>
        </tr>
	<?php }?>
    </tbody>
    <tfoot>
    	<tr>
        	<td colspan="10" style="padding-left:30px;">
			<?php echo $fenye ;?>
			</td>
        </tr>
    </tfoot>
</table>


</body>
</html>