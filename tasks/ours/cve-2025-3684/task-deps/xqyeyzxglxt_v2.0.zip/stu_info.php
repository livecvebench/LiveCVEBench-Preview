<?php

require_once(dirname(__FILE__).'/include/common.php');
$webconfig = lyg::readArr("web");
$check_enable = intval($webconfig['system_check'])===1?true:false;

if(empty($_REQUEST['id']) || intval($_REQUEST['id'])<1){lyg::showmsg('参数错误');}
$dataid = intval($_REQUEST['id']);
$info=  $con->find("select * from #__wanglai where id=$dataid");
if(empty($info)){lyg::showmsg('参数错误');}


$jzinfo=  $con->select("select * from #__jiaz where stuid=$dataid order by id");

	
?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>信息</title>
<link href="style/css/css.css" rel="stylesheet" type="text/css" />
<link href="style/css/font-awesome.min.css" rel="stylesheet" type="text/css" />
<link href="style/css/font-awesome.min.css" rel="stylesheet" type="text/css" />
<style type="text/css">
label{margin-right:10px;}
</style>
<script type="text/javascript" src="js/My97DatePicker/WdatePicker.js"></script>
<script type="text/javascript" src="js/jquery.min.js"></script>
<script type="text/javascript" src="js/common.js"></script>
		<link rel="stylesheet" href="kindeditor/themes/default/default.css" />
		<script src="kindeditor/kindeditor-all.js" charset="UTF-8"></script>
		<script src="kindeditor/lang/zh-CN.js" charset="UTF-8"></script>
		<script>
			KindEditor.ready(function(K) {
				var editor = K.editor({
					allowFileManager : true
				});
				K('#image3').click(function() {
					editor.loadPlugin('image', function() {
						editor.plugin.imageDialog({
							showRemote : false,
							imageUrl : K('#url3').val(),
							clickFn : function(url, title, width, height, border, align) {
								K('#url3').val(url);
								editor.hideDialog();
							}
						});
					});
				});
			});
		</script>

</head>


<body class="content">
<style type="text/css">
@media print { 
 .noprint{display:none;}
}
</style>
<div align="right" class="noprint">
<a href='javascript:window.print()'>打印此页</a>
</div>


<h5 class='title'><span><?php echo $webconfig['system_name'];?>档案信息表</span></h5>

<div class="list-menu">
	<ul>
		<li>基本信息</li>
	</ul>
</div>

<table cellpadding="3" cellspacing="0" class="table-add">

  <tr>
    <td align="right" height='36' width="100px">幼儿编号：</td>
    <td><?php echo $info['bianhao'];?></td>
    <td align="right" height='36' width="100px">幼儿姓名：</td>
    <td><?php echo $info['name'];?></td>
    <td  rowspan="4" align="center"><img src="<?php if($info['pic']){echo $info['pic'];}else{echo "style/images/stu.jpg";}?>" width="160" align="middle"></td>
  </tr>
  <tr>
    <td align="right">幼儿性别：</td>
    <td><?php echo $info['sex'];?></td>
    <td align="right">民族：</td>
    <td><?php echo $info['nation'];?></td>
  </tr>
  <tr>
    <td align="right">幼儿生日：</td>
    <td><?php echo substr($info['shengri'],0,10);?></td>
    <td align="right">幼儿状态：</td>
    <td><?php echo $c_stuok["{$info['isok']}"];?></td>
  </tr>
  <tr>
    <td align="right">所在班级：</td>
    <td><?php echo c_classname("xiangmu",$info['banji']);?></td>
    <td align="right">入园日期：</td>
    <td><?php echo substr($info['ruzhi'],0,10);?></td>
  </tr>
  <tr>
    <td align="right">身份证号：</td>
    <td colspan="4"><?php echo $info['zjno'];?></td>
  </tr>
  <tr>
    <td align="right">家庭地址：</td>
    <td colspan="4"><?php echo $info['address'];?></td>
  </tr>
  <tr>
    <td align="right">备注信息：</td>
    <td colspan="4"><?php echo $info['beizhu'];?></td>
  </tr>
</table>


<div class="list-menu">
	<ul>
		<li>家长信息</li>
	</ul>
</div>
<?php
foreach ($jzinfo as $k => $v) {
?>
<table cellpadding="3" cellspacing="0" class="table-add">
		<tr>
			<td align="right" height='36' width="100px">关系：</td>
			<td>
			<?php echo $v['gx'];?>
			</td>
		</tr>
		<tr>
			<td align="right" height='36'>姓名：</td>
			<td>
			<?php echo $v['name'];?>
			</td>
		</tr>
		<tr>
			<td align="right" height='36'>电话：</td>
			<td>
			<?php echo $v['mobile'];?>
			</td>
		</tr>
		<tr>
			<td align="right" height='36'>身份证号码：</td>
			<td>
			<?php echo $v['cardno'];?>
			</td>
		</tr>

		<tr>
			<td align="right" height='36'>地址：</td>
			<td>
			<?php echo $v['address'];?>
			</td>
		</tr>


	<tr>
		<td align="right" height='36'>备注：</td>
		<td align="left"><?php echo $v['beizhu'];?></td>
	</tr>
</table><br>
 <?php                 
}
?>





</body>
</html>