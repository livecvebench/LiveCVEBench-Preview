<?php
require_once(dirname(__FILE__).'/include/common.php');
if (strpos($_SESSION['eptime_flag'], 'feiafig') === false) {LYG::ShowMsg('您没有权限！');}

$webconfig = lyg::readArr("web");
$check_enable = intval($webconfig['system_check'])===1?true:false;
	
if(!empty($_POST)){
	//参数校验
	extract($_POST);

	if(empty($stuid) || trim($stuid)==''){
		LYG::ShowMsg('姓名不能为空');
	}

preg_match_all('/(?<=\[)([^\]]*?)(?=\])/' , $stuid , $ary);
$stuid1 = $ary[0][0] ;
$fangshi=trim($fangshi);
$selldate=trim($selldate);
$begindate= trim($begindate);
$enddate= trim($enddate);
$jingban= trim($jingban);
$moneyID = c_newOrderNo("F");
$id_login = $_SESSION['eptime_id'];
$login = $_SESSION['eptime_username'];


	if(trim(c_bigclassid('2'))==''){
		LYG::ShowMsg('没有收费专用项目，不能操作');
	}
$type=c_bigclassid1('2');
$id_bigclass=c_bigclassid('2');
$id_smallclass=0;
	if(trim(c_zhanghuisok('1'))==''){
		LYG::ShowMsg('没有收费账号，不能操作');
	}
$zhanghu=c_zhanghuisok('1');
$yuangong=0;
$xiangmu=c_wanglaibanji($stuid1);
if($check_enable){
	$isok = 1;
		}
		else{$isok = 0;}
$addtime = date("Y-m-d H:i:s",time());


$price1=0;
for($i=0;$i<count($price);$i++){  

		$data1 = array(
		    'stuid' =>$stuid1,
			'begindate'=>$begindate,
            'enddate'  =>$enddate,
			'fangshi'=>$fangshi,
            'selldate'  =>$selldate,
			'jingban'=>$jingban,
            'moneyID'  =>$moneyID,
			'id_login'=>$id_login,
            'login'  =>$login,
            'name'	=>$name[$i],
			'price'=>$price[$i],
		    'beizhu'=>$beizhu[$i]
	);
	$eok = $con->add("fei",$data1);
$price1=$price1+$price[$i];
}
$beizhu1='收费自动生成';
//收支记录开始
	$data = array(
		'type'		=>$type,
  'id_bigclass'		=>$id_bigclass,
 'id_smallclass'	=>$id_smallclass,
        'price'		=>$price1,
        'selldate'	=>$selldate,
		'zhanghu'	=>$zhanghu,
		'wanglai'	=>$stuid1,
		'yuangong'	=>$yuangong,
		'xiangmu'	=>$xiangmu,
		'moneyID'	=>$moneyID,
		'id_login'	=>$id_login,
        'login'		=>$login,
		'isok'		=>$isok,
		'beizhu'    =>$beizhu1,
		'addtime'	=>$addtime
	);
	
	$aok = $con->add("money",$data);
if ($type==0){$bok = $con->Update("update #__zhanghu set amount=amount+{$price1} where id={$zhanghu}");}
elseif($type==1){$bok = $con->Update("update #__zhanghu set amount=amount-{$price1} where id={$zhanghu}");}
//收支记录结束


		LYG::ShowMsg('添加成功','fei_list.php');

	
	die();
}
$classes = $con->select("select * from #__fangshi");
?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>费用收取</title>
<link href="style/css/css.css" rel="stylesheet" type="text/css" />
<link href="style/css/font-awesome.min.css" rel="stylesheet" type="text/css" />
<style type="text/css">
label{margin-right:10px;}
</style>
<script type="text/javascript" src="js/My97DatePicker/WdatePicker.js"></script>
<script type="text/javascript" src="js/jquery.min.js"></script>
<script type="text/javascript" src="js/common.js"></script>
		<link rel="stylesheet" href="kindeditor/themes/default/default.css" />
		<script src="kindeditor/kindeditor-all.js" charset="UTF-8"></script>
		<script src="kindeditor/lang/zh-CN.js" charset="UTF-8"></script>
		<script>
			KindEditor.ready(function(K) {
				var editor = K.editor({
					allowFileManager : true
				});
				K('#image3').click(function() {
					editor.loadPlugin('image', function() {
						editor.plugin.imageDialog({
							showRemote : false,
							imageUrl : K('#url3').val(),
							clickFn : function(url, title, width, height, border, align) {
								K('#url3').val(url);
								editor.hideDialog();
							}
						});
					});
				});
			});
		</script>
        <script  language="javascript">
            function ShowOpenWin(objTag)
            {
                document.getElementById("frmOpenWin").style.display = "block";
                
                var position = getPos(objTag);                    

                document.getElementById("frmOpenWin").style.top =  (position.y+22) + "px";
                document.getElementById("frmOpenWin").style.left = position.x+"px";
            }

            function HiddenAllFlag()
            {
                if(event.srcElement.id != "tbxCategory")
                {
                    document.getElementById("frmOpenWin").style.display = "none";
                }
            }
            
            function getPos(elm)
            {
                for(var zx=zy=0;elm!=null;zx+=elm.offsetLeft,zy+=elm.offsetTop,elm=elm.offsetParent); 
                return {x:zx,y:zy}                
            }
        </script>
<script type="text/javascript">
$(function(){
	$(':button[name=add]').click(function(){
		insertTr();
	})
})
var gradeI=1;
function insertTr(){
	var html='';
	html+='<tr align="center" class="itme">';
	html+='<td><input type="text" name="name[]"></td>';
	html+='<td><input type="text" name="price[]"></td>';
	html+='<td><input type="text" name="beizhu[]"></td>';
	$('#tab').append(html);
	$('button[name=del]').click(function(){
		$(this).parents('tr').remove();
	})	
	gradeI++;
}
</script>
</head>


<body class="content">
<form action='' method='post'>

<table cellpadding="3" cellspacing="0" class="table-add">
		<tr>
			<td align="right" height='36' width="100px">姓名：</td>
			<td colspan='5' >
<input type="text" name="stuid" id="tbxCategory" onClick="ShowOpenWin(this);" style="width:360" class='inp'  readonly/> <font color="red">必须选择</font>
<iframe onlosecapture="HiddenAllFlag()" onblur="HiddenAllFlag()" src="wang1.php" id="frmOpenWin" frameborder="0" style="BORDER-RIGHT: 1px solid; BORDER-TOP: 1px solid; DISPLAY: none; BORDER-LEFT: 1px solid; WIDTH: 360px; BORDER-BOTTOM: 1px solid; POSITION: absolute; HEIGHT: 200px"></iframe>

			</td>
		</tr>
		<tr>
			<td align="right" height='36'>起止日期：</td>
			<td colspan='5' >
			<input type='text' class='inp2' name='begindate' value='<?php echo date("Y-m-d",time()) ?>' placeholder="0000-00-00" onclick="WdatePicker({dateFmt:'yyyy-MM-dd'});" /> -- <input type='text' class='inp2' name='enddate' value='<?php echo (date('Y',time())+1)."-".date('m-d',time()) ?>' placeholder="0000-00-00" onclick="WdatePicker({dateFmt:'yyyy-MM-dd'});" />
			<span>点击选择</span>
			
			</td>
		</tr>

		<tr>
			<td align="right" height='36'>收费日期：</td>
			<td>
			<input type='text' class='inp2' name='selldate' value='<?php echo date("Y-m-d",time()) ?>' placeholder="0000-00-00" onclick="WdatePicker();" />
			<span>点击选择</span>
			</td>
			<td align="right" height='36'>付款方式：</td>
			<td>
				<select name="fangshi" class="select" onchange="search(this);">
			<?php
			foreach ($classes as $k => $v) {
					echo "<option value='{$v['name']}'>{$v['name']}</option>";    
			}
			?></select>	<a href="base.php?base=fangshi">+</a>	
			</td>
			<td align="right" height='36'>经办人：</td>
			<td>
			<select name="jingban" class="select">
				<?php
				foreach(c_classinfo("yuangong") as $k=>$v){
if(intval($_SESSION['eptime_l_yuangong'])===intval($v['id'])){echo "<option value='{$v['id']}' selected='selected'>{$v['name']}</option>";}
else{echo "<option value='{$v['id']}'>{$v['name']}</option>";}
				}
				?>
				</select>
			</td>
		</tr>


			<tr>
				<td align="right" width='100' height='36'>费用信息：</td>
				<td align="left" colspan='5' >

	<table width="100%" id="tab" class="table-add">
		<tr><th>费用名称</th><th>金额(金额为负表示退费)</th><th>备注</th></tr>
		<tr align="center" class="itme">
			<td><input type="text" name="name[]"></td>
			<td><input type="text" name="price[]"></td>
			<td><input type="text" name="beizhu[]"></td>
		</tr>
	</table>
	<div align="center"><input type="button" name="add" value="增加一行"></div>


				</td>
			</tr>



			<tr>
				<td align="right" height='50'>　</td>
				<td align="left" colspan='5' ><input class='sub' type='submit' value='确认收取'/></td>
			</tr>
</table>

</form>
</body>
</html>