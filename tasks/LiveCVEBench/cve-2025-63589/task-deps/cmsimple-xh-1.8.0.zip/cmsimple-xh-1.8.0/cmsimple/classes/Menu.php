<?php

/**
 * A dummy file for backward compatibility with CMSimple_XH 1.6
 */

trigger_error(
    sprintf('Manual loading of %s is deprecated; use autoloading instead', __FILE__),
    E_USER_DEPRECATED
);
