<?php

require_once(dirname(__FILE__).'/include/common.php');


if($_GET['a']<>""){

$moblie=$_SESSION['eptime_mobile'];
$send_code=random(6,1);
$_SESSION['eptime_login_code1']=$send_code;
        $updatehosturl = $webconfig['sms_api'].'?eptime='.$webconfig['sms_eptimecode'].'&mobile='.$moblie.'&sendcode='.$send_code;
        $updatenowinfo = file_get_contents($updatehosturl);
}



if($_POST['ok']=="ok"){

		if(empty($_SESSION['eptime_login_code1'])){
			
			LYG::ShowMsg('非法操作','money_list.php');
		}
		if(empty($_POST['code'])){
			LYG::ShowMsg('请输入验证码','money_list.php');
		}
		if(strtolower($_POST['code']) != $_SESSION['eptime_login_code1']){
			LYG::ShowMsg('验证码错误','money_list.php');
		}
		$_SESSION['eptime_login_code1'] = null;
		unset($_SESSION['eptime_login_code1']);

	
	extract($_POST);
$dataid=intval($id);
$type=intval($type);
$moneyID=trim($moneyID);
$price=trim($price);
$old_price=trim($old_price);
$old_zhanghu=trim($old_zhanghu);
$selldate=trim($selldate);
	$zhanghu = intval($zhanghu);
	$wanglai = intval($wanglai);
	$yuangong = intval($yuangong);
	$xiangmu = intval($xiangmu);
	$beizhu= trim($beizhu);
	$img = trim($img);
$LastLogin = $_SESSION['eptime_username'];
$LastTime = date("Y-m-d H:i:s",time());

	if(empty($price) || trim($price)==''){
		LYG::ShowMsg('金额不能为空');
	}

    $data = array(
        'price'		=>$price,
        'selldate'	=>$selldate,
		'zhanghu'	=>$zhanghu,
		'wanglai'	=>$wanglai,
		'yuangong'	=>$yuangong,
		'xiangmu'	=>$xiangmu,
		'beizhu'	=>$beizhu,
		'img'		=>$img,
        'LastLogin'	=>$LastLogin,
		'LastTime'	=>$LastTime,
    );
	$result	= $con->savemin("money",$data,"id={$dataid}");
	if($result!==false){
if ($type==0){$eok = $con->Update("update #__zhanghu set amount=amount+{$price} where id={$zhanghu}");
              $eok = $con->Update("update #__zhanghu set amount=amount-{$old_price} where id={$old_zhanghu}");}
elseif($type==1){$eok = $con->Update("update #__zhanghu set amount=amount-{$price} where id={$zhanghu}");
                 $eok = $con->Update("update #__zhanghu set amount=amount+{$old_price} where id={$old_zhanghu}");}
LYG::writeLog("[".$_SESSION['eptime_username']."]修改单号[".$moneyID."]");
		LYG::ShowMsg('修改成功','money_list.php');
	}else{
		LYG::ShowMsg('流水没有更改');
	}
	
	die();


}
	
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta name="renderer" content="webkit" />
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title><?php echo $webconfig['system_title'];?></title>
<link href="style/css/sms.css" type="text/css" rel="stylesheet" />
<style type="text/css">
.loginbox{ height:200px;}
</style>
<script src="js/jquery.min.js"></script>
<script>
    time =60;  //短信倒计时时间
    function send(obj) {
        var timer =  setInterval(function () {
            time--;
            $(obj).text(time+'秒之后重发');
            $(obj).removeClass('btn-info');
            $(obj).addClass('btn-success')
            $(obj).prop('disabled', true);
 
            if(time==0){
 
                //清除定时器
                clearInterval(timer)
                $(obj).removeClass('btn-success');
                $(obj).addClass('btn-info');
                $(obj).prop('disabled', false);
 
                $(obj).text('获取验证码');
                time=60;
 
            }
        },1000);
        //获取手机号
        var phonum = $('#phonum').val();
            $.post('?a=sendSms&phonum='+phonum,{phonum:phonum},function () {
            },'json')
    }
</script>
</head>

<body>
	<div class="loginbox">
		<div class="loginbody">
			<form method="post">
<input type='hidden' name='id' value="<?php echo $_REQUEST['id'];?>" />
		<input type='hidden' name='type' value="<?php echo $_REQUEST['type'];?>" />
		<input type='hidden' name='moneyID' value="<?php echo $_REQUEST['moneyID'];?>" />
		<input type="hidden" name="old_price" value="<?php echo $_REQUEST['old_price'];?>">
		 <input type="hidden" name="old_zhanghu" value="<?php echo $_REQUEST['old_zhanghu'];?>">
<input type="hidden" name="price" value="<?php echo $_REQUEST['price'];?>">
<input type="hidden" name="selldate" value="<?php echo $_REQUEST['selldate'];?>">
<input type="hidden" name="zhanghu" value="<?php echo $_REQUEST['zhanghu'];?>">
<input type="hidden" name="wanglai" value="<?php echo $_REQUEST['wanglai'];?>">
<input type="hidden" name="yuangong" value="<?php echo $_REQUEST['yuangong'];?>">
<input type="hidden" name="xiangmu" value="<?php echo $_REQUEST['xiangmu'];?>">
<input type="hidden" name="beizhu" value="<?php echo $_REQUEST['beizhu'];?>">
<input type="hidden" name="img" value="<?php echo $_REQUEST['img'];?>">
<input type="hidden" name="ok" value="ok">
				<div class="oneline">
				    <input type="hidden" name="phonum"  id="phonum" autocomplete="off" placeholder="请输入手机号" value="<?php echo $_SESSION['eptime_mobile'];?>">
					<div class="code-text"><input type="text" name="code" autocomplete="off" placeholder="请输入手机验证码"></div>
					<div class="code-img"><button type="button" onclick="send(this)">获取验证码</button></div>
				</div>
				<div class="loginbtn">
				 <input type="submit" value="确定">
				</div>
			</form>		
		</div>
	</div>
</body>
</html>