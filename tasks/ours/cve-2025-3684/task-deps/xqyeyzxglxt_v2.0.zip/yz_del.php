<?php

require_once(dirname(__FILE__).'/include/common.php');
if (strpos($_SESSION['eptime_flag'], 'moneydfig') === false) {LYG::ShowMsg('您没有权限！');} 


if($_GET['a']<>""){

$moblie=$_SESSION['eptime_mobile'];
$send_code=random(6,1);
$_SESSION['eptime_login_code1']=$send_code;
        $updatehosturl = $webconfig['sms_api'].'?eptime='.$webconfig['sms_eptimecode'].'&mobile='.$moblie.'&sendcode='.$send_code;
        $updatenowinfo = file_get_contents($updatehosturl);
}


if(empty($_REQUEST['id'])){ lyg::showmsg('参数错误'); }

$arr = $_REQUEST['id'];

$yz = $_REQUEST['yz'];

if(!empty($_POST)){
	
	$post = $_POST;


		if(empty($_SESSION['eptime_login_code1'])){
			LYG::ShowMsg('非法操作');
		}
		if(empty($post['code'])){
			LYG::ShowMsg('请输入验证码');
		}
		if(strtolower($post['code']) != $_SESSION['eptime_login_code1']){
			LYG::ShowMsg('验证码错误');
		}
		$_SESSION['eptime_login_code1'] = null;
		unset($_SESSION['eptime_login_code1']);
if($yz=="m"){lyg::jump("money_del.php?id=$arr"); }
if($yz=="p"){lyg::jump("money_pay_del.php?id=$arr"); }	

	exit();
}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta name="renderer" content="webkit" />
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title><?php echo $webconfig['system_title'];?></title>
<link href="style/css/sms.css" type="text/css" rel="stylesheet" />
<style type="text/css">
.loginbox{ height:200px;}
</style>
<script src="js/jquery.min.js"></script>
</head>

<body>
<script>
    time =60;  //短信倒计时时间
    function send(obj) {
        var timer =  setInterval(function () {
            time--;
            $(obj).text(time+'秒之后重发');
            $(obj).removeClass('btn-info');
            $(obj).addClass('btn-success')
            $(obj).prop('disabled', true);
 
            if(time==0){
 
                //清除定时器
                clearInterval(timer)
                $(obj).removeClass('btn-success');
                $(obj).addClass('btn-info');
                $(obj).prop('disabled', false);
 
                $(obj).text('获取验证码');
                time=60;
 
            }
        },1000);
        //获取手机号
        var phonum = $('#phonum').val();
            $.post('?a=sendSms&phonum='+phonum,{phonum:phonum},function () {
            },'json')
    }
</script>
	<div class="loginbox">
		<div class="loginbody">
			<form method="post">

				<div class="oneline">
				    <input type="hidden" name="phonum"  id="phonum" autocomplete="off" placeholder="请输入手机号" value="<?php echo $_SESSION['eptime_mobile'];?>">
					<div class="code-text"><input type="text" name="code" autocomplete="off" placeholder="请输入手机验证码"></div>
					<div class="code-img"><button type="button" onclick="send(this)">获取验证码</button></div>
				</div>
				<div class="loginbtn">
				 <input type="submit" value="确定">
				</div>
			</form>		
		</div>
	</div>
</body>
</html>