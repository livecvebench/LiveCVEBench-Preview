<?php

namespace KaizenCoders\URL_Shortify\Common;

class Import {

}