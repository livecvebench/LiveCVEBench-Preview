tinymce.addI18n('zh_TW',{
    'HTML source code': 'HTML原始碼',
    'Start search': '開始搜尋',
    'Find next': '搜尋下一個.',
    'Find previous': '搜尋上一個.',
    'Replace': '取代',
    'Replace all': '全部取代'
});
