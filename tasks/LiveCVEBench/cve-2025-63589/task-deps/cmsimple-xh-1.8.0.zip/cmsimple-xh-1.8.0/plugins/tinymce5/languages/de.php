<?php
$plugin_tx['tinymce5']['cf_init']="Der Umfang der Toolbar";
$plugin_tx['tinymce5']['cf_utf-8_marker']="<p>Internal usage. <strong>Do not change!</strong></p>";
