<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>手机网</title>
<meta name='keywords' content='' />
<meta name='description' content='' />

<link rel="stylesheet" type="text/css" href="style/css/phone.css" />
</head>
<body>
    <!--  content  -->
<div class="wrapper">
  <div class="f_left">
    <div class="phone">
      <iframe frameborder="0" marginheight="0" marginwidth="0" style="width:266px;height:430px;overflow-y:auto;" src="m/index.php" name="phone"></iframe>
    </div>
    <ul class="phone_button">
      <li>
        特别提示：此页面为模仿手机的使用效果
      </li>
    </ul>
    <div class="phone_box"></div>
  </div>
  <div class="f_right">
  </div>
</div>

</body>
</html>