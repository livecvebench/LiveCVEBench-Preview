<?php
require_once(dirname(__FILE__).'/include/common.php');
$check_enable = intval($webconfig['system_check'])===1?true:false;
if (strpos($_SESSION['eptime_flag'], 'kucundfig') === false) {LYG::ShowMsg('您没有权限！');} 

if(empty($_REQUEST['id']) || intval($_REQUEST['id'])<1){lyg::showmsg('参数错误');}
$data_id = intval($_REQUEST['id']);
$info=  $con->find("select * from #__kucun where id=$data_id");
if(empty($info)){lyg::showmsg('参数错误');}

if(!empty($_POST)){
	//参数校验
	extract($_POST);


	if(!empty($shuliang)){
    $type=3;
    $pricea=$price*$shuliang;
	$data = array(
		'type'		=>$type,
		'danhao'	=>$danhao,
		'shangpinid'=>$shangpinid,
		'cangku'	=>$cangku,
		'cangku1'	=>$cangku1,
		'price'		=>floatval($price),
		'pricea'	=>floatval($pricea),
		'shuliang'	=>floatval($shuliang),
		'yuangong'	=>$yuangong,
		'beizhu'	=>$beizhu,
	);
	$aok = $con->add("kucunlog",$data);

//入库
	$ex = $con->rowscount("select count(*) from #__kucun where shangpinid=? and cangkuid=?",array(
		$shangpinid,$cangku1
	));
	if($ex>0){
    $eok = $con->Update("update #__kucun set shuliang=shuliang+{floatval($shuliang)} where shangpinid={$shangpinid} and cangkuid={$cangku1}");
	}else{
		$data1 = array(
		'shangpinid'=>$shangpinid,
		'cangkuid'	=>$cangku1,
		'shuliang'	=>floatval($shuliang),
	                 );
	    $bok = $con->add("kucun",$data1);	
	}


$eok = $con->Update("update #__kucun set shuliang=shuliang-{floatval($shuliang)} where id={$id}");
//出库
	}
LYG::ShowMsg('处理成功！','-1');


	die();
}


?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title></title>
<link href="style/css/css.css" rel="stylesheet" type="text/css" />
<script type="text/javascript" src="js/My97DatePicker/WdatePicker.js"></script>
<script type="text/javascript" src="js/jquery.min.js"></script>
<script type="text/javascript" src="js/common.js"></script>
</head>

<body class="content">

<form action='' method='post' name="form1">
<input type='hidden' name='id' value='<?php echo $data_id;?>'>
		<input type='hidden' name='shangpinid' value="<?php echo $info['shangpinid'];?>" />
		<input type='hidden' name='cangku' value="<?php echo $info['cangkuid'];?>" />
		<input type='hidden' name='price' value="<?php echo c_shangpin5($info['shangpinid']);?>" />
	<table cellpadding="3" cellspacing="0" class="table-add">

		<tr>
			<td align="right" height='36' width="100px"><strong>单号：</strong></td>
			<td><?php echo c_newOrderNo("D");?>&nbsp;&nbsp;&nbsp;&nbsp; <input type="hidden" name="danhao" class="inp2" value="<?php echo c_newOrderNo("D");?>"></td>
		</tr>

		<tr>
			<td align="right" height='36'><strong>调入仓库：</strong></td>
			<td >
				<select name="cangku1" class="select">
				<?php
				foreach(c_classinfo("cangku") as $k=>$v){
  if(intval($info['cangkuid'])!=intval($v['id'])){echo "<option value='{$v['id']}'>{$v['name']}</option>";}
				}
				?>
				</select>
			</td>
		</tr>
		<tr>
			<td align="right" height='36'><strong>经办人：</strong></td>
			<td >
			<select name="yuangong" class="select">
				<?php
				foreach(c_classinfo("yuangong") as $k=>$v){
if(intval($_SESSION['eptime_l_yuangong'])===intval($v['id'])){echo "<option value='{$v['id']}' selected='selected'>{$v['name']}</option>";}
else{echo "<option value='{$v['id']}'>{$v['name']}</option>";}
				}
				?>
				</select>
			</td>
		</tr>

		<tr>
			<td align="right" height='36'><strong>调拨商品：</strong></td>
			<td >
				<?php echo c_shangpin1($info['shangpinid']);?>[<?php echo c_shangpin2($info['shangpinid']);?>]
			</td>
		</tr>
		<tr>
			<td align="right" height='36'><strong>调拨数量：</strong></td>
			<td >
				<input type="number" name="shuliang" class="inp2" placeholder="" step="0.01" value="<?php echo $info['shuliang'];?>">
			</td>
		</tr>
		<tr>
			<td align="right" height='36'><strong>备注：</strong></td>
			<td >
				<input type="text" name="beizhu" class="inp3" placeholder="">
			</td>
		</tr>
		<tr>
			<td align="right" height='50'>　</td>
			<td align="left" ><input class='sub' type='submit' value='确定'/></td>
		</tr>

	</table>
</form>

</body>
</html>