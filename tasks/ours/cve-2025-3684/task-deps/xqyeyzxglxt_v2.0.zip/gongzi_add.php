<?php
require_once(dirname(__FILE__).'/include/common.php');
if (strpos($_SESSION['eptime_flag'], 'gonghfig') === false) {LYG::ShowMsg('您没有权限！');}

$hesuanmouth=date('Y-m',strtotime(date('Y').'-'.(date('m')-1).'-01'));

if(!empty($_POST)){
	//参数校验
	extract($_POST);
$login = $_SESSION['eptime_username'];
for($i=0;$i<count($ygid);$i++){  

		$data1 = array(
		    'ygid'  =>$ygid[$i],
			'yuefen'=>$yuefen[$i],
            'jiben'	=>$jiben[$i],
			'kaohe' =>$kaohe[$i],
			'kaoqin'=>$kaoqin[$i],
            'butie'	=>$butie[$i],
			'shebao'=>$shebao[$i],
			'shui'  =>$shui[$i],
            'qita'	=>$qita[$i],
			'gongzi'=>$gongzi[$i],
			'gongzia'=>$gongzia[$i],
			'hesuan' =>$login,
		    'beizhu' =>$beizhu[$i]

	);
	$eok = $con->add("gongzi",$data1);
    $uok = $con->Update("update #__yuangong set yuefen='".$yuefen[$i]."' where id={$ygid[$i]}");
}  

	LYG::ShowMsg('成功！','gongzi_list.php');
	
	die();
}
$classes = $con->select("select * from #__gangwei");

$yuangong = $con->select("select * from #__yuangong where isok=1 and yuefen!='".$hesuanmouth."'");

?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title></title>
<link href="style/css/css.css" rel="stylesheet" type="text/css" />
<script type="text/javascript" src="js/My97DatePicker/WdatePicker.js"></script>
<script type="text/javascript" src="js/jquery.min.js"></script>
<script type="text/javascript" src="js/common.js"></script>
<script type="text/javascript">
	$(function (){
		$("input").blur(function (){
<?php 
$ii=1;
foreach($yuangong as $k=>$v){?>
var sum = parseInt($("#one<?php echo $ii;?>").val()) + parseInt($("#two<?php echo $ii;?>").val()) + parseInt($("#three<?php echo $ii;?>").val()) + parseInt($("#four<?php echo $ii;?>").val());
$("#sum<?php echo $ii;?>").val(sum);

var suma = parseInt($("#one<?php echo $ii;?>").val()) + parseInt($("#two<?php echo $ii;?>").val()) + parseInt($("#three<?php echo $ii;?>").val()) + parseInt($("#four<?php echo $ii;?>").val()) - parseInt($("#five<?php echo $ii;?>").val()) - parseInt($("#six<?php echo $ii;?>").val()) - parseInt($("#sever<?php echo $ii;?>").val());
$("#suma<?php echo $ii;?>").val(suma);
<?php $ii=$ii+1;}?>
		})
	})
</script>
</head>

<body class="content">


<form action='' method='post'>
	<table cellpadding="3" cellspacing="0" class="table-add">
		<tbody>
			<tr align="center"  height='36'>
				<th>教工编号</th>
				<th>教工姓名</th>
				<th>任职岗位</th>
				<th>月份</th>
				<th>基本工资(+)</th>
				<th>绩效考核(+)</th>
				<th>人事考勤(+)</th>
				<th>补贴(+)</th>
				<th>社保公积金(-)</th>
				<th>个人所得税(-)</th>
				<th>其他扣除(-)</th>
				<th>应发工资</th>
				<th>实发工资</th>
				<th>备注</th>
			</tr>
<?php 
$iii=1;
foreach($yuangong as $k=>$v){?>
	<input type="hidden" name="ygid[]"  value="<?php echo $v['id'];?>">
	<input type="hidden" name="yuefen[]"  value="<?php echo $hesuanmouth;?>">
		<tr align="center"><td><?php  echo $v['bianhao'];?></td>
			<td><?php echo $v['name'];?></td>
			<td><?php echo $v['gangwei'];?></td>
			<td><?php echo $hesuanmouth;?></td>
			<td><input type="number" name="jiben[]" class='inp1' id="one<?php echo $iii;?>"></td>
			<td><input type="number" name="kaohe[]" value="0" class='inp1' id="two<?php echo $iii;?>"></td>
			<td><input type="number" name="kaoqin[]" value="0" class='inp1' id="three<?php echo $iii;?>"></td>
			<td><input type="number" name="butie[]" value="0" class='inp1' id="four<?php echo $iii;?>"></td>
			<td><input type="number" name="shebao[]" value="0" class='inp1' id="five<?php echo $iii;?>"></td>
			<td><input type="number" name="shui[]" value="0" class='inp1' id="six<?php echo $iii;?>"></td>
			<td><input type="number" name="qita[]" value="0" class='inp1' id="sever<?php echo $iii;?>"></td>
			<td><input type="number" name="gongzi[]" class='inp1' id="sum<?php echo $iii;?>" readonly></td>
			<td><input type="number" name="gongzia[]" class='inp1' id="suma<?php echo $iii;?>" readonly></td>
			<td><input type="text" name="beizhu[]" class='inp1'></td>
		</tr>
<?php $iii=$iii+1;}?>
			<tr align="center" height='40'>
				<td colspan="14"><input class='sub' type='submit' value='核算'/></td>
			</tr>
		</tbody>
	</table>
</form>

</body>
</html>