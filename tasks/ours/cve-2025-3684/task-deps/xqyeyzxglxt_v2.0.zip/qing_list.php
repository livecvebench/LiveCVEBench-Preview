<?php

require_once(dirname(__FILE__).'/include/common.php');
if (strpos($_SESSION['eptime_flag'], 'qinglfig') === false) {LYG::ShowMsg('您没有权限！');}
$webconfig = lyg::readArr("web");

$_k = "";
$_v = array();

$_c = array();//分页条件
$_s = array();//搜索条件

if(!empty($_GET['yuangong']) && intval($_GET['yuangong'])>0){
    $_k=$_k." and #__qingj.yuangong=".intval($_GET['yuangong']);
    $_c[]="yuangong=".intval($_GET['yuangong']);
    $_s['yuangong'] = intval($_GET['yuangong']);
}

if(!empty($_GET['keywords']) && trim($_GET['keywords'])!=''){
    $_k=$_k." and (#__wanglai.name like '%".trim($_GET['keywords'])."%' or #__qingj.beizhu like '%".trim($_GET['keywords'])."%')";
    $_c[]="keywords=".trim($_GET['keywords']);
    $_s['keywords'] = trim($_GET['keywords']);
}

if(!empty($_GET['time0']) && !empty($_GET['time1']) && 
    preg_match("/^\d{4}\-\d{2}\-\d{2}$/",$_GET['time0']) && preg_match("/^\d{4}\-\d{2}\-\d{2}$/",$_GET['time1'])
){
    $time0 = $_GET['time0'];
    $time1 = $_GET['time1'];
    $t0 = strtotime($time0." 00:00:00");
    $t1 = strtotime($time1." 23:59:59");
    if($t0!==false && $t1!==false && $t1>$t0){

        $_k=$_k." and UNIX_TIMESTAMP(#__qingj.begindate)>=".$t0;
        $_c[]="time0=$time0";
        $_s['time0'] = $time0;

        $_k=$_k." and UNIX_TIMESTAMP(#__qingj.enddate)<=".$t1;
        $_c[]="time1=$time1";
        $_s['time1'] = $time1;
    }
}


if($_k!=''){
    $_k = " where 1=1 ".$_k;
}

$field = array(
	"#__qingj.*",
	"#__wanglai.name"
);
$field = implode(",",$field);
$left = "left join #__wanglai on #__wanglai.id=#__qingj.stuid ";


$action="search";
if(!empty($_GET['action']) && $_GET['action']=='output'){
	require_once(dirname(__FILE__).'/include/PHPExcel/PHPExcel.php');
	$sql = "select {$field} from #__qingj {$left} {$_k} order by #__qingj.id desc,#__qingj.isok desc";
	$data = $con->select($sql);
	require_once("output.php");
	die();
}


$nowcount=$con->RowsCount("select count(distinct #__qingj.stuid) from #__qingj {$left} {$_k}");




if($webconfig['eptime_pagesize']){$pagesize=$webconfig['eptime_pagesize'];}else{$pagesize = 20;}

$datacount=$con->RowsCount("select count(#__qingj.id) from #__qingj {$left} {$_k}");

$totalpages=LYG::getTotalPage($datacount,$pagesize);
$page=1;
if(!empty($_GET['p']) && intval($_GET['p'])>0){
	$page=intval($_GET['p']);
	$page=$page>$totalpages?$totalpages:$page;
	if($page+1<=1){$page=1;}
}
$start_id=($page-1)*$pagesize;

$sql = "select {$field} from #__qingj {$left} {$_k} order by #__qingj.id desc,#__qingj.isok desc limit {$start_id},{$pagesize}";
$data =$con->select($sql);
$fenye = LYG::getPageHtml($page,$datacount,$pagesize,$_c);




$classes = $con->select("select * from #__class");

if(trim($_GET['shenhe'])=="kk"){$eok = $con->Update("update #__wanglai set isok=1 where id={$_GET['stuid']}");
$eok1 = $con->Update("update #__qingj set isok=0 where id={$_GET['id']}");echo "<script>window.history.go(-1); </script>";}

?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>请假记录</title>
<link href="style/css/css.css" rel="stylesheet" type="text/css" />
<link href="style/css/font-awesome.min.css" rel="stylesheet" type="text/css" />
<script type="text/javascript" src="js/My97DatePicker/WdatePicker.js"></script>
<script type="text/javascript" src="js/jquery.min.js"></script>
<script type="text/javascript" src="js/common.js"></script>
<script type="text/javascript">
function setEnable(obj,id){
    $.post("json.php",{"act":"setadminenable","id":id,"enable":obj.checked?"1":"0"},function(e){
        location.reload();
    },"Json");
}
</script>
<script type="text/javascript">
function search(obj){
	document.searchform.submit();
}
$(function(){
	$("input.sort").blur(function(){
		
		var sort = parseInt($(this).val());
		if(isNaN(sort)){
			sort = 100;
		}
		if(sort == parseInt(this.defaultValue)){
			return;
		}
		
		var id = $(this).parent().parent().attr("data-id");
		
		$.post("json.php",{"act":"shangpinsort","id":id,"sort":sort},function(e){
			location.reload();
		},"json");
	});
});
</script>
</head>

<body class="content">
<div class="searchform">
    <form method="get" name="searchform">
	<table>
		<tr>
		    <td width="*" align="right">时间</td>
			<td width="100" align="right">
				<input type="text" name="time0" class="text"  onclick="WdatePicker();" value="<?php 
					if(array_key_exists("time0",$_s)){
						echo $_s['time0'];
					}
				?>">
			</td>
			<td width="20" align="center">至</td>
			<td width="100">
				<input type="text" name="time1" class="text"  onclick="WdatePicker();" value="<?php 
					if(array_key_exists("time1",$_s)){
						echo $_s['time1'];
					}
				?>">
			</td>
			<td width="200" align="right">
				<select name="yuangong" class="select bai" onchange="search(this);">
					<option value='0'>所有经办人</option><?php
					foreach(c_classinfo("yuangong") as $k=>$v){
						if(array_key_exists('yuangong', $_s) && intval($_s['yuangong'])===intval($v['id'])){
							echo "<option value='{$v['id']}' selected='selected'>{$v['name']}</option>";
						}else{
							echo "<option value='{$v['id']}'>{$v['name']}</option>";    
						}
					}
					?>
				</select>
			</td>
			<td width="60" align="right">关键词:</td>
			<td width="160">
				<input type="text" name="keywords" class="text" placeholder='请假人或备注' value="<?php 
					if(array_key_exists("keywords",$_s)){
						echo $_s['keywords'];
					}
				?>">
			</td>
			
			<td width="80" align="right">
<input type="submit" onclick="setmethod('search');" value="查询" class="sub">
			</td>
		</tr>
	</table>
    </form>
	<table>
		<tr>
		<td width="*" align="right"></td>
			<td width="80%" align="right">
			请假总人数：<b><?php echo $nowcount;?></b> 人&nbsp;
			</td>
			</tr>
	</table>
</div>


<table cellpadding="3" cellspacing="0">
	<thead>
    	<tr>
            <th>ID</th>
            <th>请假人</th>
            <th>开始时间</th>
			<th>结束时间</th>
            <th>天数</th>
            <th>经办人</th>
			<th>备注</th>
            <th>状态</th>
            <th>-</th>
        </tr>


    </thead>
    <tbody>
	<?php foreach($data as $k=>$v){?>

    	<tr class='list' data-id="<?php echo $v['id'];?>">
        	<td align="center"><?php echo $v['id'];?></td>
        	<td align="center"><?php echo c_classname("wanglai",$v['stuid']);?></td>
        	<td align="center"><?php echo $v['begindate'];?></td>
			<td align="center"><?php echo $v['enddate'];?></td>
<td align="center"><?php echo sprintf("%.1f",abs((strtotime($v['enddate'])-strtotime($v['begindate']))/86400));?></td>
<td align="center"><?php echo c_classname("yuangong",$v['yuangong']);?></td>
<td align="center"><?php echo $v['beizhu'];?></td>
<td align="center">
<?php if($v['isok']==1){echo "<a href=?shenhe=kk&stuid={$v['stuid']}&id={$v['id']}>";}?>
<font color=<?php if($v['isok']==1){echo "red";}else{echo "green";}?>><?php echo $c_stuok1[$v['isok']];?></font></a>
</td>

            <td align="center">
<?php if($v['isok']==0){?>
				<a onclick="return confirm('确定删除吗？');" class="del" href="class_del.php?id=<?php echo $v['id'];?>&class=qingj"><i class="fa fa-close"></i><span>删除</span></a>
<?php }?>
			</td>
        </tr>
	<?php }?>
    </tbody>
    <tfoot>
    	<tr>
        	<td colspan="12" style="padding-left:30px;">
			<?php echo $fenye ;?>
			</td>
        </tr>
    </tfoot>
</table>


</body>
</html>