<?php

/**
 * jQuery for CMSimple
 *
 * Version:    1.6.8
 * Build:      2024101401
 * Copyright:  Holger Irmler
 * Email:      CMSimple@HolgerIrmler.de
 * Website:    http://CMSimple.HolgerIrmler.de
 * Copyright:  CMSimple_XH developers
 * Website:    https://www.cmsimple-xh.org/?About-CMSimple_XH/The-XH-Team
 
 * */

$plugin_cf['jquery']['version_core']="3.7.1";
$plugin_cf['jquery']['version_ui']="1.14.0";
$plugin_cf['jquery']['version_migrate']="jquery-migrate-3.5.2.min.js";
$plugin_cf['jquery']['load_migrate']="";
$plugin_cf['jquery']['autoload']="";
$plugin_cf['jquery']['autoload_libraries']="jQuery";
