<?php
require_once(dirname(__FILE__).'/include/common.php');
$webconfig = lyg::readArr("web");
$check_enable = intval($webconfig['system_check'])===1?true:false;
	
if(!empty($_POST)){
	//参数校验
	extract($_POST);

	if(empty($jzmobile) || trim($jzmobile)==''){
		LYG::ShowMsg('电话不能为空');
	}
	if(empty($jzname) || trim($jzname)==''){
		LYG::ShowMsg('姓名不能为空');
	}

		$data = array(
		    'stuid' =>$stuid,
			'gx'    =>$jzgx,
            'name'	=>$jzname,
			'cardno'=>$jzcardno,
			'mobile'=>$jzmobile,
		    'beizhu'=>$jzbeizhu
	);
	$aok = $con->add("jiaz",$data);

	if($aok){
		LYG::ShowMsg('添加成功','stu_info1.php?stuid='.$stuid.'');
	}else{
		LYG::ShowMsg('添加失败，请重试');
	}
	
	die();
}

?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>请假登记</title>
<script type="text/javascript" src="js/jquery-1.4.2.min.js"></script>	
<script type="text/javascript" src="js/jquery.tree.js"></script>	
<script type="text/javascript">
$(function(){
	$('#files').tree({
		expanded: 'li:first'
	});
});
</script>	
<style>
body {
	background-color:#FFFFFF;
}
</style>
        <script language="javascript">
            var oldBackGroundColor = "";
            var bClick = false;
            
            function onclickRow(objid,objName)
            {
                window.parent.document.getElementById("tbxCategory").value = objName+"["+objid+"]";
                window.parent.window.document.getElementById("frmOpenWin").style.display = "none";
            }
            
            function tr_onmouseover(event)
            {
                bClick = true;
                var objTR = null;
                
                if(event == null)
                {
                    event = window.event; // For IE
                }
                var objTag = event.srcElement? event.srcElement : event.target;//For FierFox
                
                if(objTag.tagName == "TD")
                {
                    if(document.all)
                    {
                        if(objTag.parentNode.tagName == "TR")
                        {
                            oldBackGroundColor = objTag.parentNode.style.backgroundColor;
                            objTag.parentNode.style.backgroundColor = "#99ff00";
                        }
                        else if(objTag.parentNode.parentNode.tagName == "TR")
                        {
                            oldBackGroundColor = objTag.parentNode.style.backgroundColor;
                            objTag.parentNode.parentNode.style.backgroundColor = "#99ff00";
                        }
                    }
                    else
                    {
                        if(objTag.parentNode.tagName == "TR")
                        {
                            oldBackGroundColor = objTag.parentNode.style.backgroundColor;
                            objTag.parentNode.style.backgroundColor = "#99ff00";
                        }
                        else if(objTag.parentNode.parentNode.tagName == "TR")
                        {
                            oldBackGroundColor = objTag.parentNode.style.backgroundColor;
                            objTag.parentNode.parentNode.style.backgroundColor = "#99ff00";
                        }
                    }    
                }
                else
                {
                    if(objTag.tagName == "TR")
                    {
                        oldBackGroundColor = objTag.parentNode.style.backgroundColor;
                        objTag.style.backgroundColor="#99ff00";
                    }
                    else if(objTag.parentNode.tagName == "TR")
                    {
                        oldBackGroundColor = objTag.parentNode.style.backgroundColor;
                        objTag.parentNode.style.backgroundColor="#99ff00";
                    }
                    else if(objTag.parentNode.parentNode.tagName == "TR")
                    {
                        oldBackGroundColor = objTag.parentNode.style.backgroundColor;
                        objTag.parentNode.parentNode.style.backgroundColor="#99ff00";
                    }
                }
            }
            function tr_onmouseout(event)
            {
                var objTR = null;
                if(event == null)
                {
                    event = window.event; // For IE
                }
                var objTag = event.srcElement? event.srcElement : event.target;//For FierFox
                
                if(objTag.tagName == "TD")
                {
                    if(objTag.parentNode.tagName == "TR" && bClick)
                    {
                        objTag.parentNode.style.backgroundColor = oldBackGroundColor;
                        oldBackGroundColor = "";
                    }
                    else if(objTag.parentNode.parentNode.tagName == "TR" && bClick)
                    {
                        objTag.parentNode.parentNode.style.backgroundColor = oldBackGroundColor;
                        oldBackGroundColor = "";
                    }
                }
                else
                {
                    if(objTag.tagName == "TR" && bClick)
                    {
                        objTag.style.backgroundColor = oldBackGroundColor;
                        oldBackGroundColor = "";
                    }
                    else if(objTag.parentNode.tagName == "TR" && bClick)
                    {
                        objTag.parentNode.style.backgroundColor=oldBackGroundColor;
                        oldBackGroundColor = "";
                    }
                    else if(objTag.parentNode.parentNode.tagName == "TR" && bClick)
                    {
                        objTag.parentNode.parentNode.style.backgroundColor=oldBackGroundColor;
                        oldBackGroundColor = "";
                    }
                }
                bClick = false;
            }
            
            function InitRowBackColor(objTable)
            {
                for(var i = 0; i < objTable.rows.length; i ++)
                {
                    if(document.all)
                    {
                        objTable.rows[i].style.backgroundColor = "";
                    }
                    else
                    {
                        objTable.rows[i].style.backgroundColor = "";
                    }
                }
            }
        </script>
</head>
<BODY MS_POSITIONING="GridLayout" leftmargin="0" topmargin="0">
<style type="text/css">
*{margin:0;padding:0;list-style-type:none;font-size:14px;}
a,img{border:0;}
#files{margin:10px auto;width:300px;}
.tree,.tree ul,.tree li{list-style:none;margin:0;padding:0;zoom: 1;}
.tree ul{margin-left:10px;}
.tree li a{color:#555;padding:.1em 7px .1em 27px;display:block;text-decoration:none;border:1px dashed #fff;background:url(style/images/icon-file.gif) 5px 50% no-repeat;}
.tree li a.tree-parent{background:url(style/images/icon-folder-open.gif) 5px 50% no-repeat;}
.tree li a.tree-parent-collapsed{background:url(style/images/icon-folder.gif) 5px 50% no-repeat;}
.tree li a:hover,.tree li a.tree-parent:hover,.tree li a:focus,.tree li a.tree-parent:focus,.tree li a.tree-item-active{color:#000;border:1px solid#eee;background-color:#fafafa;-moz-border-radius:4px;-webkit-border-radius:4px;border-radius:4px;}
.tree li a:focus,.tree li a.tree-parent:focus,.tree li a.tree-item-active{border:1px solid #e2f3fb;background-color:#f2fafd;}
.tree ul.tree-group-collapsed{display:none;}
</style>


<ul id="files">
<li><a href="javascript:void(0);">请首先选择班级</a>
	<ul>
<?php
foreach(c_classinfo("xiangmu") as $k=>$v){  
?>
			<li><a href="javascript:void(0);"><?php echo $v['name'];?></a>
				<ul>
<?php
$sql='select * from #__wanglai where banji='.$v['id'].' and isok=1 order by convert(name using gbk) ASC';
$data	=$con->select($sql,'');

foreach($data as $k=>$v){ 
?>
					<li><a onclick="onclickRow('<?php echo $v['id'];?>','<?php echo $v['name'];?>');" onmouseover="tr_onmouseover()"
                            onmouseout="tr_onmouseout()"><?php echo $v['name'];?></a></li>
<?php
}
?>
				</ul>
			</li>

<?php
}
?>
	</ul>
</li>

</ul>

</ul>
</body>
</html>