<?php

require_once(dirname(__FILE__).'/include/common.php');
if ($_SESSION['eptime_adminPower']<>0) {LYG::ShowMsg('您没有权限！');} 
if (strpos($_SESSION['eptime_flag'], 'zhilfig') === false) {LYG::ShowMsg('您没有权限！');} 


$_k = "";
$_v = array();

$_c = array();//分页条件
$_s = array();//搜索条件

if(!empty($_GET['banji']) && intval($_GET['banji'])>0){
    $_k=$_k." and #__yuangong.banji=".intval($_GET['banji']);
    $_c[]="banji=".intval($_GET['banji']);
    $_s['banji'] = intval($_GET['banji']);
}
if(intval($_GET['isok'])<>9){
    $_k=$_k." and #__yuangong.isok=".intval($_GET['isok']);
    $_c[]="isok=".intval($_GET['isok']);
    $_s['isok'] = intval($_GET['isok']);
}

if(!empty($_GET['sex'])){
    $_k=$_k." and #__yuangong.sex='".trim($_GET['sex'])."'";
    $_c[]="sex='".trim($_GET['sex'])."'";
    $_s['sex'] = trim($_GET['sex']);
}
if(!empty($_GET['nation'])){
    $_k=$_k." and #__yuangong.nation='".trim($_GET['nation'])."'";
    $_c[]="nation='".trim($_GET['nation'])."'";
    $_s['nation'] = trim($_GET['nation']);
}
if(!empty($_GET['gangwei'])){
    $_k=$_k." and #__yuangong.gangwei='".trim($_GET['gangwei'])."'";
    $_c[]="gangwei='".trim($_GET['gangwei'])."'";
    $_s['gangwei'] = trim($_GET['gangwei']);
}
if(!empty($_GET['keywords']) && trim($_GET['keywords'])!=''){
    $_k=$_k." and (#__yuangong.name like '%".trim($_GET['keywords'])."%' or #__yuangong.bianhao like '%".trim($_GET['keywords'])."%' or #__yuangong.tel like '%".trim($_GET['keywords'])."%' or #__yuangong.beizhu like '%".trim($_GET['keywords'])."%')";
    $_c[]="keywords=".trim($_GET['keywords']);
    $_s['keywords'] = trim($_GET['keywords']);
}

if(!empty($_GET['time0']) && !empty($_GET['time1']) && 
    preg_match("/^\d{4}\-\d{2}\-\d{2}$/",$_GET['time0']) && preg_match("/^\d{4}\-\d{2}\-\d{2}$/",$_GET['time1'])
){
    $time0 = $_GET['time0'];
    $time1 = $_GET['time1'];
    $t0 = strtotime($time0." 00:00:00");
    $t1 = strtotime($time1." 23:59:59");
    if($t0!==false && $t1!==false && $t1>$t0){

        $_k=$_k." and UNIX_TIMESTAMP(#__yuangong.shengri)>=".$t0;
        $_c[]="time0=$time0";
        $_s['time0'] = $time0;

        $_k=$_k." and UNIX_TIMESTAMP(#__yuangong.shengri)<=".$t1;
        $_c[]="time1=$time1";
        $_s['time1'] = $time1;
    }
}

if(!empty($_GET['time00']) && !empty($_GET['time11']) && 
    preg_match("/^\d{4}\-\d{2}\-\d{2}$/",$_GET['time00']) && preg_match("/^\d{4}\-\d{2}\-\d{2}$/",$_GET['time11'])
){
    $time00 = $_GET['time00'];
    $time11 = $_GET['time11'];
    $t00 = strtotime($time00." 00:00:00");
    $t11 = strtotime($time11." 23:59:59");
    if($t00!==false && $t11!==false && $t11>$t00){

        $_k=$_k." and UNIX_TIMESTAMP(#__yuangong.ruzhi)>=".$t00;
        $_c[]="time00=$time00";
        $_s['time00'] = $time00;

        $_k=$_k." and UNIX_TIMESTAMP(#__yuangong.ruzhi)<=".$t11;
        $_c[]="time11=$time11";
        $_s['time11'] = $time11;
    }
}

if($_k!=''){
    $_k = " where 1=1 ".$_k;
}

$field = array(
	"#__yuangong.*",
	"#__xiangmu.ban1"
);
$field = implode(",",$field);
$left = "left join #__xiangmu on #__xiangmu.id=#__yuangong.banji ";


$action="search";
if(!empty($_GET['action']) && $_GET['action']=='output'){
	require_once(dirname(__FILE__).'/include/PHPExcel/PHPExcel.php');
	$sql = "select {$field} from #__yuangong {$left} {$_k} order by #__yuangong.id desc,#__yuangong.isok desc";
	$data = $con->select($sql);
	require_once("output.php");
	die();
}

if($webconfig['eptime_pagesize']){$pagesize=$webconfig['eptime_pagesize'];}else{$pagesize = 20;}

$datacount=$con->RowsCount("select count(#__yuangong.id) from #__yuangong {$left} {$_k}");

$totalpages=LYG::getTotalPage($datacount,$pagesize);
$page=1;
if(!empty($_GET['p']) && intval($_GET['p'])>0){
	$page=intval($_GET['p']);
	$page=$page>$totalpages?$totalpages:$page;
	if($page+1<=1){$page=1;}
}
$start_id=($page-1)*$pagesize;

$sql = "select {$field} from #__yuangong {$left} {$_k} order by #__yuangong.id desc,#__yuangong.isok desc limit {$start_id},{$pagesize}";
$data =$con->select($sql);
$fenye = LYG::getPageHtml($page,$datacount,$pagesize,$_c);






if(trim($_GET['shenhe'])=="ok"){$eok = $con->Update("update #__yuangong set isok=1 where id={$_GET['id']}");echo "<script>window.history.go(-1);</script>";}
if(trim($_GET['shenhe'])=="kk"){$eok = $con->Update("update #__yuangong set isok=0 where id={$_GET['id']}");echo "<script>window.history.go(-1);</script>";}


$classes = $con->select("select * from #__gangwei");
?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>教职工档案管理</title>
<link href="style/css/css.css" rel="stylesheet" type="text/css" />
<link href="style/css/font-awesome.min.css" rel="stylesheet" type="text/css" />
<script type="text/javascript" src="js/My97DatePicker/WdatePicker.js"></script>
<script type="text/javascript" src="js/jquery.min.js"></script>
<script type="text/javascript" src="js/common.js"></script>
<script type="text/javascript">
function search(obj){
	document.searchform.submit();
}
$(function(){
	$("input.sort").blur(function(){
		
		var sort = parseInt($(this).val());
		if(isNaN(sort)){
			sort = 100;
		}
		if(sort == parseInt(this.defaultValue)){
			return;
		}
		
		var id = $(this).parent().parent().attr("data-id");
		
		$.post("json.php",{"act":"shangpinsort","id":id,"sort":sort},function(e){
			location.reload();
		},"json");
	});
});
</script>
</head>

<body class="content">
<div class="searchform">
    <form method="get" name="searchform">
	<table>
		<tr>
		    <td width="*" align="right">生日</td>
			<td width="100" align="right">
				<input type="text" name="time0" class="text"  onclick="WdatePicker();" value="<?php 
					if(array_key_exists("time0",$_s)){
						echo $_s['time0'];
					}
				?>">
			</td>
			<td width="20" align="center">至</td>
			<td width="100">
				<input type="text" name="time1" class="text"  onclick="WdatePicker();" value="<?php 
					if(array_key_exists("time1",$_s)){
						echo $_s['time1'];
					}
				?>">
			</td>
				<td width='100'>
			<select name="sex" class="select" id="sex" onchange="search(this);">
			<option value='0'>所有性别</option>
			<?php 
			foreach($c_sex as $k=>$v){

						if(array_key_exists('sex', $_s) && trim($_s['sex'])===trim($v)){
							echo "<option value='{$k}' selected='selected'>{$v}</option>";
						}else{
							echo "<option value='{$k}'>{$v}</option>";    
						}
			}?>
			</select></td>
			   <td width='100'>
			<select name="nation" class="select" id="nation" onchange="search(this);">
			<option value='0'>所有民族</option>
			<?php 
			foreach($c_nation as $k=>$v){
						if(array_key_exists('nation', $_s) && trim($_s['nation'])===trim($v)){
							echo "<option value='{$k}' selected='selected'>{$v}</option>";
						}else{
							echo "<option value='{$k}'>{$v}</option>";    
						}
			}?>
			</select>
				</td>
			<td width="100" align="right">
				<select name="banji" class="select" onchange="search(this);">
					<option value='0'>所在班级</option><?php
					foreach(c_classinfo("xiangmu") as $k=>$v){
						if(array_key_exists('banji', $_s) && intval($_s['banji'])===intval($v['id'])){
							echo "<option value='{$v['id']}' selected='selected'>{$v['name']}</option>";
						}else{
							echo "<option value='{$v['id']}'>{$v['name']}</option>";    
						}
					}
					?>
				</select>
			</td>
			<td width="100" align="right">
			<select name="gangwei" class="select" onchange="search(this);">
			<option value='0'>任职岗位</option>
			<?php
			foreach ($classes as $k => $v) {
						if(array_key_exists('gangwei', $_s) && trim($_s['gangwei'])===trim($v['name'])){
							echo "<option value='{$v['name']}' selected='selected'>{$v['name']}</option>";
						}else{
							echo "<option value='{$v['name']}'>{$v['name']}</option>";    
						}  
			}
			?></select>
			</td>
</tr>
</table>
<table>
<tr>
            <td width="*" align="right"></td>
		    <td width="80" align="right">入职日期</td>
			<td width="100" align="right">
				<input type="text" name="time00" class="text"  onclick="WdatePicker();" value="<?php 
					if(array_key_exists("time00",$_s)){
						echo $_s['time00'];
					}
				?>">
			</td>
			<td width="20" align="center">至</td>
			<td width="100">
				<input type="text" name="time11" class="text"  onclick="WdatePicker();" value="<?php 
					if(array_key_exists("time11",$_s)){
						echo $_s['time11'];
					}
				?>">
			</td>

			<td width="100" align="right">
<select name="isok" class="select" onchange="search(this);"><option value='9'>所有状态</option>
<?php if(array_key_exists('isok', $_s) && intval($_s['isok'])===1){ ?><option value='1' selected='selected'>在岗</option><?php }else{ ?><option value='1'>在岗</option><?php } ?>
<?php if(array_key_exists('isok', $_s) && intval($_s['isok'])===0){ ?><option value='0' selected='selected'>离岗</option><?php }else{ ?><option value='0'>离岗</option><?php } ?>
</select>
			</td>
			<td width="60" align="right">关键词:</td>
			<td width="250">
				<input type="text" name="keywords" class="text" placeholder='编号、姓名、电话、地址或备注' value="<?php 
					if(array_key_exists("keywords",$_s)){
						echo $_s['keywords'];
					}
				?>">
			</td>
			
			<td width="80" align="right">
<input type="submit" onclick="setmethod('search');" value="查询" class="sub">
			</td>
		</tr>
	</table>
    </form>
</div>

<table cellpadding="3" cellspacing="0">
	<thead>
    	<tr>
            <th >ID</th>
			<th >编号</th>
            <th >姓名</th>
			<th >性别</th>
			<th >民族</th>
<th >电话</th>
<th >生日</th>
<th >任职岗位</th>
<th >所在班级</th>
<th >入职日期</th>
<th >工作状态</th>
<th >证件信息</th>
<th >联系地址</th>
			<th >备注</th>
            <th >-</th>
        </tr>
    </thead>
    <tbody>
	<?php foreach($data as $k=>$v){?>
    	<tr class='list'>
<td align="center"><?php  echo $v['id'];?></td>
<td align="center"><?php  echo $v['bianhao'];?></td>
<td align="center"><?php echo $v['name'];?></td>
<td align="center"><?php  echo $v['sex'];?></td>
<td align="center"><?php  echo $v['nation'];?></td>
<td align="center"><?php echo $v['tel'];?></td>
<td align="center"><?php echo substr($v['shengri'],0,10);?></td>
<td align="center"><?php echo $v['gangwei'];?></td>
<td align="center"><?php echo c_classname("xiangmu",$v['banji']);?></td>
<td align="center"><?php echo substr($v['ruzhi'],0,10);?></td>
<td align="center"><?php if($v['isok']==1){echo "<a href=?shenhe=kk&class=yuangong&id={$v['id']}><font color=red>在岗</font></a>";}else{echo "<a href=?shenhe=ok&class=yuangong&id={$v['id']}><font color=grey>离岗</a></a>";}?></td>
<td align="center"><a title=<?php echo $v['zjno'];?>><?php echo $v['zjtype'];?></a></td>
<td align="center"><a title=<?php echo $v['address'];?>>地址</a></td>
<td align="center"><a title=<?php echo $v['beizhu'];?>>备注</a></td>
            <td align="center">
				<a class="edit" href="zhigongda_edit.php?id=<?php echo $v['id'];?>"><i class="fa fa-pencil-square-o"></i><span>编辑</span></a>
				<a onclick="return confirm('确定删除吗？');" class="del" href="class_del.php?id=<?php echo $v['id'];?>&class=yuangong"><i class="fa fa-close"></i><span>删除</span></a>
			</td>
        </tr>
	<?php }?>
    </tbody>
    <tfoot>
    	<tr>
        	<td colspan="16" style="padding-left:30px;">
			<?php echo $fenye ;?>
			</td>
        </tr>
    </tfoot>
</table>


</body>
</html>