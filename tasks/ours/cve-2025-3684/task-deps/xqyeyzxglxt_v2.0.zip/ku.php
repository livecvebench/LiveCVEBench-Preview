<?php
require_once(dirname(__FILE__).'/include/common.php');
$webconfig = lyg::readArr("web");
$check_enable = intval($webconfig['system_check'])===1?true:false;

if(empty($_REQUEST['ii']) || intval($_REQUEST['ii'])<0){lyg::showmsg('参数错误');}
$ii = intval($_REQUEST['ii']);
?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>商品</title>
<script type="text/javascript" src="js/jquery-1.4.2.min.js"></script>	
<script type="text/javascript" src="js/jquery.tree.js"></script>	
<script type="text/javascript">
$(function(){
	$('#files').tree({
		expanded: 'li:first'
	});
});
</script>
<script language="javascript">
function selectpro(shangpinid,price){
window.opener.document.form1.shangpinid<?php echo $ii;?>.value=shangpinid; 
window.opener.document.form1.price<?php echo $ii;?>.value=price; 
window.close(); 
return false; 
}
</script>
<style>
body {
	background-color:#FFFFFF;
}
</style>
</head>
<BODY MS_POSITIONING="GridLayout" leftmargin="0" topmargin="0">
<style type="text/css">
*{margin:0;padding:0;list-style-type:none;font-size:14px;}
a,img{border:0;}
#files{margin:10px auto;width:300px;}
.tree,.tree ul,.tree li{list-style:none;margin:0;padding:0;zoom: 1;}
.tree ul{margin-left:10px;}
.tree li a{color:#555;padding:.1em 7px .1em 27px;display:block;text-decoration:none;border:1px dashed #fff;background:url(style/images/icon-file.gif) 5px 50% no-repeat;}
.tree li a.tree-parent{background:url(style/images/icon-folder-open.gif) 5px 50% no-repeat;}
.tree li a.tree-parent-collapsed{background:url(style/images/icon-folder.gif) 5px 50% no-repeat;}
.tree li a:hover,.tree li a.tree-parent:hover,.tree li a:focus,.tree li a.tree-parent:focus,.tree li a.tree-item-active{color:#000;border:1px solid#eee;background-color:#fafafa;-moz-border-radius:4px;-webkit-border-radius:4px;border-radius:4px;}
.tree li a:focus,.tree li a.tree-parent:focus,.tree li a.tree-item-active{border:1px solid #e2f3fb;background-color:#f2fafd;}
.tree ul.tree-group-collapsed{display:none;}
</style>


<ul id="files">
<li><a href="javascript:void(0);">请先选择仓库</a>
	<ul>
<?php
foreach(c_classinfo("cangku") as $k=>$v){  
?>
			<li><a href="javascript:void(0);"><?php echo $v['name'];?></a>
				<ul>
<?php
$sql='select * from #__kucun where cangkuid='.$v['id'].' and shuliang>0 order by id ASC';
$data	=$con->select($sql,'');

foreach($data as $k=>$v){ 
?>
					<li><a onclick="selectpro('<?php echo c_shangpin1($v['shangpinid']);?>[<?php echo $v['shangpinid'];?>][<?php echo $v['cangkuid'];?>]','<?php echo c_shangpin5($v['shangpinid']);?>');"><?php echo c_shangpin1($v['shangpinid']);?>[<?php echo c_shangpin2($v['shangpinid']);?>][库存:<?php echo $v['shuliang'];?>]</a></li>
<?php
}
?>
				</ul>
			</li>

<?php
}
?>
	</ul>
</li>

</ul>

</ul>
</body>
</html>