<?php
require_once(dirname(__FILE__).'/include/common.php');
$webconfig = lyg::readArr("web");
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>左侧</title>
<link href="style/css/css.css" rel="stylesheet" type="text/css" />
</head>
	<style>
		*{ margin: 0; padding: 0; overflow:hidden;}
		img{border:0;}
        ul,li{list-style-type:none;}
		a {color:#00007F;text-decoration:none;}
		a:hover {color:#bd0a01;text-decoration:underline;}
		.treebox{ width: 200px; margin: 0 auto; background-color:#F4F4F4; }
		.menu{ overflow: hidden; border-color: #ddd; border-style: solid ; border-width: 0 1px 1px ; }
		/*第一层*/
		.menu li.level1>a{ 
			display:block;
			height: 40px;
			line-height: 40px;
			color: #000;
			padding-left: 50px;
			border-bottom: 1px solid #FFF; 
			font-size: 15px;
			position: relative;
		 }
		 .menu li.level1 a:hover{ text-decoration: none;background-color:#01C0C8;color:#FFF;   }
		 .menu li.level1 a.current{ background: #E0E0E2; }

		/*============修饰图标*/
		 .ico{ width: 20px; height: 20px; display:block;   position: absolute; left: 20px; top: 10px; background-repeat: no-repeat; background-image: url(style/images/img/ico1.png); }

		 /*============小箭头*/
		 .level1 i{ width: 20px; height: 10px; background-image:url(style/images/img/arrow.png); background-repeat: no-repeat; display: block; position: absolute; right: 20px; top: 15px; }
		.level1 i.down{ background-position: 0 -10px; }

		 .ico1{ background-position: 0 0; }
		 .ico2{ background-position: 0 -20px; }
		 .ico3{ background-position: 0 -40px; }
		 .ico4{ background-position: 0 -60px; }
         .ico5{ background-position: 0 -80px; }
		 .ico6{ background-position: 0 -100px; }
		 .ico7{ background-position: 0 -120px; }
		 .ico8{ background-position: 0 -140px; }

		 /*第二层*/
		 .menu li ul{ overflow: hidden; }
		 .menu li ul.level2{ display: none;background: #E0E0E2;  }
		 .menu li ul.level2 li a{
		 	display: block;
			height: 40px;
			line-height: 40px;
			color: #000;
			text-indent: 50px;
			/*border-bottom: 1px solid #ddd; */
			font-size: 14px;
		 }

	</style>
<body>

	<div class="treebox">
		<ul class="menu">
			<li class="level1">
				<a href="#none"><em class="ico ico8"></em>收费管理<i></i></a>
				<ul class="level2">
					<li><a href="nav.php?list=11" target="right">收费记录</a></li>
					<li><a href="nav.php?list=12" target="right">收费统计</a></li>
				</ul>
			</li>

			<li class="level1">
				<a href="#none"><em class="ico ico7"></em><?php echo $webconfig['system_wanglai'];?>管理<i></i></a>
				<ul class="level2">
					<li><a href="nav.php?list=21" target="right">请假记录</a></li>
					<li><a href="nav.php?list=22" target="right"><?php echo $webconfig['system_wanglai'];?>档案</a></li>
				</ul>
			</li>

			<li class="level1">
				<a href="#none"><em class="ico ico6"></em><?php echo $webconfig['system_yuangong'];?>管理<i></i></a>
				<ul class="level2">
					<li><a href="nav.php?list=31" target="right">工资管理</a></li>
					<li><a href="nav.php?list=32" target="right"><?php echo $webconfig['system_yuangong'];?>档案</a></li>
				</ul>
			</li>

			<li class="level1">
				<a href="#none"><em class="ico ico5"></em>库存管理<i></i></a>
				<ul class="level2">
					<li><a href="nav.php?list=41" target="right">采购记录</a></li>
					<li><a href="nav.php?list=42" target="right">领取记录</a></li>
					<li><a href="nav.php?list=43" target="right">库存信息</a></li>
				</ul>
			</li>

			<li class="level1">
				<a href="#none"><em class="ico ico4"></em>财务管理<i></i></a>
				<ul class="level2">
					<li><a href="nav.php?list=51" target="right">日常记账</a></li>
					<li><a href="nav.php?list=52" target="right">资金管理</a></li>
					<li><a href="nav.php?list=53" target="right">报表统计</a></li>
				</ul>
			</li>

<?php if ($_SESSION['eptime_adminPower']==0) {?>
			<li class="level1">
				<a href="#none"><em class="ico ico2"></em>系统设置<i></i></a>
				<ul class="level2">
<li><a href="zhanghu_list.php" target="right">账户管理</a></li>
<li><a href="nav.php?list=65" target="right">收支分类</a></li>
<li><a href="class_list.php?class=xiangmu" target="right"><?php echo $webconfig['system_xiangmu'];?>管理</a></li>
<li><a href="shangpin_list.php" target="right">商品管理</a></li>
<li><a href="class_list.php?class=cangku" target="right">仓库管理</a></li>
<li><a href="user_list.php" target="right">用户管理</a></li>
<li><a href="nav.php?list=66" target="right">基础设置</a></li>	
				</ul>
			</li>

            <li class="level1">
				<a href="#none"><em class="ico ico1"></em>关于系统<i></i></a>
				<ul class="level2">
	<li><a href="config_system_email.php" target="right">授权信息</a></li>
	<li><a href="update.php" target="right">在线升级</a></li>
				</ul>
			</li>
<?php }?>
		</ul>
	</div>
	<!-- 引入 jQuery -->
<script src="style/js/jquery1.8.3.min.js" type="text/javascript"></script>
<script src="style/js/easing.js"></script>
<script>
//等待dom元素加载完毕.
	$(function(){
		$(".treebox .level1>a").click(function(){
			$(this).addClass('current')   //给当前元素添加"current"样式
			.find('i').addClass('down')   //小箭头向下样式
			.parent().next().slideDown('slow','easeOutQuad')  //下一个元素显示
			.parent().siblings().children('a').removeClass('current')//父元素的兄弟元素的子元素去除"current"样式
			.find('i').removeClass('down').parent().next().slideUp('slow','easeOutQuad');//隐藏
			 return false; //阻止默认时间
		});
	})
</script>
</body>
</html>