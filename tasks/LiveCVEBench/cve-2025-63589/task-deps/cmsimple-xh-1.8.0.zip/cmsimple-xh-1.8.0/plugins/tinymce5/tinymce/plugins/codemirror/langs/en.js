tinymce.addI18n('en',{
	'HTML source code': 'HTML source code',
	'Start search': 'Start search',
	'Find next': 'Find next',
	'Find previous': 'Find previous',
	'Replace': 'Replace',
	'Replace all': 'Replace all'
});
