<?php
require_once(dirname(__FILE__).'/include/common.php');
if (strpos($_SESSION['eptime_flag'], 'kucunlfig') === false) {LYG::ShowMsg('您没有权限！');} 

$_k = "";
$_v = array();

$_c = array();//分页条件
$_s = array();//搜索条件

if(!empty($_GET['cangku']) && intval($_GET['cangku'])>0){
    $_k=$_k." and #__kucun.cangkuid=".intval($_GET['cangku']);
    $_c[]="cangku=".intval($_GET['cangku']);
    $_s['cangku'] = intval($_GET['cangku']);
}

if(!empty($_GET['fenlei']) && intval($_GET['fenlei'])>0){
    $_k=$_k." and #__shangpin.fenlei=".intval($_GET['fenlei']);
    $_c[]="fenlei=".intval($_GET['fenlei']);
    $_s['fenlei'] = intval($_GET['fenlei']);
}

if(!empty($_GET['keywords']) && trim($_GET['keywords'])!=''){
    $_k=$_k." and (#__shangpin.name like '%".trim($_GET['keywords'])."%' or #__shangpin.bianhao like '%".trim($_GET['keywords'])."%' or #__shangpin.xinghao like '%".trim($_GET['keywords'])."%' or #__shangpin.beizhu like '%".trim($_GET['keywords'])."%')";
    $_c[]="keywords=".trim($_GET['keywords']);
    $_s['keywords'] = trim($_GET['keywords']);
}

if($_k!=''){
    $_k = " where 1=1 ".$_k;
}

$field = array(
	"#__kucun.*",
	"#__shangpin.name,bianhao,fenlei,xinghao,danwei,price"
);
$field = implode(",",$field);
$left = "left join #__shangpin on #__shangpin.id=#__kucun.shangpinid ";


$action="search";
if(!empty($_GET['action']) && $_GET['action']=='output'){
	require_once(dirname(__FILE__).'/include/PHPExcel/PHPExcel.php');
	$sql = "select {$field} from #__kucun {$left} {$_k} order by #__kucun.id desc,#__shangpin.name desc";
	$data = $con->select($sql);
	require_once("output.php");
	die();
}

$sqla = "select {$field} from #__kucun {$left} {$_k} order by #__kucun.id desc,#__shangpin.name desc";
$dataa = $con->select($sqla);
$nowprice1=0;
$nowprice11=0;
$nowprice2=0;
foreach($dataa as $k=>$v){
$nowprice1=$nowprice1+$v['shuliang'];
$nowprice11=$nowprice11+$v['shuliangr'];
$nowprice2=$nowprice2+$v['price']*$v['shuliangr'];
                        }


if($webconfig['eptime_pagesize']){$pagesize=$webconfig['eptime_pagesize'];}else{$pagesize = 20;}

$datacount=$con->RowsCount("select count(#__kucun.id) from #__kucun {$left} {$_k}");

$totalpages=LYG::getTotalPage($datacount,$pagesize);
$page=1;
if(!empty($_GET['p']) && intval($_GET['p'])>0){
	$page=intval($_GET['p']);
	$page=$page>$totalpages?$totalpages:$page;
	if($page+1<=1){$page=1;}
}
$start_id=($page-1)*$pagesize;

$sql = "select {$field} from #__kucun {$left} {$_k} order by #__kucun.id desc limit {$start_id},{$pagesize}";
$data =$con->select($sql);
$fenye = LYG::getPageHtml($page,$datacount,$pagesize,$_c);
?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title></title>
<link href="style/css/css.css" rel="stylesheet" type="text/css" />
<link href="style/css/font-awesome.min.css" rel="stylesheet" type="text/css" />
<script type="text/javascript" src="js/jquery.min.js"></script>
<script type="text/javascript" src="js/common.js"></script>
<SCRIPT language=javascript> 
function openScript(url, width, height) {
        var Win = window.open(url,"openScript",'width=' + width + ',height=' + 
 
height + ',resizable=0,scrollbars=no,menubar=no,status=no' );
}
</SCRIPT>
<script type="text/javascript">
function search(obj){
	document.searchform.submit();
}
$(function(){
	$("input.sort").blur(function(){
		
		var sort = parseInt($(this).val());
		if(isNaN(sort)){
			sort = 100;
		}
		if(sort == parseInt(this.defaultValue)){
			return;
		}
		
		var id = $(this).parent().parent().attr("data-id");
		
		$.post("json.php",{"act":"shangpinsort","id":id,"sort":sort},function(e){
			location.reload();
		},"json");
	});
});
</script>
</head>

<body class="content">


<div class="searchform">
    <form method="get" name="searchform">
	<table>
		<tr>
		    <td width="*" align="right"></td>
			<td width="200" align="right">
			<select name="cangku" class="select bai" onchange="search(this);">
				<option value='0'>所有仓库</option>
           <?php
			foreach (c_classinfo("cangku") as $k => $v) {
				if(array_key_exists('cangku', $_s) && intval($_s['cangku'])===intval($v['id'])){
					echo "<option value='{$v['id']}' selected='selected'>{$v['name']}</option>";
				}else{
					echo "<option value='{$v['id']}'>{$v['name']}</option>";    
				}                    
			}
			?>
            </select>
			</td>
			<td width="200" align="right">
			<select name="fenlei" class="select bai" onchange="search(this);">
				<option value='0'>所有商品分类</option>
           <?php
			foreach (c_classinfo("fenlei") as $k => $v) {
				if(array_key_exists('fenlei', $_s) && intval($_s['fenlei'])===intval($v['id'])){
					echo "<option value='{$v['id']}' selected='selected'>{$v['name']}</option>";
				}else{
					echo "<option value='{$v['id']}'>{$v['name']}</option>";    
				}                    
			}
			?></select>
			</td>
			<td width="60" align="right">关键词:</td>
			<td width="180">
				<input type="text" name="keywords" class="text" placeholder='编号、名称、规格型号或备注' value="<?php 
					if(array_key_exists("keywords",$_s)){
						echo $_s['keywords'];
					}
				?>">
			</td>
			
			<td width="80" align="right">
<input type="submit" onclick="setmethod('search');" value="查询" class="sub">
			</td>
		</tr>
	</table>
    </form>
	<table>
		<tr>
		<td width="*" align="right"></td>
			<td width="80%" align="right">
			库存总数量：<b><?php echo $nowprice1;?></b> ，实际库存总数量：<b><?php echo $nowprice11;?></b> ，损耗：<b><?php echo round(($nowprice1-$nowprice11)/$nowprice1*100,2)."%";?></b>，实际库存总价值：<b><?php echo $nowprice2;?></b> 元&nbsp;
			</td>
			</tr>
	</table>
</div>




<table cellpadding="3" cellspacing="0">
	<thead>
    	<tr>
            <th>ID</th>
            <th>仓库</th>
			<th>商品分类</th>
            <th>商品编号</th>
			<th>商品名称</th>
            <th>规格型号</th>
            <th>单位</th>
			<th>当前库存</th>
			<th>实际库存</th>
			<th>损耗(%)</th>
			<th>单价</th>
			<th>价值</th>
			<th>--</th>
        </tr>
    </thead>
    <tbody>
	<?php foreach($data as $k=>$v){?>
    	<tr class='list' data-id="<?php echo $v['id'];?>">
        	<td align="center"><?php echo $v['id'];?></td>
			<td align="center"><?php echo c_classname('cangku',$v['cangkuid']);?></td>
			<td align="center"><?php echo c_classname('fenlei',$v['fenlei']);?></td>
        	<td align="center"><?php echo $v['bianhao'];?></td>
			<td align="center"><?php echo $v['name'];?></td>
			<td align="center"><?php echo $v['xinghao'];?></td>
			<td align="center"><?php echo $v['danwei'];?></td>
			<td align="center"><?php echo round($v['shuliang'],2);?></td>
			<td align="center"><?php echo round($v['shuliangr'],2);?></td>
			<td align="center"><?php echo round(($v['shuliang']-$v['shuliangr'])/$v['shuliang']*100,2)."%";?></td>
        	<td align="center"><?php echo round($v['price'],2);?></td>
			<td align="center"><?php echo round($v['price']*$v['shuliangr'],2);?></td>
			<td align="center"><a href='javascript:openScript("kucun_diao.php?id=<?php echo $v['id'];?>",400,400)'>调拨</a> <a href='javascript:openScript("kucun_pan.php?id=<?php echo $v['id'];?>",400,400)'>盘点</a></td>
        </tr>
	<?php }?>
    </tbody>
    <tfoot>
    	<tr>
        	<td colspan="13" style="padding-left:30px;">
			<?php echo $fenye ;?>
			</td>
        </tr>
    </tfoot>
</table>


</body>
</html>