<?php

require_once(dirname(__FILE__).'/include/common.php');
$webconfig = lyg::readArr("web");
$check_enable = intval($webconfig['system_check'])===1?true:false;

if(empty($_REQUEST['id']) || intval($_REQUEST['id'])<1){lyg::showmsg('参数错误');}
$dataid = intval($_REQUEST['id']);
$info=  $con->find("select * from #__gongzi where id=$dataid");
if(empty($info)){lyg::showmsg('参数错误');}


	
?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>详情</title>
<link href="style/css/css.css" rel="stylesheet" type="text/css" />
<link href="style/css/font-awesome.min.css" rel="stylesheet" type="text/css" />
<link href="style/css/font-awesome.min.css" rel="stylesheet" type="text/css" />
<style type="text/css">
label{margin-right:10px;}
</style>
<script type="text/javascript" src="js/My97DatePicker/WdatePicker.js"></script>
<script type="text/javascript" src="js/jquery.min.js"></script>
<script type="text/javascript" src="js/common.js"></script>
		<link rel="stylesheet" href="kindeditor/themes/default/default.css" />
		<script src="kindeditor/kindeditor-all.js" charset="UTF-8"></script>
		<script src="kindeditor/lang/zh-CN.js" charset="UTF-8"></script>
		<script>
			KindEditor.ready(function(K) {
				var editor = K.editor({
					allowFileManager : true
				});
				K('#image3').click(function() {
					editor.loadPlugin('image', function() {
						editor.plugin.imageDialog({
							showRemote : false,
							imageUrl : K('#url3').val(),
							clickFn : function(url, title, width, height, border, align) {
								K('#url3').val(url);
								editor.hideDialog();
							}
						});
					});
				});
			});
		</script>
</head>


<body class="content">
<style type="text/css">
@media print { 
 .noprint{display:none;}
}
</style>
<div align="right" class="noprint">
<a href='javascript:window.print()'>打印此页</a>
</div>


<div class="list-menu">
	<ul>
		<li>基本信息</li>
	</ul>
</div>

<table cellpadding="3" cellspacing="0" class="table-add">
  <tr>
    <td align="right" height='36' width="100px">教工编号：</td>
    <td width="150px"><?php  echo c_yuanggong1($info['ygid']);?></td>
    <td align="right" height='36' width="100px">教工姓名：</td>
    <td width="150px"><?php  echo c_yuanggong2($info['ygid']);?></td>
  </tr>
  <tr>
    <td align="right">任职岗位：</td>
    <td><?php  echo c_yuanggong3($info['ygid']);?></td>
    <td align="right">工资月份：</td>
    <td><?php echo $info['yuefen'];?></td>
  </tr>
</table>


<div class="list-menu">
	<ul>
		<li>工资信息</li>
	</ul>
</div>


<table cellpadding="3" cellspacing="0" class="table-add">
		<tr>
			<td align="right" height='36' width="100px">基本工资：</td>
			<td width="150px">
			<?php echo $info['jiben'];?>
			</td>
			<td align="right" height='36' width="100px">绩效考核：</td>
			<td width="150px">
			<?php echo $info['kaohe'];?>
			</td>
		</tr>
		<tr>
			<td align="right" height='36'>人事考勤：</td>
			<td>
			<?php echo $info['kaoqin'];?>
			</td>
			<td align="right" height='36'>补贴：</td>
			<td>
			<?php echo $info['butie'];?>
			</td>
		</tr>
		<tr>
			<td align="right" height='36'>社保公积金：</td>
			<td>
			<?php echo $info['shebao'];?>
			</td>
			<td align="right" height='36'>个人所得税：</td>
			<td>
			<?php echo $info['shui'];?>
			</td>
		</tr>

		<tr>
			<td align="right" height='36' width="100px">其他扣除：</td>
			<td colspan="3" >
			<?php echo $info['qita'];?>
			</td>
		</tr>
		<tr>
			<td align="right" height='36' width="100px">应发工资：</td>
			<td width="150px">
			<?php echo $info['gongzi'];?>
			</td>
			<td align="right" height='36'>实发工资：</td>
			<td width="150px">
			<?php echo $info['gongzia'];?>
			</td>
		</tr>
	<tr>
		<td align="right" height='36'>备注：</td>
		<td align="left" colspan="3" ><?php echo $info['beizhu'];?></td>
	</tr>
</table>
<div class="list-menu">
	<ul>
		<li>其他信息</li>
	</ul>
</div>
<table  cellpadding="3" cellspacing="0" class="table-add">
		<tr>
			<td align="right" height='36' width="100px">核算人：</td>
			<td width="150px">
			<?php echo $info['hesuan'];?>
			</td>
			<td align="right" height='36' width="100px">核算时间：</td>
			<td width="150px">
			<?php echo $info['addtime'];?>
			</td>
		</tr>
		<tr>
			<td align="right" height='36' width="100px">发放人：</td>
			<td width="150px">
			<?php echo $info['fa'];?>
			</td>
			<td align="right" height='36' width="100px">发放时间：</td>
			<td width="150px">
			<?php echo $info['fatime'];?>
			</td>
		</tr>


</table>

</body>
</html>