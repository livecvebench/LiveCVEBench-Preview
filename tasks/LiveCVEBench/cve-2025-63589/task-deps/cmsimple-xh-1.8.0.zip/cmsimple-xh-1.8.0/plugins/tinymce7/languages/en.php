<?php
$plugin_tx['tinymce7']['cf_init'] = "The size of the toolbar";
$plugin_tx['tinymce7']['cf_CDN_alt_src']="alternate CDN Source";
$plugin_tx['tinymce7']['cf_CDN']="CDN Version if checked. BE AWARE when using CDN you fetch from a foreign server and leave personal data (IP address) there";
$plugin_tx['tinymce7']['menu_main']="About...";
$plugin_tx['tinymce7']['cf_utf-8_marker']="<p>Internal usage. <strong>Do not change!</strong></p>";