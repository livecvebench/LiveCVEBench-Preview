<?php

$plugin_cf['tinymce5']['init']="dropdown";
$plugin_cf['tinymce5']['utf8_marker']="äöü";
$plugin_cf['tinymce5']['CDN_src']="https://cdn.tiny.cloud/1/no-api-key/tinymce/5/tinymce.min.js";
$plugin_cf['tinymce5']['CDN']="";
