<?php

$plugin_mcf['fa']['require_auto']="bool";

$plugin_mcf['fa']['fontawesome_version']="enum:4,5";
$plugin_mcf['fa']['fontawesome_shim']="bool";
