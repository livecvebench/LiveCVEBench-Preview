<?php
$tpl_tx['text']['sitename_logobox']="<a href=\"./\" title=\"Startseite\"><img src='" . $pth['folder']['templateimages'] . "logo.png' alt='Logo'></a>";
$tpl_tx['text']['sitename_slogan']="CMSimple_XH Template";
$tpl_tx['text']['language_select']="<img src='" . $pth['folder']['templateimages'] . "gmi_language.svg' alt='Sprache wählen'><span>&nbsp;&nbsp;Sprache wählen</span>";
$tpl_tx['text']['legalnotice']="Impressum";
$tpl_tx['text']['privacy']="Datenschutz";
$tpl_tx['text']['mailform']="Kontakt";
$tpl_tx['text']['modal-overlay']="Fenster schließen";
$tpl_tx['text']['menu_button']="Menü & News";
$tpl_tx['text']['pagetools_to-top']="Nach oben";
$tpl_tx['text']['footer_company-name']="Firmenname";

// Config languagemenu (select the display of the language menu)
$cf['language']['menu']="dd_longname"; // Options: flags|shortname|longname|flagsandshortname|flagsandlongname|dd_longname|dd_flagsandlongname (dd_=Dropdownmenu)
