<?php

require_once(dirname(__FILE__).'/include/common.php');
if (strpos($_SESSION['eptime_flag'], 'feilfig') === false) {LYG::ShowMsg('您没有权限！');}

$webconfig = lyg::readArr("web");

$_k = "";
$_v = array();

$_c = array();//分页条件
$_s = array();//搜索条件

if(!empty($_GET['jingban']) && intval($_GET['jingban'])>0){
    $_k=$_k." and #__fei.jingban=".intval($_GET['jingban']);
    $_c[]="jingban=".intval($_GET['jingban']);
    $_s['jingban'] = intval($_GET['jingban']);
}

if(!empty($_GET['keywords']) && trim($_GET['keywords'])!=''){
    $_k=$_k." and (#__wanglai.name like '%".trim($_GET['keywords'])."%' or #__fei.moneyID like '%".trim($_GET['keywords'])."%' or #__fei.name like '%".trim($_GET['keywords'])."%' or #__fei.fangshi like '%".trim($_GET['keywords'])."%' or #__fei.beizhu like '%".trim($_GET['keywords'])."%')";
    $_c[]="keywords=".trim($_GET['keywords']);
    $_s['keywords'] = trim($_GET['keywords']);
}

if(!empty($_GET['time0']) && !empty($_GET['time1']) && 
    preg_match("/^\d{4}\-\d{2}\-\d{2}$/",$_GET['time0']) && preg_match("/^\d{4}\-\d{2}\-\d{2}$/",$_GET['time1'])
){
    $time0 = $_GET['time0'];
    $time1 = $_GET['time1'];
    $t0 = strtotime($time0." 00:00:00");
    $t1 = strtotime($time1." 23:59:59");
    if($t0!==false && $t1!==false && $t1>$t0){

        $_k=$_k." and UNIX_TIMESTAMP(#__fei.selldate)>=".$t0;
        $_c[]="time0=$time0";
        $_s['time0'] = $time0;

        $_k=$_k." and UNIX_TIMESTAMP(#__fei.selldate)<=".$t1;
        $_c[]="time1=$time1";
        $_s['time1'] = $time1;
    }
}


if($_k!=''){
    $_k = " where 1=1 ".$_k;
}

$field = array(
	"#__fei.*",
	"#__wanglai.name"
);
$field = implode(",",$field);
$left = "left join #__wanglai on #__wanglai.id=#__fei.stuid ";


$action="search";
if(!empty($_GET['action']) && $_GET['action']=='output'){
	require_once(dirname(__FILE__).'/include/PHPExcel/PHPExcel.php');
	$sql = "select {$field} from #__fei {$left} {$_k} order by #__fei.id desc,#__fei.isok desc";
	$data = $con->select($sql);
	require_once("output.php");
	die();
}

$sqla = "select {$field} from #__fei {$left} {$_k} order by #__fei.id desc,#__fei.isok desc";
$dataa = $con->select($sqla);
$nowprice1=0;
foreach($dataa as $k=>$v){
$nowprice1=$nowprice1+$v['price'];
                        }


if($webconfig['eptime_pagesize']){$pagesize=$webconfig['eptime_pagesize'];}else{$pagesize = 20;}

$datacount=$con->RowsCount("select count(distinct(#__fei.moneyID)) from #__fei {$left} {$_k}");

$totalpages=LYG::getTotalPage($datacount,$pagesize);
$page=1;
if(!empty($_GET['p']) && intval($_GET['p'])>0){
	$page=intval($_GET['p']);
	$page=$page>$totalpages?$totalpages:$page;
	if($page+1<=1){$page=1;}
}
$start_id=($page-1)*$pagesize;

$sql = "select {$field} from #__fei {$left} {$_k} group by #__fei.moneyID desc,#__fei.isok desc limit {$start_id},{$pagesize}";
$data =$con->select($sql);
$fenye = LYG::getPageHtml($page,$datacount,$pagesize,$_c);



if(trim($_GET['shenhe'])=="kk"){$eok = $con->Update("update #__wanglai set isok=1 where id={$_GET['stuid']}");
$eok1 = $con->Update("update #__fei set isok=0 where id={$_GET['id']}");echo "<script>window.history.go(-1); </script>";}

$classes = $con->select("select * from #__fangshi");
?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>记录</title>
<link href="style/css/css.css" rel="stylesheet" type="text/css" />
<link href="style/css/font-awesome.min.css" rel="stylesheet" type="text/css" />
<script type="text/javascript" src="js/My97DatePicker/WdatePicker.js"></script>
<script type="text/javascript" src="js/jquery.min.js"></script>
<script type="text/javascript" src="js/common.js"></script>
<SCRIPT language=javascript> 
function openScript(url, width, height) {
        var Win = window.open(url,"openScript",'width=' + width + ',height=' + 
 
height + ',resizable=0,scrollbars=no,menubar=no,status=no' );
}
</SCRIPT>
<script type="text/javascript">
function search(obj){
	document.searchform.submit();
}
$(function(){
	$("input.sort").blur(function(){
		
		var sort = parseInt($(this).val());
		if(isNaN(sort)){
			sort = 100;
		}
		if(sort == parseInt(this.defaultValue)){
			return;
		}
		
		var id = $(this).parent().parent().attr("data-id");
		
		$.post("json.php",{"act":"shangpinsort","id":id,"sort":sort},function(e){
			location.reload();
		},"json");
	});
});
</script>
</head>

<body class="content">
<div class="searchform">
    <form method="get" name="searchform">
	<table>
		<tr>
		    <td width="*" align="right">收费日期</td>
			<td width="100" align="right">
				<input type="text" name="time0" class="text"  onclick="WdatePicker();" value="<?php 
					if(array_key_exists("time0",$_s)){
						echo $_s['time0'];
					}
				?>">
			</td>
			<td width="20" align="center">至</td>
			<td width="100">
				<input type="text" name="time1" class="text"  onclick="WdatePicker();" value="<?php 
					if(array_key_exists("time1",$_s)){
						echo $_s['time1'];
					}
				?>">
			</td>
			<td width="200" align="right">
				<select name="jingban" class="select bai" onchange="search(this);">
					<option value='0'>所有经办人</option><?php
					foreach(c_classinfo("yuangong") as $k=>$v){
						if(array_key_exists('jingban', $_s) && intval($_s['jingban'])===intval($v['id'])){
							echo "<option value='{$v['id']}' selected='selected'>{$v['name']}</option>";
						}else{
							echo "<option value='{$v['id']}'>{$v['name']}</option>";    
						}
					}
					?>
				</select>
			</td>
			<td width="60" align="right">关键词:</td>
			<td width="240">
				<input type="text" name="keywords" class="text" placeholder='单号、姓名、费用名、付款方式或备注' value="<?php 
					if(array_key_exists("keywords",$_s)){
						echo $_s['keywords'];
					}
				?>">
			</td>
			
			<td width="80" align="right">
<input type="submit" onclick="setmethod('search');" value="查询" class="sub">
			</td>
		</tr>
	</table>
    </form>
	<table>
		<tr>
		<td width="*" align="right"></td>
			<td width="80%" align="right">
			合计：<b><?php echo $nowprice1;?></b> 元&nbsp;
			</td>
			</tr>
	</table>
</div>


<table cellpadding="3" cellspacing="0">
	<thead>
    	<tr>
            <th>单号</th>
            <th>姓名</th>
            <th>起止日期</th>
			<th>收费日期</th>
            <th>付款方式</th>
            <th>经办人</th>
			<th width="40%">
<table cellpadding="0" cellspacing="0">
    	<tr>
<td align="left" width="40%">费用项目</td>
<td align="left" width="20%">金额</td>
<td align="left" width="40%">备注</td>
        </tr>
</table>			
			
			</th>
        </tr>
    </thead>
    <tbody>
	<?php foreach($data as $k=>$v){?>

    	<tr class='list' data-id="<?php echo $v['id'];?>">
        	<td align="left"><a href='javascript:openScript("fei_info.php?id=<?php echo $v['moneyID'];?>",800,600)'><?php echo $v['moneyID'];?></a></td>
        	<td align="left"><?php echo c_classname("wanglai",$v['stuid']);?></td>
        	<td align="left"><?php echo substr($v['begindate'],0,10);?> -- <?php echo substr($v['enddate'],0,10);?></td>
			<td align="left"><?php echo substr($v['selldate'],0,10);?></td>
<td align="left"><?php echo $v['fangshi'];?></td>
<td align="left"><?php echo c_classname("yuangong",$v['jingban']);?></td>
<td align="left">

				<?php
$feiinfo = $con->select("select * from #__fei where moneyID='".$v['moneyID']."'");
				foreach($feiinfo as $k1=>$v1){
				?>

<table cellpadding="0" cellspacing="0">
    	<tr>
<td align="left" width="40%"><?php echo $v1['name'];?></td>
<td align="left" width="20%"><?php echo $v1['price'];?></td>
<td align="left" width="40%"><?php echo $v1['beizhu'];?></td>

        </tr>
</table>
				<?php
				}
				?>
</td>

        </tr>
	<?php }?>
    </tbody>
    <tfoot>
    	<tr>
        	<td colspan="12" style="padding-left:30px;">
			<?php echo $fenye ;?>
			</td>
        </tr>
    </tfoot>
</table>


</body>
</html>