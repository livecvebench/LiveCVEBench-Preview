<?php
require_once(dirname(__FILE__).'/include/common.php');
if (strpos($_SESSION['eptime_flag'], 'stumfig') === false) {LYG::ShowMsg('您没有权限！');}

if(empty($_REQUEST['id']) || intval($_REQUEST['id'])<1){lyg::showmsg('参数错误');}
$id = intval($_REQUEST['id']);
$info=  $con->find("select * from #__wanglai where id=$id");
if(empty($info)){lyg::showmsg('参数错误');}

if(!empty($_POST)){
	//参数校验
	extract($_POST);
if(empty($bianhao) || trim($bianhao)==''){
		LYG::ShowMsg('编号不能为空');
	}	
	if(empty($name) || trim($name)==''){
		LYG::ShowMsg('名称不能为空');
	}
$bianhao= trim($bianhao);
$name= trim($name);
$sex= trim($sex);
$nation= trim($nation);
$shengri= trim($shengri);
$pic= trim($pic);
$banji = intval($banji);
$ruzhi= trim($ruzhi);
$zjtype= trim($zjtype);
$zjno= trim($zjno);
$tel= trim($tel);
$address= trim($address);
$beizhu= trim($beizhu);

	$ex = $con->rowscount("select count(*) from #__wanglai where bianhao=? and id<>$id",array($bianhao));
	if($ex>0){
		lyg::showmsg("已存在");
	}
$eok = $con->update("update #__wanglai set bianhao=?, name=?,sex=?,nation=?,shengri=?,pic=?,banji=?,ruzhi=?,zjtype=?,zjno=?,tel=?,address=?,beizhu=? where id=$id limit 1",array($bianhao,$name,$sex,$nation,$shengri,$pic,$banji,$ruzhi,$zjtype,$zjno,$tel,$address,$beizhu));

	if($eok!==false){
		LYG::ShowMsg('操作成功','stu_list.php');
	}else{
		LYG::ShowMsg('操作失败，请重试');
	}
	die();
}
$classes = $con->select("select * from #__gangwei");	
?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>编辑<?php echo $c_class["{$class}"];?></title>
<link href="style/css/css.css" rel="stylesheet" type="text/css" />
<script type="text/javascript" src="js/My97DatePicker/WdatePicker.js"></script>
<script type="text/javascript" src="js/jquery.min.js"></script>
<script type="text/javascript" src="js/common.js"></script>
		<link rel="stylesheet" href="kindeditor/themes/default/default.css" />
		<script src="kindeditor/kindeditor-all.js" charset="UTF-8"></script>
		<script src="kindeditor/lang/zh-CN.js" charset="UTF-8"></script>
		<script>
			KindEditor.ready(function(K) {
				var editor = K.editor({
					allowFileManager : true
				});
				K('#image3').click(function() {
					editor.loadPlugin('image', function() {
						editor.plugin.imageDialog({
							showRemote : false,
							imageUrl : K('#url3').val(),
							clickFn : function(url, title, width, height, border, align) {
								K('#url3').val(url);
								editor.hideDialog();
							}
						});
					});
				});
			});
		</script>
</head>

<body class="content">

<h5 class='back' onclick='history.go(-1);'><span>返回</span></h5>

<form action='' method='post'>
	<input type='hidden' name='id' value='<?php echo $info['id'];?>'>
	<table cellpadding="3" cellspacing="0" class="table-add">
		<tbody>
			<tr>
				<td align="right" width='100' height='36'>档案编号：</td>
				<td align="left" width='*'>
				<input type='number' class='inp' name='bianhao' placeholder='' step="0" value='<?php echo $info['bianhao'];?>'/> 全部为数字，如20190102（2019级01班02号）
				</td>
			</tr>
			<tr>
				<td align="right" width='100' height='36'>幼儿姓名：</td>
				<td align="left" width='*'>
					<input type='text' class='inp' name='name' placeholder='' value='<?php echo $info['name'];?>'/>
				</td>
			</tr>
			<tr>
				<td align="right" width='100' height='36'>幼儿性别：</td>
				<td align="left" width='*'>
			<select name="sex" class="select" id="sex">
			<?php 
			foreach($c_sex as $k=>$v){
        		if($info['sex']===$v){echo "<option value='{$k}' selected='selected'>{$v}</option>";}else{echo "<option value='{$k}'>{$v}</option>";}		
			}?>
			</select>	民族：<select name="nation" class="select" id="nation">
			<?php 
			foreach($c_nation as $k=>$v){
if($info['nation']===$v){echo "<option value='{$k}' selected='selected'>{$v}</option>";}else{echo "<option value='{$k}'>{$v}</option>";}	
			}?>
			</select>
				</td>
			</tr>
			<tr>
				<td align="right" width='100' height='36'>幼儿生日：</td>
				<td align="left" width='*'>
					<input type='text' class='inp' name='shengri' placeholder="0000-00-00"  value='<?php echo substr($info['shengri'],0,10);?>' onclick="WdatePicker();"/>
				</td>
			</tr>
	<tr>
		<td align="right" height='36'>幼儿照片：</td>
		<td align="left"><input type='text' class='inp' name='pic' value='<?php echo $info['pic'];?>' id="url3"/><input type="button" id="image3" value="选择图片" /></td>
	</tr>
			<tr>
				<td align="right" width='100' height='36'>所在班级：</td>
				<td align="left" width='*'>
			<select name="banji" class="select">
				<?php
				foreach(c_classinfo("xiangmu") as $k=>$v){

        		if(intval($info['banji'])===intval($v['id'])){
					echo "<option value='{$v['id']}' selected='selected'>{$v['name']}</option>";
        		}else{
        			echo "<option value='{$v['id']}'>{$v['name']}</option>";}
				}
				?>
				</select>
				</td>
			</tr>

			<tr>
				<td align="right" width='100' height='36'>入园日期：</td>
				<td align="left" width='*'>
					<input type='text' class='inp' name='ruzhi' placeholder="0000-00-00" value='<?php echo substr($info['ruzhi'],0,10);?>' onclick="WdatePicker();" />
				</td>
			</tr>

			<tr>
				<td align="right" width='100' height='36'>备注：</td>
				<td align="left" width='*'>
					<input type='text' class='inp' name='beizhu' placeholder='' value='<?php echo $info['beizhu'];?>'/>
				</td>
			</tr>
			<tr>
				<td align="right" height='50'>　</td>
				<td align="left"><input class='sub' type='submit' value='修改'/></td>
			</tr>
		</tbody>
	</table>

</form>

</body>
</html>