<?php require_once(dirname(__FILE__).'/include/common.php');
$check_enable = intval($webconfig['system_check'])===1?true:false;
if (strpos($_SESSION['eptime_flag'], 'kucunafig') === false) {LYG::ShowMsg('您没有权限！');} 


if(empty($_REQUEST['type']) || intval($_REQUEST['type'])<1){lyg::showmsg('参数错误');}
$data_id = intval($_REQUEST['type']);
require_once(dirname(__FILE__).'/kucun_inc.php');
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title></title>
<link href="style/css/css.css" rel="stylesheet" type="text/css" />
<script type="text/javascript" src="js/My97DatePicker/WdatePicker.js"></script>
<script type="text/javascript" src="js/jquery.min.js"></script>
<script type="text/javascript" src="js/common.js"></script>
<script language="javascript">
<?php 
for ($x=1; $x<=20; $x++) {
?>
   function add<?php echo $x;?>()
   {
      var a<?php echo $x;?> = parseFloat(form1.shuliang<?php echo $x;?>.value);
      var b<?php echo $x;?> = parseFloat(form1.price<?php echo $x;?>.value);
      if(!(isNaN(a<?php echo $x;?>)||isNaN(b<?php echo $x;?>)))
        form1.pricea<?php echo $x;?>.value = a<?php echo $x;?>*b<?php echo $x;?>;
   }
<?php 
} 
?>
</script>



<?php if($data_id==1){?>


<?php 
for ($x=1; $x<=20; $x++) {
?>
<script language="javascript">
function getinfo<?php echo $x;?>(){
window.open('shang.php?form=form1&field=shangpinid<?php echo $x;?>&ii=<?php echo $x;?>','selected','directorys=no,toolbar=no,status=no,menubar=no,resizable=no,width=360,height=500,top=100,left=120,scrollbars=yes');
}
</script>
<?php 
} 
?>


<?php }?>
<?php if($data_id==2){?>


<?php 
for ($x=1; $x<=20; $x++) {
?>
<script language="javascript">
function getinfo<?php echo $x;?>(){
window.open('ku.php?form=form1&field=shangpinid<?php echo $x;?>&ii=<?php echo $x;?>','selected','directorys=no,toolbar=no,status=no,menubar=no,resizable=no,width=360,height=500,top=100,left=120,scrollbars=yes');
}
</script>
<?php 
} 
?>


<?php }?>



<script type="text/javascript">
$(function(){
	$(':button[name=add]').click(function(){
		insertTr();
	})
})
var gradeI=2;
function insertTr(){
	var html='';
	html+='<tr align="center" class="itme">';
	html+='<td>'+gradeI+'. <input type="text" name="shangpinid'+gradeI+'" class="inp" readonly> <a onclick="getinfo'+gradeI+'()">选择商品</a></td>';
	html+='<td><input type="number" name="shuliang'+gradeI+'" class="inp" placeholder="0.00" step="0.01" onblur="add'+gradeI+'();"></td>';
	html+='<td><input type="number"  name="price'+gradeI+'" class="inp" value="" placeholder="0.00" step="0.01" onblur="add'+gradeI+'();" <?php if($data_id==2){echo "readonly";}?>></td>';
	html+='<td><input type="number" name="pricea'+gradeI+'" class="inp" placeholder="0.00" step="0.01" readonly ></td>';
	$('#tab').append(html);
	$('button[name=del]').click(function(){
		$(this).parents('tr').remove();
	})	
	gradeI++;
}

</script>
</head>

<body class="content">

<form action='' method='post' name="form1">
<input type='hidden' name='type' value='<?php echo $data_id;?>'>
	<table cellpadding="3" cellspacing="0" class="table-add">

		<tr>
			<td align="right" height='36' width="100px"><strong>单号：</strong></td>
			<td><?php echo c_newOrderNo("D");?>&nbsp;&nbsp;&nbsp;&nbsp; <input type="hidden" name="danhao" class="inp2" value="<?php echo c_newOrderNo("D");?>">

<?php if($data_id==1){?>
<strong>入库仓库：</strong>
				<select name="cangku" class="select">
				<?php
				foreach(c_classinfo("cangku") as $k=>$v){
					echo "<option value='{$v['id']}'>{$v['name']}</option>";
				}
				?>
				</select>
<?php }?>
			<td align="right" height='36'><strong>经办人：</strong></td>
			<td>
			<select name="yuangong" class="select">
				<?php
				foreach(c_classinfo("yuangong") as $k=>$v){
if(intval($_SESSION['eptime_l_yuangong'])===intval($v['id'])){echo "<option value='{$v['id']}' selected='selected'>{$v['name']}</option>";}
else{echo "<option value='{$v['id']}'>{$v['name']}</option>";}
				}
				?>
				</select>
			</td>
		</tr>

		<tr>
			<td align="right" height='36'><strong>备注：</strong></td>
			<td colspan='3'>
				<input type="text" name="beizhu" class="inp" placeholder="">
			</td>
		</tr>
		<tr>
		    <td align="right" height='36'><strong>商品信息：</strong></td>
			<td colspan='3'>
<table id="tab">
		<tr >
			<th height='36'>商品名称</th>
			<th>数量</th>
			<th>单价</th>
			<th>价值</th>
		</tr>
		<tr align="center" class="itme">
			<td>1. <input type="text" name="shangpinid1" class="inp" readonly> <a onclick="getinfo1()">选择商品</a></td>
			<td><input type="number" name="shuliang1" class="inp" placeholder="0.00" step="0.01" onblur="add1();"></td>
			<td><input type="number"  name="price1" class="inp" value="" placeholder="0.00" step="0.01" onblur="add1();" <?php if($data_id==2){echo "readonly";}?>></td>
			<td><input type="number" name="pricea1" class="inp" placeholder="0.00" step="0.01" readonly ></td>
		</tr>
</table>
	<div align="center"><input type="button" name="add" value="增加一行 最多20行"></div>


			</td>
		</tr>
		<tr>
			<td align="right" height='50'>　</td>
			<td align="left" colspan='3'><input class='sub' type='submit' value='添加'/></td>
		</tr>

	</table>
</form>

</body>
</html>