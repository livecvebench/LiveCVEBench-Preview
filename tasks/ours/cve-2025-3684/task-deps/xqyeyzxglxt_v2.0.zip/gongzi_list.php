<?php

require_once(dirname(__FILE__).'/include/common.php');
if (strpos($_SESSION['eptime_flag'], 'gonglfig') === false) {LYG::ShowMsg('您没有权限！');}

$login = $_SESSION['eptime_username'];



$_k = "";
$_v = array();

$_c = array();//分页条件
$_s = array();//搜索条件


if(intval($_GET['isok'])<>9){
    $_k=$_k." and #__gongzi.isok=".intval($_GET['isok']);
    $_c[]="isok=".intval($_GET['isok']);
    $_s['isok'] = intval($_GET['isok']);
}

if(!empty($_GET['gangwei'])){
    $_k=$_k." and #__yuangong.gangwei='".trim($_GET['gangwei'])."'";
    $_c[]="gangwei='".trim($_GET['gangwei'])."'";
    $_s['gangwei'] = trim($_GET['gangwei']);
}
if(!empty($_GET['yuefen'])){
    $_k=$_k." and #__gongzi.yuefen='".trim($_GET['yuefen'])."'";
    $_c[]="yuefen='".trim($_GET['yuefen'])."'";
    $_s['yuefen'] = trim($_GET['yuefen']);
}

if(!empty($_GET['keywords']) && trim($_GET['keywords'])!=''){
    $_k=$_k." and ( #__yuangong.name like '%".trim($_GET['keywords'])."%' or #__yuangong.bianhao like '%".trim($_GET['keywords'])."%' or #__gongzi.beizhu like '%".trim($_GET['keywords'])."%')";
    $_c[]="keywords=".trim($_GET['keywords']);
    $_s['keywords'] = trim($_GET['keywords']);
}



if($_k!=''){
    $_k = " where 1=1 ".$_k;
}

$field = array(
	"#__gongzi.*",
	"#__yuangong.gangwei,bianhao,name"
);
$field = implode(",",$field);
$left = "left join #__yuangong on #__yuangong.id=#__gongzi.ygid ";


$action="search";
if(!empty($_GET['action']) && $_GET['action']=='output'){
	require_once(dirname(__FILE__).'/include/PHPExcel/PHPExcel.php');
	$sql = "select {$field} from #__gongzi {$left} {$_k} order by #__gongzi.id desc,#__gongzi.isok desc";
	$data = $con->select($sql);
	require_once("output.php");
	die();
}

$sqla = "select {$field} from #__gongzi {$left} {$_k} order by #__gongzi.id desc,#__gongzi.isok desc";
$dataa = $con->select($sqla);
$nowprice1=0;
$nowprice2=0;
foreach($dataa as $k=>$v){
$nowprice1=$nowprice1+$v['jiben'];
$nowprice2=$nowprice2+$v['gongzia'];
                        }



if($webconfig['eptime_pagesize']){$pagesize=$webconfig['eptime_pagesize'];}else{$pagesize = 20;}

$datacount=$con->RowsCount("select count(#__gongzi.id) from #__gongzi {$left} {$_k}");

$totalpages=LYG::getTotalPage($datacount,$pagesize);
$page=1;
if(!empty($_GET['p']) && intval($_GET['p'])>0){
	$page=intval($_GET['p']);
	$page=$page>$totalpages?$totalpages:$page;
	if($page+1<=1){$page=1;}
}
$start_id=($page-1)*$pagesize;

$sql = "select {$field} from #__gongzi {$left} {$_k} order by #__gongzi.id desc,#__gongzi.isok desc limit {$start_id},{$pagesize}";
$data =$con->select($sql);
$fenye = LYG::getPageHtml($page,$datacount,$pagesize,$_c);


$classes = $con->select("select * from #__gangwei");
?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title></title>
<link href="style/css/css.css" rel="stylesheet" type="text/css" />
<link href="style/css/font-awesome.min.css" rel="stylesheet" type="text/css" />
<script type="text/javascript" src="js/My97DatePicker/WdatePicker.js"></script>
<script type="text/javascript" src="js/jquery.min.js"></script>
<script type="text/javascript" src="js/common.js"></script>
<SCRIPT language=javascript> 
function openScript(url, width, height) {
        var Win = window.open(url,"openScript",'width=' + width + ',height=' + 
 
height + ',resizable=0,scrollbars=no,menubar=no,status=no' );
}
</SCRIPT>
<script type="text/javascript">
function search(obj){
	document.searchform.submit();
}
$(function(){
	$("input.sort").blur(function(){
		
		var sort = parseInt($(this).val());
		if(isNaN(sort)){
			sort = 100;
		}
		if(sort == parseInt(this.defaultValue)){
			return;
		}
		
		var id = $(this).parent().parent().attr("data-id");
		
		$.post("json.php",{"act":"shangpinsort","id":id,"sort":sort},function(e){
			location.reload();
		},"json");
	});
});
</script>
</head>

<body class="content">
<div class="searchform">
    <form method="get" name="searchform">
	<table>
		<tr>
		    <td width="*" align="right"></td>

<td width="200" align="right">
			<select name="gangwei" class="select" onchange="search(this);">
			<option value='0'>所有任职岗位</option>
			<?php
			foreach ($classes as $k => $v) {
						if(array_key_exists('gangwei', $_s) && trim($_s['gangwei'])===trim($v['name'])){
							echo "<option value='{$v['name']}' selected='selected'>{$v['name']}</option>";
						}else{
							echo "<option value='{$v['name']}'>{$v['name']}</option>";    
						}  
			}
			?></select>
</td>
			<td width="50" align="right">月份</td>
			<td width="100">
				<input type="text" name="yuefen" class="text"  placeholder="0000-00" onclick="WdatePicker({dateFmt:'yyyy-MM'});" value="<?php 
					if(array_key_exists("yuefen",$_s)){
						echo $_s['yuefen'];
					}
				?>">
			</td>
			<td width="200" align="right">
<select name="isok" class="select bai" onchange="search(this);"><option value='9'>所有状态</option>
<?php if(array_key_exists('isok', $_s) && intval($_s['isok'])===1){ ?><option value='1' selected='selected'>已发放</option><?php }else{ ?><option value='1'>已发放</option><?php } ?>
<?php if(array_key_exists('isok', $_s) && intval($_s['isok'])===0){ ?><option value='0' selected='selected'>待发放</option><?php }else{ ?><option value='0'>待发放</option><?php } ?>
</select>
			</td>



			<td width="60" align="right">关键词:</td>
			<td width="160">
				<input type="text" name="keywords" class="text" placeholder='教工编号、姓名或备注' value="<?php 
					if(array_key_exists("keywords",$_s)){
						echo $_s['keywords'];
					}
				?>">
			</td>
			
			<td width="80" align="right">
<input type="submit" onclick="setmethod('search');" value="查询" class="sub">
			</td>
		</tr>
	</table>
    </form>
	<table>
		<tr>
		<td width="*" align="right"></td>
			<td width="80%" align="right">
			基本工资合计：<b><?php echo $nowprice1;?></b> ，实发工资合计：<b><?php echo $nowprice2;?></b> 元&nbsp;
			</td>
			</tr>
	</table>
</div>

<table cellpadding="3" cellspacing="0">
	<thead>
    	<tr>
				<th>ID</th>
				<th>教工编号</th>
				<th>教工姓名</th>
				<th>任职岗位</th>
				<th>月份</th>
				<th>基本工资</th>
				<th>核算人</th>
				<th>核算时间</th>
				<th>实发工资</th>
				<th>备注</th>
				<th>发放状态</th>
            <th >-</th>
        </tr>
    </thead>
    <tbody>
	<?php foreach($data as $k=>$v){?>
    	<tr class='list'>
<td align="center"><a href='javascript:openScript("gongzi_info.php?id=<?php echo $v['id'];?>",600,690)'><?php  echo $v['id'];?></a></td>
<td align="center"><?php  echo c_yuanggong1($v['ygid']);?></td>
<td align="center"><?php  echo c_yuanggong2($v['ygid']);?></td>
<td align="center"><?php  echo c_yuanggong3($v['ygid']);?></td>
<td align="center"><?php  echo $v['yuefen'];?></td>
<td align="center"><?php  echo $v['jiben'];?></td>
<td align="center"><?php echo $v['hesuan'];?></td>
<td align="center"><?php echo $v['addtime'];?></td>
<td align="center"><?php echo $v['gongzia'];?></td>
<td align="center"><a title=<?php echo $v['beizhu'];?>>备注</a></td>
<td align="center"><?php if($v['isok']==1){echo "<a href=?shenhe=kk&class=yuangong&id={$v['id']}><font color=green>已发放</font></a>";}else{echo "<a href=?shenhe=ok&class=yuangong&id={$v['id']}><font color=red>待发放</a></a>";}?></td>
            <td align="center">
				<a onclick="return confirm('确定删除吗？');" class="del" href="class_del.php?id=<?php echo $v['id'];?>&class=gongzi"><i class="fa fa-close"></i><span>删除</span></a>
			</td>
        </tr>
	<?php }?>
    </tbody>
    <tfoot>
    	<tr>
        	<td colspan="12" style="padding-left:30px;">
			<?php echo $fenye ;?>
			</td>
        </tr>
    </tfoot>
</table>


</body>
</html>