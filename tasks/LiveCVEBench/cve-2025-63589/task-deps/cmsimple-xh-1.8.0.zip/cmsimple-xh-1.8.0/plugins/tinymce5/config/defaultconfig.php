<?php
$plugin_cf['tinymce5']['init']="full";
$plugin_cf['tinymce5']['utf8_marker']="äöü";
$plugin_cf['tinymce5']['CDN_src']="https://cdn.tiny.cloud/1/no-api-key/tinymce/5/tinymce.min.js";
$plugin_cf['tinymce5']['CDN']="";   //"" = locally installed, "true" = CDN Variant 
