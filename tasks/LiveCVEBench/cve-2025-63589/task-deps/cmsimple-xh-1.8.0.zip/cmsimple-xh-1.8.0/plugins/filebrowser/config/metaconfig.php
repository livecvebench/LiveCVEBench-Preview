<?php

$plugin_mcf['filebrowser']['extensions_handle_as_images']="hidden";
$plugin_mcf['filebrowser']['extensions_no_getimagesize']="hidden";
