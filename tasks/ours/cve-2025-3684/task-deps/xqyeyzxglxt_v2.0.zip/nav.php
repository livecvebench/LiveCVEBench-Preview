<?php
require_once(dirname(__FILE__).'/include/common.php');
if(empty($_GET['list'])){lyg::showmsg('��������');}else{$_list=$_GET['list'];}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title></title>
<style type="text/css">
*{ margin:0; padding:0; outline:0; list-style:none;}
body{ background:#ffffff;}
</style>
</head>
<frameset rows="40,*" frameborder="0">
	<frame src="nav_nav.php?list=<?php echo $_list;?>" style="border-right:1px solid #ccc" frameborder="0"/>
    <frame name="system" src="<?php 
if($_list==11){echo "fei_list.php";} if($_list==12){echo "fei_tong.php";}
if($_list==21){echo "qing_list.php";} if($_list==22){echo "stu_list.php";}
if($_list==31){echo "gongzi_list.php?isok=9";} if($_list==32){echo "zhigongda_list.php?isok=9";} 
if($_list==41){echo "kucun_list.php?type=1";} if($_list==42){echo "kucun_list.php?type=2";} if($_list==43){echo "kucun_listok.php";}
if($_list==51){echo "money_add.php";} if($_list==52){echo "money_zhang.php";} if($_list==53){echo "tongji/yearReport.php";} 
if($_list==61){echo "zhanghu_list.php";}
if($_list==62){echo "user_list.php";}
if($_list==63){echo "shangpin_list.php";}
if($_list==64){echo "big_list.php";}
if($_list==65){echo "big_list.php";}
if($_list==66){echo "config_system_base.php";}?>"/>
</frameset>
</html>