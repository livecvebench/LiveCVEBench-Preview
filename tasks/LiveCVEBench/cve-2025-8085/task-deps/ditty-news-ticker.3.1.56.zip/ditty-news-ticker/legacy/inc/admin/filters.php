<?php


/**
 * List heading actions
 *
 * @access  public 
 * @since   1.0.0
 */	
add_action( 'mtphr_dnt_list_heading', 'mtphr_dnt_list_heading_drag', 10 );
add_action( 'mtphr_dnt_list_heading', 'mtphr_dnt_list_heading_buttons', 20 );




