<?php
require_once(dirname(__FILE__).'/include/common.php');
if(empty($_GET['list'])){lyg::showmsg('参数错误');}else{$_list=$_GET['list'];}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title></title>
<link href="style/css/css.css" rel="stylesheet" type="text/css" />
<link href="style/css/font-awesome.min.css" rel="stylesheet" type="text/css" />
<script type='text/javascript' src='js/jquery.min.js'></script>
<script type='text/javascript'>
$(function(){
	$('li a').click(function(){
		$(this).parent().addClass('active').siblings('li').removeClass('active');
	});
});
</script>
</head>
<style type="text/css">
body{ overflow:hidden; background:#f5f2f2}
ul{  padding:5px 10px;}
li{ float:left;text-align:left; width:120px; user-select:none;-webkit-user-select:none;-moz-user-select:none;}
li a{ font-size:14px; line-height:34px; color:#212121; text-decoration:none; padding-left:8px;}
li a i{margin-right:4px;}
li.active{ background-color:#01C0C8!important;position:relative;}
li.active a{color:#FFF;font-weight:bold;}
</style>
<body>

<ul>
<?php if($_list==11){?>
<li class='active'><a href="fei_list.php" target="system"><i class="fa fa-home fa-fw"></i>收费记录</a></li>
<li><a href="fei_add.php" target="system"><i class="fa fa-user fa-fw"></i>费用收取</a></li>
<?php }?>
<?php if($_list==12){?>
<li class='active'><a href="fei_tong.php" target="system"><i class="fa fa-home fa-fw"></i>收费统计</a></li>
<?php }?>


<?php if($_list==21){?>
<li class='active'><a href="qing_list.php" target="system"><i class="fa fa-home fa-fw"></i>请假记录</a></li>
<li><a href="qing_add.php" target="system"><i class="fa fa-user fa-fw"></i>请假登记</a></li>
<?php }?>
<?php if($_list==22){?>
<li class='active'><a href="stu_list.php" target="system"><i class="fa fa-home fa-fw"></i><?php echo $webconfig['system_wanglai'];?>档案</a></li>
<li><a href="stu_add.php" target="system"><i class="fa fa-user fa-fw"></i>添加档案</a></li>
<?php }?>

<?php if($_list==31){?>
<li class='active'><a href="gongzi_list.php?isok=9" target="system"><i class="fa fa-home fa-fw"></i>工资管理</a></li>
<li><a href="gongzi_add.php" target="system"><i class="fa fa-hdd-o fa-fw"></i>工资核算</a></li>
<li><a href="gongzi_fa.php" target="system"><i class="fa fa-hdd-o fa-fw"></i>工资发放</a></li>
<?php }?>
<?php if($_list==32){?>
<li class='active'><a href="zhigongda_list.php?isok=9" target="system"><i class="fa fa-home fa-fw"></i><?php echo $webconfig['system_yuangong'];?>档案</a></li>
<li><a href="zhigongda_add.php" target="system"><i class="fa fa-user fa-fw"></i>添加档案</a></li>
<?php }?>

<?php if($_list==41){?>
<li class='active'><a href="kucun_list.php?type=1" target="system"><i class="fa fa-home fa-fw"></i>采购记录</a></li>
<li><a href="kucun_add.php?type=1" target="system"><i class="fa fa-hdd-o fa-fw"></i>采购入库</a></li>
<?php }?>
<?php if($_list==42){?>
<li class='active'><a href="kucun_list.php?type=2" target="system"><i class="fa fa-home fa-fw"></i>领取记录</a></li>
<li><a href="kucun_add.php?type=2" target="system"><i class="fa fa-hdd-o fa-fw"></i>领取出库</a></li>
<?php }?>
<?php if($_list==43){?>
<li class='active'><a href="kucun_listok.php" target="system"><i class="fa fa-home fa-fw"></i>库存列表</a></li>
<li><a href="kucun_list.php?type=3" target="system"><i class="fa fa-hdd-o fa-fw"></i>调拨记录</a></li>
<li><a href="kucun_list.php?type=4" target="system"><i class="fa fa-hdd-o fa-fw"></i>盘点记录</a></li>
<?php }?>
<?php if($_list==51){?>
	<li class='active'><a href="money_add.php" target="system"><i class="fa fa-home fa-fw"></i>收支记账</a></li>	
	<li><a href="money_list.php" target="system"><i class="fa fa-database fa-fw"></i>收支流水</a></li>
	<li><a href="money_pay_add.php" target="system"><i class="fa fa-database fa-fw"></i>应收应付记账</a></li>
	<li><a href="money_pay_list.php" target="system"><i class="fa fa-database fa-fw"></i>应收应付流水</a></li>
	<li><a href="money_pay_list.php?type=0" target="system"><i class="fa fa-database fa-fw"></i>借出收款</a></li>
	<li><a href="money_pay_list.php?type=1" target="system"><i class="fa fa-database fa-fw"></i>借入归还</a></li>
<?php }?>
<?php if($_list==52){?>
	<li class='active'><a href="money_zhang.php" target="system"><i class="fa fa-home fa-fw"></i>资金账户余额</a></li>	
	<li><a href="money_pay_list_ok.php" target="system"><i class="fa fa-database fa-fw"></i>已收已付款</a></li>
	<li><a href="money_zhang_list.php" target="system"><i class="fa fa-database fa-fw"></i>资金转账流水</a></li>
<?php }?>
<?php if($_list==53){?>
	<li class='active'><a href="tongji/yearReport.php" target="system"><i class="fa fa-home fa-fw"></i>年度收支统计表</a></li>	
	<li><a href="tongji/Month.php" target="system"><i class="fa fa-database fa-fw"></i>月收支曲线图</a></li>
	<li><a href="tongji/year.php" target="system"><i class="fa fa-database fa-fw"></i>年度收支柱状图</a></li>
	<li><a href="tongji/wanglai.php" target="system"><i class="fa fa-database fa-fw"></i><?php echo $webconfig['system_wanglai'];?>收支柱状图</a></li>
	<li><a href="tongji/yuangong.php" target="system"><i class="fa fa-database fa-fw"></i><?php echo $webconfig['system_yuangong'];?>收支柱状图</a></li>
	<li><a href="tongji/xiangmu.php" target="system"><i class="fa fa-database fa-fw"></i><?php echo $webconfig['system_xiangmu'];?>收支柱状图</a></li>
	<li><a href="tongji/shouzhi.php?type=0" target="system"><i class="fa fa-database fa-fw"></i>收入支出构成图表</a></li>
	<li><a href="tongji/total.php" target="system"><i class="fa fa-database fa-fw"></i>收支汇总饼状图</a></li>
<?php }?>
<?php if($_list==61){?>
<li class='active'><a href="zhanghu_list.php" target="system"><i class="fa fa-home fa-fw"></i>账户管理</a></li>
<?php }?>
<?php if($_list==62){?>
<li class='active'><a href="user_list.php" target="system"><i class="fa fa-home fa-fw"></i>用户管理</a></li>
<?php }?>
<?php if($_list==63){?>
<li class='active'><a href="shangpin_list.php" target="system"><i class="fa fa-home fa-fw"></i>商品管理</a></li>
<?php }?>
<?php if($_list==65){?>
<li class='active'><a href="big_list.php" target="system"><i class="fa fa-home fa-fw"></i>一级分类</a></li>
<li><a href="small_list.php" target="system"><i class="fa fa-th-list fa-fw"></i>二级分类</a></li>
<?php }?>
<?php if($_list==66){?>
<li class='active'><a href="config_system_base.php" target="system"><i class="fa fa-home fa-fw"></i>基础设置</a></li>
<li><a href="base.php?base=gangwei" target="system"><i class="fa fa-th-list fa-fw"></i>岗位管理</a></li>
<li><a href="base.php?base=fangshi" target="system"><i class="fa fa-th-list fa-fw"></i>付款方式</a></li>
<li><a href="zhanghuclass.php" target="system"><i class="fa fa-th-list fa-fw"></i>账户分类</a></li>
<li><a href="base.php?base=fenlei" target="system"><i class="fa fa-th-list fa-fw"></i>商品分类</a></li>
<li><a href="base.php?base=danwei" target="system"><i class="fa fa-th-list fa-fw"></i>计量单位</a></li>
<li><a href="config_system_backrestore.php" target="system"><i class="fa fa-th-list fa-fw"></i>数据库维护</a></li>
<li><a href="log_list.php" target="system"><i class="fa fa-th-list fa-fw"></i>操作日志</a></li>
<?php }?>
</ul>
</body>
</html>