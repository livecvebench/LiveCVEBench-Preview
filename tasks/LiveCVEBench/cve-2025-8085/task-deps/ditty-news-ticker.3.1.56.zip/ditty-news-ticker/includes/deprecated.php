<?php

/**
 * No longer used, but may be called in extension upgrades.
 */
function ditty_set_variation_default( $item_type, $variation, $layout_id ) {}
