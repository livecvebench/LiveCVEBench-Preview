-- phpMyAdmin SQL Dump
-- version phpStudy 2014
-- http://www.phpmyadmin.net
--
-- 主机: localhost
-- 生成日期: 2019 年 08 月 07 日 18:01
-- 服务器版本: 5.5.53
-- PHP 版本: 5.4.45

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- 数据库: `school`
--

-- --------------------------------------------------------

--
-- 表的结构 `eptime_admin`
--

CREATE TABLE IF NOT EXISTS `eptime_admin` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `UserName` varchar(255) DEFAULT NULL,
  `mobile` varchar(255) DEFAULT NULL,
  `Password` varchar(255) DEFAULT NULL,
  `AdminPower` int(11) DEFAULT '0',
  `Working` int(11) DEFAULT '0',
  `LastLoginTime` datetime DEFAULT NULL,
  `LastLoginIP` varchar(255) DEFAULT NULL,
  `LoginTimes` int(11) DEFAULT '0',
  `AddDate` datetime DEFAULT NULL,
  `M_Random` varchar(255) DEFAULT NULL,
  `Realname` varchar(255) DEFAULT NULL,
  `zhanghu` int(11) DEFAULT '0',
  `wanglai` int(11) DEFAULT '0',
  `yuangong` int(11) DEFAULT '0',
  `xiangmu` int(11) DEFAULT '0',
  `flag` varchar(500) DEFAULT NULL,
  `img` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `ID` (`ID`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- 转存表中的数据 `eptime_admin`
--

INSERT INTO `eptime_admin` (`ID`, `UserName`, `mobile`, `Password`, `AdminPower`, `Working`, `LastLoginTime`, `LastLoginIP`, `LoginTimes`, `AddDate`, `M_Random`, `Realname`, `zhanghu`, `wanglai`, `yuangong`, `xiangmu`, `flag`, `img`) VALUES
(1, 'admin', '13327512993', 'ec057d2c5440bafd028c622fb032f7df', 0, 1, '2019-01-01 00:00:00', '127.0.0.1', 0, '2019-01-01 00:00:00', 'a8edfb4efe3612449a1d04883051d9fb', '系统管理员', 1, 0, 0, 0, 'feilfig|feiafig|qinglfig|qingafig|stulfig|stuafig|stumfig|studfig|gonglfig|gonghfig|gongffig|gongdfig|zhilfig|zhiafig|zhimfig|zhidfig|kucunlfig|kucunafig|kucundfig|kucunpfig|moneyfig|moneymfig|moneydfig|payfig|paymfig|paydfig|pay1fig|pay2fig|zhangfig|zhangzfig|zhanglfig|excelfig|yearrfig|monthfig|yearfig|chengyuanfig|xiangmufig|kehufig|shouzhifig|totalfig', 'style/images/user.png');

-- --------------------------------------------------------

--
-- 表的结构 `eptime_cangku`
--

CREATE TABLE IF NOT EXISTS `eptime_cangku` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `beizhu` longtext,
  `date` datetime DEFAULT NULL,
  `isok` int(11) DEFAULT '1',
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

--
-- 转存表中的数据 `eptime_cangku`
--

INSERT INTO `eptime_cangku` (`id`, `name`, `beizhu`, `date`, `isok`) VALUES
(1, '仓库A', '地下一层1108', NULL, 1),
(2, '仓库B', '', NULL, 1);

-- --------------------------------------------------------

--
-- 表的结构 `eptime_danwei`
--

CREATE TABLE IF NOT EXISTS `eptime_danwei` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=8 ;

--
-- 转存表中的数据 `eptime_danwei`
--

INSERT INTO `eptime_danwei` (`id`, `name`) VALUES
(1, '个'),
(7, '台');

-- --------------------------------------------------------

--
-- 表的结构 `eptime_fangshi`
--

CREATE TABLE IF NOT EXISTS `eptime_fangshi` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=6 ;

--
-- 转存表中的数据 `eptime_fangshi`
--

INSERT INTO `eptime_fangshi` (`id`, `name`) VALUES
(1, '现金'),
(2, '支付宝'),
(3, '微信'),
(4, '银行转账');

-- --------------------------------------------------------

--
-- 表的结构 `eptime_fei`
--

CREATE TABLE IF NOT EXISTS `eptime_fei` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `stuid` int(11) DEFAULT '0',
  `id_login` int(11) DEFAULT '0',
  `login` varchar(50) DEFAULT NULL,
  `selldate` datetime DEFAULT NULL,
  `fangshi` varchar(50) DEFAULT '0',
  `begindate` datetime DEFAULT NULL,
  `enddate` datetime DEFAULT NULL,
  `isok` tinyint(1) DEFAULT '0',
  `addtime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `jingban` int(11) DEFAULT NULL,
  `beizhu` varchar(255) DEFAULT NULL,
  `price` double DEFAULT '0',
  `name` varchar(255) DEFAULT NULL,
  `moneyID` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=37 ;

-- --------------------------------------------------------

--
-- 表的结构 `eptime_fenlei`
--

CREATE TABLE IF NOT EXISTS `eptime_fenlei` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=8 ;

--
-- 转存表中的数据 `eptime_fenlei`
--

INSERT INTO `eptime_fenlei` (`id`, `name`) VALUES
(1, '日用品'),
(2, '食堂材料');

-- --------------------------------------------------------

--
-- 表的结构 `eptime_gangwei`
--

CREATE TABLE IF NOT EXISTS `eptime_gangwei` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=6 ;

--
-- 转存表中的数据 `eptime_gangwei`
--

INSERT INTO `eptime_gangwei` (`id`, `name`) VALUES
(1, '班主任'),
(2, '副班主任'),
(3, '保育员');

-- --------------------------------------------------------

--
-- 表的结构 `eptime_gongzi`
--

CREATE TABLE IF NOT EXISTS `eptime_gongzi` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ygid` int(11) DEFAULT NULL,
  `yuefen` varchar(50) DEFAULT NULL,
  `jiben` double DEFAULT '0',
  `kaohe` double DEFAULT '0',
  `kaoqin` double DEFAULT '0',
  `hesuan` varchar(50) DEFAULT NULL,
  `addtime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `beizhu` longtext,
  `butie` double DEFAULT '0',
  `shebao` double DEFAULT '0',
  `shui` double DEFAULT '0',
  `qita` double DEFAULT '0',
  `gongzi` double DEFAULT '0',
  `gongzia` double DEFAULT '0',
  `fa` varchar(50) DEFAULT NULL,
  `fatime` datetime DEFAULT NULL,
  `isok` int(11) DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=4 ;

-- --------------------------------------------------------

--
-- 表的结构 `eptime_jiaz`
--

CREATE TABLE IF NOT EXISTS `eptime_jiaz` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `stuid` int(11) DEFAULT NULL,
  `gx` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `beizhu` varchar(255) DEFAULT NULL,
  `cardno` varchar(255) DEFAULT NULL,
  `mobile` varchar(50) DEFAULT NULL,
  `addtime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `address` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=72 ;

-- --------------------------------------------------------

--
-- 表的结构 `eptime_kucun`
--

CREATE TABLE IF NOT EXISTS `eptime_kucun` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `shangpinid` int(11) NOT NULL DEFAULT '0',
  `cangkuid` int(11) NOT NULL DEFAULT '0',
  `shuliang` double DEFAULT NULL,
  `shuliangr` double DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=29 ;

-- --------------------------------------------------------

--
-- 表的结构 `eptime_kucunlog`
--

CREATE TABLE IF NOT EXISTS `eptime_kucunlog` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `shangpinid` int(11) NOT NULL DEFAULT '0',
  `cangku` int(11) NOT NULL DEFAULT '0',
  `shuliang` double DEFAULT NULL,
  `price` double DEFAULT NULL,
  `beizhu` varchar(255) DEFAULT NULL,
  `isok` int(11) DEFAULT '0',
  `type` int(11) DEFAULT '0',
  `pricea` double DEFAULT NULL,
  `yuangong` int(11) DEFAULT '0',
  `addtime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `danhao` varchar(255) DEFAULT NULL,
  `cangku1` int(11) DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=78 ;

-- --------------------------------------------------------

--
-- 表的结构 `eptime_log`
--

CREATE TABLE IF NOT EXISTS `eptime_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ip` varchar(255) DEFAULT NULL,
  `os` varchar(255) DEFAULT NULL,
  `content` longtext,
  `addtime` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=15 ;

-- --------------------------------------------------------

--
-- 表的结构 `eptime_money`
--

CREATE TABLE IF NOT EXISTS `eptime_money` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `beizhu` varchar(255) DEFAULT NULL,
  `id_login` int(11) DEFAULT '0',
  `login` varchar(50) DEFAULT NULL,
  `selldate` datetime DEFAULT NULL,
  `type` int(11) DEFAULT '0',
  `id_bigclass` int(11) DEFAULT '0',
  `id_smallclass` int(11) DEFAULT '0',
  `price` double DEFAULT '0',
  `isok` tinyint(1) DEFAULT '0',
  `addtime` datetime DEFAULT NULL,
  `zhanghu` int(11) DEFAULT '0',
  `wanglai` int(11) DEFAULT '0',
  `zhanghu1` int(11) DEFAULT '0',
  `LastLogin` varchar(255) DEFAULT NULL,
  `LastTime` datetime DEFAULT NULL,
  `yuangong` int(11) DEFAULT '0',
  `xiangmu` int(11) DEFAULT '0',
  `moneyID` varchar(50) DEFAULT NULL,
  `shenhetime` datetime DEFAULT NULL,
  `shenhe` varchar(255) DEFAULT NULL,
  `img` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=26 ;

-- --------------------------------------------------------

--
-- 表的结构 `eptime_money_bigclass`
--

CREATE TABLE IF NOT EXISTS `eptime_money_bigclass` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `bigclass` varchar(255) DEFAULT NULL,
  `type` int(11) DEFAULT '0',
  `isok` int(11) DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=12 ;

--
-- 转存表中的数据 `eptime_money_bigclass`
--

INSERT INTO `eptime_money_bigclass` (`id`, `bigclass`, `type`, `isok`) VALUES
(1, '销售收入', 0, 0),
(2, '服务收入', 0, 0),
(3, '其他收入', 0, 0),
(4, '借入款项', 0, 1),
(6, '工人工资', 1, 3),
(7, '其他支出', 1, 0),
(8, '借出款项', 1, 1),
(9, '幼儿缴费', 0, 2),
(10, '工资支出', 1, 0),
(11, '采购支出', 1, 4);

-- --------------------------------------------------------

--
-- 表的结构 `eptime_money_pay`
--

CREATE TABLE IF NOT EXISTS `eptime_money_pay` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `beizhu` varchar(255) DEFAULT NULL,
  `id_login` int(11) DEFAULT '0',
  `login` varchar(50) DEFAULT NULL,
  `selldate` datetime DEFAULT NULL,
  `type` int(11) DEFAULT '0',
  `id_bigclass` int(11) DEFAULT '0',
  `id_smallclass` int(11) DEFAULT '0',
  `price` double DEFAULT '0',
  `isok` tinyint(1) DEFAULT '0',
  `addtime` datetime DEFAULT NULL,
  `zhanghu` int(11) DEFAULT '0',
  `wanglai` int(11) DEFAULT '0',
  `zhanghu1` int(11) DEFAULT '0',
  `LastLogin` varchar(255) DEFAULT NULL,
  `LastTime` datetime DEFAULT NULL,
  `yuangong` int(11) DEFAULT '0',
  `xiangmu` int(11) DEFAULT '0',
  `moneyID` varchar(50) DEFAULT NULL,
  `isclass` longtext,
  `Lastdate` datetime DEFAULT NULL,
  `payid` varchar(50) DEFAULT NULL,
  `price1` double DEFAULT '0',
  `shenhe` varchar(255) DEFAULT NULL,
  `shenhetime` datetime DEFAULT NULL,
  `img` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- 表的结构 `eptime_money_smallclass`
--

CREATE TABLE IF NOT EXISTS `eptime_money_smallclass` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `smallclass` varchar(255) DEFAULT NULL,
  `id_bigclass` int(11) DEFAULT '0',
  `isok` int(11) DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=15 ;

--
-- 转存表中的数据 `eptime_money_smallclass`
--

INSERT INTO `eptime_money_smallclass` (`id`, `smallclass`, `id_bigclass`, `isok`) VALUES
(1, '设备销售', 1, 0),
(2, '软件销售', 1, 0),
(3, '硬件维修', 2, 0),
(4, '软件服务', 2, 0),
(5, '其他收入', 3, 0),
(6, '银行贷款', 4, 1),
(7, '其他借入', 4, 1),
(10, '业务部工资', 6, 0),
(11, '财务部工资', 6, 0),
(12, '其他支出', 7, 0),
(13, '差旅费', 8, 1),
(14, '其他借出', 8, 1);

-- --------------------------------------------------------

--
-- 表的结构 `eptime_qingj`
--

CREATE TABLE IF NOT EXISTS `eptime_qingj` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `stuid` int(11) DEFAULT NULL,
  `isok` int(11) DEFAULT '1',
  `begindate` datetime DEFAULT NULL,
  `enddate` datetime DEFAULT NULL,
  `yuangong` int(11) DEFAULT NULL,
  `beizhu` varchar(255) DEFAULT NULL,
  `addtime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=12 ;

-- --------------------------------------------------------

--
-- 表的结构 `eptime_shangpin`
--

CREATE TABLE IF NOT EXISTS `eptime_shangpin` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `fenlei` int(11) DEFAULT NULL,
  `bianhao` varchar(50) DEFAULT NULL,
  `xinghao` varchar(255) DEFAULT NULL,
  `danwei` varchar(255) DEFAULT NULL,
  `price` double DEFAULT NULL,
  `beizhu` varchar(255) DEFAULT NULL,
  `isok` int(11) DEFAULT '1',
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=10 ;

-- --------------------------------------------------------

--
-- 表的结构 `eptime_wanglai`
--

CREATE TABLE IF NOT EXISTS `eptime_wanglai` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `tel` varchar(50) DEFAULT NULL,
  `sex` varchar(50) DEFAULT NULL,
  `email` varchar(50) DEFAULT NULL,
  `address` varchar(50) DEFAULT NULL,
  `addtime` datetime DEFAULT NULL,
  `shengri` datetime DEFAULT NULL,
  `beizhu` longtext,
  `isok` int(11) DEFAULT '1',
  `bianhao` int(50) DEFAULT NULL,
  `nation` varchar(50) DEFAULT NULL,
  `gangwei` varchar(50) DEFAULT NULL,
  `banji` int(11) DEFAULT NULL,
  `ruzhi` datetime DEFAULT NULL,
  `zjtype` varchar(50) DEFAULT NULL,
  `zjno` varchar(50) DEFAULT NULL,
  `pic` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=5 ;

-- --------------------------------------------------------

--
-- 表的结构 `eptime_xiangmu`
--

CREATE TABLE IF NOT EXISTS `eptime_xiangmu` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `beizhu` longtext,
  `date` datetime DEFAULT NULL,
  `isok` int(11) DEFAULT '1',
  `ban1` int(11) DEFAULT NULL,
  `ban2` int(11) DEFAULT NULL,
  `ban3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

--
-- 转存表中的数据 `eptime_xiangmu`
--

INSERT INTO `eptime_xiangmu` (`id`, `name`, `beizhu`, `date`, `isok`, `ban1`, `ban2`, `ban3`) VALUES
(1, '小班', '', '2019-01-01 00:00:00', 1, NULL, NULL, NULL),
(2, '中班', '', '2019-01-01 00:00:00', 1, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- 表的结构 `eptime_yuangong`
--

CREATE TABLE IF NOT EXISTS `eptime_yuangong` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `tel` varchar(50) DEFAULT NULL,
  `sex` varchar(50) DEFAULT NULL,
  `email` varchar(50) DEFAULT NULL,
  `address` varchar(50) DEFAULT NULL,
  `addtime` datetime DEFAULT NULL,
  `shengri` datetime DEFAULT NULL,
  `beizhu` longtext,
  `isok` int(11) DEFAULT '1',
  `bianhao` varchar(50) DEFAULT NULL,
  `nation` varchar(50) DEFAULT NULL,
  `gangwei` varchar(50) DEFAULT NULL,
  `banji` int(11) DEFAULT NULL,
  `ruzhi` datetime DEFAULT NULL,
  `zjtype` varchar(50) DEFAULT NULL,
  `zjno` varchar(50) DEFAULT NULL,
  `yuefen` varchar(50) DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=4 ;

-- --------------------------------------------------------

--
-- 表的结构 `eptime_zhanghu`
--

CREATE TABLE IF NOT EXISTS `eptime_zhanghu` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `type` int(11) DEFAULT '0',
  `amount` double DEFAULT '0',
  `beizhu` longtext,
  `date` datetime DEFAULT NULL,
  `amount0` double DEFAULT '0',
  `isok` int(11) DEFAULT '1',
  `sy` int(11) DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=5 ;

--
-- 转存表中的数据 `eptime_zhanghu`
--

INSERT INTO `eptime_zhanghu` (`id`, `name`, `type`, `amount`, `beizhu`, `date`, `amount0`, `isok`, `sy`) VALUES
(1, '工商银行', 2, 0, '', '2019-01-01 00:00:01', 0, 0, 1),
(2, '电子钱包', 1, 0, '', '2019-01-01 00:00:01', 0, 1, 1),
(3, '农业银行', 2, 0, '', NULL, 0, 2, 1),
(4, '采购用账户', 2, 0, '', NULL, 0, 3, 1);

-- --------------------------------------------------------

--
-- 表的结构 `eptime_zhanghu_class`
--

CREATE TABLE IF NOT EXISTS `eptime_zhanghu_class` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `zhanghuclass` varchar(255) DEFAULT NULL,
  `px` int(11) DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=7 ;

--
-- 转存表中的数据 `eptime_zhanghu_class`
--

INSERT INTO `eptime_zhanghu_class` (`id`, `zhanghuclass`, `px`) VALUES
(1, '现金', 1),
(2, '存款', 2),
(3, '理财', 3),
(6, '999', 0);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
