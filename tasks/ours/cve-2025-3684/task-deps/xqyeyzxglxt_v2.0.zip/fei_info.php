<?php

require_once(dirname(__FILE__).'/include/common.php');
$webconfig = lyg::readArr("web");
$check_enable = intval($webconfig['system_check'])===1?true:false;

if(empty($_REQUEST['id'])){lyg::showmsg('参数错误');}
$dataid = trim($_REQUEST['id']);
$info=  $con->find("select * from #__fei where moneyID='".$dataid."'");
if(empty($info)){lyg::showmsg('参数错误');}


$feiinfo=  $con->select("select * from #__fei where moneyID='".$dataid."' order by id");

	
?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>信息</title>
<link href="style/css/css.css" rel="stylesheet" type="text/css" />
<link href="style/css/font-awesome.min.css" rel="stylesheet" type="text/css" />
<link href="style/css/font-awesome.min.css" rel="stylesheet" type="text/css" />
<style type="text/css">
label{margin-right:10px;}
</style>
<script type="text/javascript" src="js/My97DatePicker/WdatePicker.js"></script>
<script type="text/javascript" src="js/jquery.min.js"></script>
<script type="text/javascript" src="js/common.js"></script>
		<link rel="stylesheet" href="kindeditor/themes/default/default.css" />
		<script src="kindeditor/kindeditor-all.js" charset="UTF-8"></script>
		<script src="kindeditor/lang/zh-CN.js" charset="UTF-8"></script>
		<script>
			KindEditor.ready(function(K) {
				var editor = K.editor({
					allowFileManager : true
				});
				K('#image3').click(function() {
					editor.loadPlugin('image', function() {
						editor.plugin.imageDialog({
							showRemote : false,
							imageUrl : K('#url3').val(),
							clickFn : function(url, title, width, height, border, align) {
								K('#url3').val(url);
								editor.hideDialog();
							}
						});
					});
				});
			});
		</script>
</head>


<body class="content">
<style type="text/css">
@media print { 
 .noprint{display:none;}
}
</style>
<div align="right" class="noprint">
<a href='javascript:window.print()'>打印此页</a>
</div>

<h5 class='title'><span><?php echo $webconfig['system_name'];?>收款收据</span></h5>

<table cellpadding="0" cellspacing="0">
    	<tr>
<th align="left" width="60px">日期：</th>
<th align="left" width="100px"><?php echo substr($info['selldate'],0,10);?></th>
<th align="right" width="*">单号：</th>
<th align="right" width="120px"><?php echo $info['moneyID'];?></th>
        </tr>
</table>

<table cellpadding="3" cellspacing="3" class="table-add">
  <tr>
    <td align="right" height='36' width="100px">幼儿编号：</td>
    <td><?php echo c_wanglai1($info['stuid']);?></td>
    <td align="right" height='36' width="100px">幼儿姓名：</td>
    <td><?php echo c_classname("wanglai",$info['stuid']);?></td>
    <td align="right" width="100px">所在班级：</td>
    <td><?php echo c_classname("xiangmu",c_wanglaibanji($info['stuid']));?></td>
  </tr>
  <tr>
    <td align="right" height='36' width="100px">起止日期：</td>
    <td colspan="3"><?php echo substr($info['begindate'],0,10);?> -- <?php echo substr($info['enddate'],0,10);?></td>
    <td align="right">付款方式：</td>
    <td><?php echo $info['fangshi'];?></td>
  </tr>


	<tr>
		<td colspan="2"><strong>收费项目</strong></td>
		<td colspan="2"><strong>金额</strong></td>
		<td colspan="2"><strong>备注</strong></td>
	</tr>
<?php
$price1=0;
foreach ($feiinfo as $k => $v) {
?>
		<tr>
			<td colspan="2"><?php echo $v['name'];?></td>
			<td colspan="2"><?php echo $v['price'];?></td>
		    <td colspan="2"><?php echo $v['beizhu'];?></td>
	   </tr>


 <?php 
$price1=$price1+$v['price'];	 
}
?>

  <tr>
    <td align="right" height='36' width="100px"><strong>合计(大写)：</strong></td>
    <td colspan="3"><strong><?php echo LYG::num_case($price1);?></strong></td>
    <td align="right"><strong>￥：</strong></td>
    <td><strong><?php echo $price1;?></strong></td>
  </tr>

</table>




<table cellpadding="0" cellspacing="0" class="table-add1">
    	<tr>
<th align="left" width="80px">付款人：</th>
<th align="left" width="100px"></th>
<th align="right" width="*">经办人：</th>
<th align="left" width="120px"><?php echo c_classname("yuangong",$info['jingban']);?></th>
<th align="right" width="200px">收款单位（盖章）：</th>
<th align="right" width="100px"></th>
        </tr>
</table>

</body>
</html>