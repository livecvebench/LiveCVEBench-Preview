tinymce.addI18n('cs',{
"Insert/edit a XH plugin call": "Vložit/upravit XH plugin",
"Insert/edit the XH plugin call here - without {{{}}}": "Sem vložte nebo upravte příkaz XH pluginu - bez {{{}}}",
});