<?php
return array (
  'host' => 'localhost',
  'user' => 'root',
  'pwd' => 'root',
  'port' => '3306',
  'database' => 'school',
  'houtai' => 'manage',
);