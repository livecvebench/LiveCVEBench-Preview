<?php
require_once(dirname(__FILE__).'/include/common.php');

if(empty($_REQUEST['id']) || intval($_REQUEST['id'])<1){lyg::showmsg('参数错误');}
$data_id = intval($_REQUEST['id']);
$info=  $con->find("select * from #__shangpin where id=$data_id");
if(empty($info)){lyg::showmsg('参数错误');}

if(!empty($_POST)){
	//参数校验
	extract($_POST);

	if(empty($bianhao) || trim($bianhao)==''){
		LYG::ShowMsg('商品编号不能为空');
	}
	if(empty($name) || trim($name)==''){
		LYG::ShowMsg('商品名不能为空');
	}
	
	$ex = $con->rowscount("select count(*) from #__shangpin where bianhao=? and name=? and id<>?",array(
		$bianhao,$name,$data_id
	));
	if($ex>0){
		lyg::showmsg("同名商品已存在");
	}
	
	$data = array(
		$name,
		$bianhao,
		$fenlei,
		$danwei,
		$xinghao,
		floatval($price),
		$beizhu,
		$data_id,
	);
	
	$eok = $con->Update("update #__shangpin set name=?,bianhao=?,fenlei=?,danwei=?,xinghao=?,price=?,beizhu=? where id=? limit 1",$data);

	if($eok!==false){
		LYG::ShowMsg('操作成功','shangpin_list.php');
	}else{
		LYG::ShowMsg('操作失败，请重试');
	}
	
	die();
}

$classinfo = $con->select("select * from #__fenlei");
$danweiinfo = $con->select("select * from #__danwei");
	
?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>编辑商品</title>
<link href="style/css/css.css" rel="stylesheet" type="text/css" />
<script type="text/javascript" src="js/jquery.min.js"></script>
<script type="text/javascript" src="js/common.js"></script>
</head>

<body class="content">

<h5 class='back' onclick='history.go(-1);'><span>返回</span></h5>

<form action='' method='post'>
	<input type='hidden' name='id' value='<?php echo $data_id;?>'>
	<table cellpadding="3" cellspacing="0" class="table-add">
		<tr>
			<td align="right" width='100' height='36'>商品编号：</td>
			<td align="left" width='*'>
				<input type='text' class='inp' name='bianhao' value='<?php echo $info['bianhao'];?>'/>
			</td>
		</tr>
		<tr>
			<td align="right" width='100' height='36'>商品名称：</td>
			<td align="left" width='*'>
				<input type='text' class='inp' name='name' value='<?php echo $info['name'];?>'/>
			</td>
		</tr>
		<tr>
			<td align="right" height='36'>商品分类：</td>
			<td align="left" width='*'>
				<select name="fenlei" class="select">
				<?php
				foreach($classinfo as $k=>$v){
					if(intval($v['id'])===intval($info['fenlei'])){
						echo "<option value='{$v['id']}' selected='selected'>{$v['name']}</option>";
					}else{
						echo "<option value='{$v['id']}'>{$v['name']}</option>";
					}
				}
				?>
				</select>
			</td>
		</tr>
		<tr>
			<td align="right" height='36'>规格型号：</td>
			<td>
				<input type="text" name="xinghao" class="inp" placeholder="" value="<?php echo $info['xinghao']?>">
			</td>
		</tr>
		<tr>
			<td align="right" height='36'>单位：</td>
			<td align="left" width='*'>
				<select name="danwei" class="select">
				<?php
				foreach($danweiinfo as $k=>$v){

					if($v['name']===$info['danwei']){
						echo "<option value='{$v['name']}' selected='selected'>{$v['name']}</option>";
					}else{
						echo "<option value='{$v['name']}'>{$v['name']}</option>";
					}

				}
				?>
				</select>
			</td>
		</tr>
		<tr>
			<td align="right" height='36'>单价：</td>
			<td>
				<input type="number" name="price" class="inp" placeholder="0.00" value="<?php echo $info['price']?>">
			</td>
		</tr>
		<tr>
			<td align="right" height='36'>备注：</td>
			<td>
				<input type="text" name="beizhu" class="inp" placeholder="" value="<?php echo $info['beizhu']?>">
			</td>
		</tr>
		<tr>
			<td align="right" height='50'>　</td>
			<td align="left"><input class='edit' type='submit' value='修改'/></td>
		</tr>

	</table>
</form>

</body>
</html>