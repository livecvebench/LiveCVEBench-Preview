<?php

$plugin_mcf['pagemanager']['verbose']="bool";
$plugin_mcf['pagemanager']['toolbar_show']="bool";
$plugin_mcf['pagemanager']['pagedata_attribute']="enum:,linked_to_menu,published";
$plugin_mcf['pagemanager']['treeview_theme']="function:Pagemanager_themes";
$plugin_mcf['pagemanager']['treeview_animation']="range:0,1000,100";
