<?php

$mtx['seperator']="Separator";
$mtx['external']="Name";
$mtx['validate']="Validate links";
$mtx['org']="Original";
$mtx['tmpfiles']="Temporary backup";
$mtx['urichar']="URL-Characters";
