<?php
require_once(dirname(__FILE__).'/include/common.php');
if (strpos($_SESSION['eptime_flag'], 'feilfig') === false) {LYG::ShowMsg('您没有权限！');}
?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title></title>
<link href="style/css/css.css" rel="stylesheet" type="text/css" />
<style type="text/css">
.tongji1{ float: left; width: 98%; padding:20px 0 0;font-size: 14px;}
.tongji1 h2{ text-align:center; font-size: 18px; line-height: 3em;padding: 10px 10px; border-bottom: 1px solid #ccc }
.tongji{ float: left; width: 49%; padding:20px 0 0;font-size: 14px;}
.tongji h2{ font-size: 15px; line-height: 1em;padding: 10px 0; border-bottom: 1px solid #ccc }
</style>
</head>

<body class="content">
<?php
$_day1 =strtotime(date("Y-m-d",time()));
$_week1 =strtotime(date("Y-m-d 00:00:00",strtotime("last Sunday +1 day")));
$_month1 =strtotime(date("Y-m-d H:i:s",mktime(0, 0 , 0,date("m"),1,date("Y"))));
$_year1 =strtotime(date("Y-01-01 00:00:00")); 
$_all1 =strtotime("2000-01-01 00:00:00"); 
function _total($pay,$time1){
	global $con;
if($pay==0){$sql = "select SUM(price) as sl from #__fei where UNIX_TIMESTAMP(selldate) >= {$time1} ";}
if($pay==1){$sql = "select SUM(price) as sl from #__fei where price>0 and UNIX_TIMESTAMP(selldate) >= {$time1} ";}
if($pay==2){$sql = "select SUM(price) as sl from #__fei where price<0 and UNIX_TIMESTAMP(selldate) >= {$time1} ";}
		$sl = $con->find($sql);
		if(empty($sl['sl'])){ $sl['sl'] = 0;}
		return round($sl['sl'],2);
	
}
?>



<div class="tongji1">
	<h2><?php echo $webconfig['system_name'];?>收退费情况统计表<font color=red></font></h2>
	<table>
		<tr>
			<td><b></b></td>
			<td><b>今日</b></td>
			<td><b>本周</b></td>
			<td><b>本月</b></td>
			<td><b>本年</b></td>
			<td><b>全部</b></td>
		</tr>
			<tr>
				<td><img src="style/images/s.png"> 收费</td>
				<td><span style="color:red"><?php echo _total('1',$_day1);?></span></td>
				<td><span style="color:red"><?php echo _total('1',$_week1);?></span></td>
				<td><span style="color:red"><?php echo _total('1',$_month1);?></span></td>
				<td><span style="color:red"><?php echo _total('1',$_year1);?></span></td>
				<td><span style="color:red"><?php echo _total('1',$_all1);?></span></td>
			</tr>
			<tr>
				<td><img src="style/images/z.png"> 退费</td>
				<td><span style="color:#229D89"><?php echo _total('2',$_day1);?></span></td>
				<td><span style="color:#229D89"><?php echo _total('2',$_week1);?></span></td>
				<td><span style="color:#229D89"><?php echo _total('2',$_month1);?></span></td>
				<td><span style="color:#229D89"><?php echo _total('2',$_year1);?></span></td>
				<td><span style="color:#229D89"><?php echo _total('2',$_all1);?></span></td>
			</tr>
			<tr>
				<td> 合计</td>
				<td><span style="color:#000"><?php echo _total('0',$_day1);?></span></td>
				<td><span style="color:#000"><?php echo _total('0',$_week1);?></span></td>
				<td><span style="color:#000"><?php echo _total('0',$_month1);?></span></td>
				<td><span style="color:#000"><?php echo _total('0',$_year1);?></span></td>
				<td><span style="color:#000"><?php echo _total('0',$_all1);?></span></td>
			</tr>
	</table>
</div>

</body>
</html>