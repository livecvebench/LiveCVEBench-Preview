<?php
/**
 * Not Allowed
 * Thanks.
 */
?>