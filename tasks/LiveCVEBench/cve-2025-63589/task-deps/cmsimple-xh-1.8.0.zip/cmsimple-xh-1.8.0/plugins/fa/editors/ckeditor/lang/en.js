CKEDITOR.plugins.setLang('fontawesome', 'en', {
	title: 'Insert Font Awesome'
});
