<?php
$plugin_mcf['tinymce7']['init']="function:tinymce_getInits";
$plugin_mcf['tinymce7']['utf8_marker']="hidden";
$plugin_mcf['tinymce7']['CDN']="bool";   //"" = locally installed, "CDN" = CDN Variant 
$plugin_mcf['tinymce7']['CDN_src']="text";
