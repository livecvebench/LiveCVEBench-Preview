/* global CodeMirror:true */
/* global wp:true */
/* global ditty_news_ticker_vars:true */
/* global ajaxurl:true */
/* global tinyMCE:true */

// @codekit-append 'partials/mtphr-dnt-affix.js';
// @codekit-append 'partials/admin-general.js';